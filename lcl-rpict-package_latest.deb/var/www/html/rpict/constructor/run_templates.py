#!/usr/bin/python3

from quik import FileLoader
loader = FileLoader('')
template = loader.load_template('frame.html')

fi = open('basic_config.html')
fo = open('../index.html','wb')
d = fi.read()
fo.write(template.render({'config_content': d}, loader=loader).encode())
fi.close()
fo.close()

fi = open('advanced_config.html')
fo = open('../advanced_configuration.html','wb')
d = fi.read()
fo.write(template.render({'config_content': d}, loader=loader).encode())
fi.close()
fo.close()

