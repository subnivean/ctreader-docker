
var config_hash = "";
var hardcode_text = "";
var config_mode = "full";


window.onload = function onloadFunction() {
	var full_config_text = localStorage.getItem("full_config_text");

	if (full_config_text != null){
		console.log("Config loaded from cache.");
		populate_config(full_config_text);
		//generate_config();
	}
	else {
		control_number_slave_changed(false);// no generate config
	}
	
	update_m0_controls();
	update_s1_controls();
	update_s2_controls();
	update_s3_controls();
	update_s4_controls();

	
	update_select_port_names("snode_port", "snode_level", "any", "btn_snode");
	update_select_port_names("pnode_portI", "pnode_levelI", "current", "btn_pnode");
	update_select_port_names("pnode_portV", "pnode_levelV", "voltage", "btn_pnode");
	update_select_port_names("tnode_portI", "tnode_levelI", "current", "btn_tnode");
	update_select_port_names("tnode_portV", "tnode_levelV", "voltage", "btn_tnode");
	update_select_port_names("fnode_port", "fnode_level", "any", "btn_fnode");
	update_snode_table();
	update_pnode_table();
	update_tnode_table();
	update_fnode_table();
	
	update_output_channels_controls();
	
	generate_config();
	
}



// delete this and also in frame.html
function onload(){}

function get_dev_config(){

	if (is_online){
		alert('This function is disabled on the online version');
		return;
	}

	$("#response").html("querying device...");

	var xhr = new XMLHttpRequest();

	
	xhr.open("POST", "/cgi-bin/get_dev_config.py");
	xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

	
	var cfg_txt = $("#config_pre").html();
	
	xhr.send("");

	
	xhr.onload = function() {
		//console.log(`Loaded: ${xhr.status} ${xhr.response}`);
		var r = JSON.parse(xhr.response);
		//document.getElementById("response").innerHTML = xhr.response;
		if (r.success=="true"){
			var config_text = r.config.replace(/\$/g, "\n");
			$("#response").html('<span style="color:green">Configuration loaded from device.</span>');
			populate_config(config_text);
			// not sure about this below
			// should we maybe do a generate config here?
			localStorage.setItem("full_config_text", config_text);
			$("#config_pre").html(config_text);
		}
		else {
			$("#response").html('<span style="color:red">'+r.error+'</span>');
		}
		
		update_output_channels_controls();
	};

	xhr.onerror = function() { // only triggers if the request couldn't be made at all
		//console.log(`Network Error`);
		$("#response").html('<span style="color:red">Network Error!</span>');
	};
	
	
}


function hardcoding_save_to_file(){

  generate_hardcode();
  //console.log(hardcode_text);

  //var textToWrite = document.getElementById('hardcode_pre').innerHTML;
  var textToWrite = hardcode_text;
  var textFileAsBlob = new Blob([ textToWrite ], { type: 'text/plain' });
  var fileNameToSaveAs = config_hash+".ino"; //filename.extension

  var downloadLink = document.createElement("a");
  downloadLink.download = fileNameToSaveAs;
  downloadLink.innerHTML = "Download File";
  if (window.webkitURL != null) {
    // Chrome allows the link to be clicked without actually adding it to the DOM.
    downloadLink.href = window.webkitURL.createObjectURL(textFileAsBlob);
  } 
  else {
    // Firefox requires the link to be added to the DOM before it can be clicked.
    downloadLink.href = window.URL.createObjectURL(textFileAsBlob);
    downloadLink.onclick = destroyClickedElement;
    downloadLink.style.display = "none";
    document.body.appendChild(downloadLink);
  }

  downloadLink.click();

}


function populate_config(text){
		console.log("populate config");
        	//clear the tables first
        	snode_table = document.getElementById("snode_table")
          	while (snode_table.rows.length > 2) snode_table.deleteRow(-1);
          	pnode_table = document.getElementById("pnode_table")
          	while (pnode_table.rows.length > 2) pnode_table.deleteRow(-1);
          	tnode_table = document.getElementById("tnode_table")
          	while (tnode_table.rows.length > 2) tnode_table.deleteRow(-1);
          	fnode_table = document.getElementById("fnode_table")
          	while (fnode_table.rows.length > 2) fnode_table.deleteRow(-1);
          	oc_table = document.getElementById("output_channels_table")
          	while (oc_table.rows.length > 2) oc_table.deleteRow(-1);
          	
          	var total_node = 0;
        	
		
        	var z = text.split("\n");
        	for(var i=0;i<z.length;i++){
        		v = z[i].split("=");
        		
        		//console.log(v);
        		v[0] = v[0].trim();
        		if (v.length>1){
        			v[1] = v[1].trim();
        		}

        		//console.log(v[0]);
        		
        		if (v[0]=="format"){
        			document.getElementById("ControlSelectFormat").value = v[1];
        		}
        		else if (v[0]=="device_id"){
          			document.getElementById("ControlInput_NID").value = v[1];
          		}
          		else if (v[0]=="output_rate"){
          			document.getElementById("ControlInput_orate").value = v[1];
          		}
          		else if (v[0]=="phasecal"){
          			document.getElementById("ControlInputPhasecal").value = v[1];
          		}
          		else if (v[0]=="vest"){
          			document.getElementById("ControlInputVest").value = v[1];
          		}
          		else if (v[0]=="xpFREQ"){
          			document.getElementById("ControlInputXpfreq").value = v[1];
          			var freq = v[1];
          		}
          		else if (v[0]=="Ncycle"){
          			document.getElementById("ControlInputNcycle").value = v[1];
          			var ncycles = v[1];
          		}
          		else if (v[0]=="debug"){
          			if (v[1]=="1") document.getElementById("ControlCheckBoxDebug").checked = true;
          			else document.getElementById("ControlCheckBoxDebug").checked = false;
          		}
          		else if (v[0]=="model"){
          			mdls = v[1].split(" ");
          			
          			document.getElementById("control_number_slave").value = mdls[0];
          			document.getElementById("control_m0_model").value = convert_modelid_to_modelname(mdls[1]);
          			document.getElementById("control_s1_model").value = convert_modelid_to_modelname(mdls[2]);
          			document.getElementById("control_s2_model").value = convert_modelid_to_modelname(mdls[3]);
          			document.getElementById("control_s3_model").value = convert_modelid_to_modelname(mdls[4]);
          			document.getElementById("control_s4_model").value = convert_modelid_to_modelname(mdls[5]);
          			
          			//
          			document.getElementById("control_select_cttype_m0").value = "Custom";
          			document.getElementById("control_select_cttype_s1").value = "Custom";
          			document.getElementById("control_select_cttype_s2").value = "Custom";
          			document.getElementById("control_select_cttype_s3").value = "Custom";
          			document.getElementById("control_select_cttype_s4").value = "Custom";
          			
          			
				
				control_number_slave_changed(false);
          			
          		}
          		else if (v[0]=="kcal"){
          			kcals = v[1].split(" ");
          			document.getElementById("ControlInput_kcal_m0c0").value = kcals[0];
          			document.getElementById("ControlInput_kcal_m0c1").value = kcals[1];
          			document.getElementById("ControlInput_kcal_m0c2").value = kcals[2];
          			document.getElementById("ControlInput_kcal_m0c3").value = kcals[3];
          			document.getElementById("ControlInput_kcal_m0c4").value = kcals[4];
          			document.getElementById("ControlInput_kcal_m0c5").value = kcals[5];
          			document.getElementById("ControlInput_kcal_m0c6").value = kcals[6];
          			document.getElementById("ControlInput_kcal_m0c7").value = kcals[7];
          			document.getElementById("ControlInput_kcal_s1c0").value = kcals[8];
          			document.getElementById("ControlInput_kcal_s1c1").value = kcals[9];
          			document.getElementById("ControlInput_kcal_s1c2").value = kcals[10];
          			document.getElementById("ControlInput_kcal_s1c3").value = kcals[11];
          			document.getElementById("ControlInput_kcal_s1c4").value = kcals[12];
          			document.getElementById("ControlInput_kcal_s1c5").value = kcals[13];
          			document.getElementById("ControlInput_kcal_s1c6").value = kcals[14];
          			document.getElementById("ControlInput_kcal_s1c7").value = kcals[15];
          			document.getElementById("ControlInput_kcal_s2c0").value = kcals[16];
          			document.getElementById("ControlInput_kcal_s2c1").value = kcals[17];
          			document.getElementById("ControlInput_kcal_s2c2").value = kcals[18];
          			document.getElementById("ControlInput_kcal_s2c3").value = kcals[19];
          			document.getElementById("ControlInput_kcal_s2c4").value = kcals[20];
          			document.getElementById("ControlInput_kcal_s2c5").value = kcals[21];
          			document.getElementById("ControlInput_kcal_s2c6").value = kcals[22];
          			document.getElementById("ControlInput_kcal_s2c7").value = kcals[23];
          			document.getElementById("ControlInput_kcal_s3c0").value = kcals[24];
          			document.getElementById("ControlInput_kcal_s3c1").value = kcals[25];
          			document.getElementById("ControlInput_kcal_s3c2").value = kcals[26];
          			document.getElementById("ControlInput_kcal_s3c3").value = kcals[27];
          			document.getElementById("ControlInput_kcal_s3c4").value = kcals[28];
          			document.getElementById("ControlInput_kcal_s3c5").value = kcals[29];
          			document.getElementById("ControlInput_kcal_s3c6").value = kcals[30];
          			document.getElementById("ControlInput_kcal_s3c7").value = kcals[31];
          			document.getElementById("ControlInput_kcal_s4c0").value = kcals[32];
          			document.getElementById("ControlInput_kcal_s4c1").value = kcals[33];
          			document.getElementById("ControlInput_kcal_s4c2").value = kcals[34];
          			document.getElementById("ControlInput_kcal_s4c3").value = kcals[35];
          			document.getElementById("ControlInput_kcal_s4c4").value = kcals[36];
          			document.getElementById("ControlInput_kcal_s4c5").value = kcals[37];
          			document.getElementById("ControlInput_kcal_s4c6").value = kcals[38];
          			document.getElementById("ControlInput_kcal_s4c7").value = kcals[39];
          			
          		}
          		else if (v[0]=="snode_pin"){
          			if (v[1]!=''){
          				nods = v[1].split(" ");
          				total_node += nods.length;
          				
          				for (var j=0; j<nods.length; j++){
          				
          					rowCount = snode_table.rows.length;
    						row = snode_table.insertRow(rowCount);
		
		    				row.insertCell(0).innerHTML= "S"+(rowCount-1);
						row.insertCell(1).innerHTML= "";
						row.insertCell(2).innerHTML= "";
						row.insertCell(3).innerHTML= '<span data-feather="x-circle" onclick="snode_deleteRow(this)">ok</span>';
						row.insertCell(4).innerHTML= nods[j];
						row.cells[4].style = "display: none";
						row.insertCell(5).innerHTML= "";
						row.cells[5].style = "display: none";
					
					}
				}
          		}
          		else if (v[0]=="snode_mcp"){
          			if (v[1]!=''){
          				nods = v[1].split(" ");
          			
          				for (j=0; j<nods.length; j++){
          					rowCount = snode_table.rows.length;
						snode_table.rows[j+2].cells[5].innerHTML = nods[j];
						snode_table.rows[j+2].cells[2].innerHTML = convert_level_number(nods[j]);
					
					}
					update_snode_table();
          			
          				//console.log(nods.length);
          				$("#header_snode").html("("+(nods.length)+")");
          			}
          			else {
          				$("#header_snode").html("(0)");
          			}
          		}
          		
          		else if (v[0]=="pnode_pinI"){
          			if (v[1]!=''){
          				nods = v[1].split(" ");
          				total_node += nods.length;
          				
          				for (var j=0; j<nods.length; j++){
          				
          					rowCount = pnode_table.rows.length;
    						row = pnode_table.insertRow(rowCount);
		
		    				row.insertCell(0).innerHTML= "P"+(rowCount-1);
						row.insertCell(1).innerHTML= "";
						row.insertCell(2).innerHTML= "";
						row.insertCell(3).innerHTML= "";
						row.insertCell(4).innerHTML= "";
						row.insertCell(5).innerHTML= '<span data-feather="x-circle" onclick="pnode_deleteRow(this)">ok</span>';
						row.insertCell(6).innerHTML= nods[j];
						row.cells[6].style = "display: none";
						row.insertCell(7).innerHTML= "";
						row.cells[7].style = "display: none";
						row.insertCell(8).innerHTML= "";
						row.cells[8].style = "display: none";
						row.insertCell(9).innerHTML= "";
						row.cells[9].style = "display: none";
						
					}
				}
          		}
          		else if (v[0]=="pnode_mcpI"){
          			if (v[1]!=''){
          				nods = v[1].split(" ");
          				
          				for (j=0; j<nods.length; j++){
          					rowCount = pnode_table.rows.length;
						pnode_table.rows[j+2].cells[7].innerHTML = nods[j];
						pnode_table.rows[j+2].cells[2].innerHTML = convert_level_number(nods[j]);
					}
          			}
          		}
          		else if (v[0]=="pnode_pinV"){
          			if (v[1]!=''){
          				nods = v[1].split(" ");
          				
          				for (j=0; j<nods.length; j++){
          					rowCount = pnode_table.rows.length;
						pnode_table.rows[j+2].cells[8].innerHTML = nods[j];
					}
          			}
          		}
          		else if (v[0]=="pnode_mcpV"){
          			if (v[1]!=''){
          				nods = v[1].split(" ");
          				
          				for (j=0; j<nods.length; j++){
          					rowCount = pnode_table.rows.length;
						pnode_table.rows[j+2].cells[9].innerHTML = nods[j];
						pnode_table.rows[j+2].cells[4].innerHTML = convert_level_number(nods[j]);
						
					}
					update_pnode_table();
          				
          				$("#header_pnode").html("("+(nods.length)+")");
          			}
          			else {
          				$("#header_pnode").html("(0)");
          			}
          		}
          		
          		else if (v[0]=="tnode_pinI"){
          			if (v[1]!=''){
          				nods = v[1].split(" ");
          				total_node += nods.length;
          			
          				for (var j=0; j<nods.length; j++){
          				
          					rowCount = tnode_table.rows.length;
    						row = tnode_table.insertRow(rowCount);
		
		    				row.insertCell(0).innerHTML= "Y"+(Math.floor((rowCount-2)/3)+1);
		    				row.insertCell(1).innerHTML= "L"+(((rowCount-2)%3)+1);
						row.insertCell(2).innerHTML= "";
						row.insertCell(3).innerHTML= "";
						row.insertCell(4).innerHTML= "";
						row.insertCell(5).innerHTML= "";
						row.insertCell(6).innerHTML= '<span data-feather="x-circle" onclick="tnode_deleteRow(this)">ok</span>';
						row.insertCell(7).innerHTML= nods[j];
						row.cells[7].style = "display: none";
						row.insertCell(8).innerHTML= "";
						row.cells[8].style = "display: none";
						row.insertCell(9).innerHTML= "";
						row.cells[9].style = "display: none";
						row.insertCell(10).innerHTML= "";
						row.cells[10].style = "display: none";
						
					}
				}
          		}
          		else if (v[0]=="tnode_mcpI"){
          			if (v[1]!=''){
		  			nods = v[1].split(" ");
		  			
		  			for (j=0; j<nods.length; j++){
		  				rowCount = tnode_table.rows.length;
						tnode_table.rows[j+2].cells[8].innerHTML = nods[j];
						tnode_table.rows[j+2].cells[3].innerHTML = convert_level_number(nods[j]);
					}
				}
          		
          		}
          		else if (v[0]=="tnode_pinV"){
          			if (v[1]!=''){
		  			nods = v[1].split(" ");
		  			
		  			for (j=0; j<nods.length; j++){
		  				rowCount = tnode_table.rows.length;
						tnode_table.rows[j+2].cells[9].innerHTML = nods[j];
					}
				}
          		
          		}
          		else if (v[0]=="tnode_mcpV"){
          			if (v[1]!=''){
		  			nods = v[1].split(" ");
		  			
		  			for (j=0; j<nods.length; j++){
		  				rowCount = pnode_table.rows.length;
						tnode_table.rows[j+2].cells[10].innerHTML = nods[j];
						tnode_table.rows[j+2].cells[5].innerHTML = convert_level_number(nods[j]);
						
					}
					update_tnode_table();
		  			
		  			$("#header_tnode").html("("+(Math.floor(nods.length/3))+")");
		  		}
		  		else {
          				$("#header_tnode").html("(0)");
          			}
          		
          		}
          		else if (v[0]=="fnode_pin"){
          			if (v[1]!=''){
		  			nods = v[1].split(" ");
		  			
		  			for (var j=0; j<nods.length; j++){
		  			
		  				rowCount = fnode_table.rows.length;
	    					row = fnode_table.insertRow(rowCount);
		
		    				row.insertCell(0).innerHTML= "F"+(rowCount-1);
						row.insertCell(1).innerHTML= "";
						row.insertCell(2).innerHTML= "";
						row.insertCell(3).innerHTML= '<span data-feather="x-circle" onclick="fnode_deleteRow(this)">ok</span>';
						row.insertCell(4).innerHTML= nods[j];
						row.cells[4].style = "display: none";
						row.insertCell(5).innerHTML= "";
						row.cells[5].style = "display: none";
						
					}
				}
          		}
          		else if (v[0]=="fnode_mcp"){
          			if (v[1]!=''){
		  			nods = v[1].split(" ");
		  			
		  			for (j=0; j<nods.length; j++){
		  				rowCount = fnode_table.rows.length;
						fnode_table.rows[j+2].cells[5].innerHTML = nods[j];
						fnode_table.rows[j+2].cells[2].innerHTML = convert_level_number(nods[j]);
						
					}
					update_fnode_table();
		  			
		  			$("#header_fnode").html("("+(nods.length)+")");
          			}
          			else {
          				$("#header_fnode").html("(0)");
          			}
          		}
          		else if (v[0]=="CHID"){
          			if (v[1]!=''){
		  			nods = v[1].split(" ");
		  			
		  			for (var j=0; j<nods.length; j++){
		  			
		  				rowCount = oc_table.rows.length;
	    					row = oc_table.insertRow(rowCount);
		
		    				row.insertCell(0).innerHTML= "";
						row.insertCell(1).innerHTML= nods[j];
						row.insertCell(2).innerHTML= "";
						row.insertCell(3).innerHTML= '<span data-feather="x-circle" onclick="output_channels_deleteRow(this)">ok</span>';
						row.insertCell(4).innerHTML= "";
						row.cells[4].style = "display: none";
						row.insertCell(5).innerHTML= nods[j];
						row.cells[5].style = "display: none";
						row.insertCell(6).innerHTML= "";
						row.cells[6].style = "display: none";
						
						
					}
				}
          		}
          		else if (v[0]=="CH_node_type"){
          			if (v[1]!=''){
		  			nods = v[1].split(" ");
		  			
		  			for (j=0; j<nods.length; j++){
		  				rowCount = oc_table.rows.length;
						oc_table.rows[j+2].cells[4].innerHTML = nods[j];
						oc_table.rows[j+2].cells[0].innerHTML = convert_nodetypenumber_to_nodetypename(nods[j]);
					}
				}          		
          		}
          		else if (v[0]=="CH_field_type"){
          			if (v[1]!=''){
		  			nods = v[1].split(" ");
		  			
		  			for (j=0; j<nods.length; j++){
		  				rowCount = pnode_table.rows.length;
						oc_table.rows[j+2].cells[6].innerHTML = nods[j];
						oc_table.rows[j+2].cells[2].innerHTML = convert_fieldnumber_to_fieldname(nods[j]);
						
					}
					//update_pnode_table();
		  			
		  			$("#header_output_channels").html("("+(nods.length)+")");
		  		} 
		  		else {
          				$("#header_output_channels").html("(0)");
          			}         		
          		}
          		
          		
        	}// for      
        	
        	update_summary(text, total_node, ncycles, freq);
        	update_sensor_from_kcal_m0();
        	update_sensor_from_kcal_s1();
        	update_sensor_from_kcal_s2();
        	update_sensor_from_kcal_s3();
        	update_sensor_from_kcal_s4();
        	update_m0_controls();
		update_s1_controls();
		update_s2_controls();
		update_s3_controls();
		update_s4_controls();
        	//
        	update_output_channels_table();
        	update_output_channels_controls();
        	feather.replace();

}

function check_kcal_against_value(kcal_in, check_val){
	var delta = 0.00001;
	if ((kcal_in>(check_val-delta)) && (kcal_in<(check_val+delta))){
		//console.log(kcal_in, check_val, true);
		return true;
	}
	return false;
}

function transform_to_closest_known_kcal(kcal_in){
	for (var i=0; i<ICALS.length; i++){
		if (check_kcal_against_value(kcal_in, parseFloat(ICALS[i].ical))){
			return ICALS[i].ical;
		}
	}
	for (var i=0; i<VCALS.length; i++){
		if (check_kcal_against_value(kcal_in, parseFloat(VCALS[i].vcal))){
			return VCALS[i].vcal;
		}
	}
	return kcal_in;
}

function allEqual(arr) {
  return new Set(arr).size == 1;
}

function ICALS_query_from_ical(ical_in){
	for (var i=0; i<ICALS.length; i++){
		if (ICALS[i].ical == ical_in){
			return ICALS[i]
		}
	}
	return null;
}

function VCALS_query_from_vcal(vcal_in){
	for (var i=0; i<VCALS.length; i++){
		if (VCALS[i].vcal == vcal_in){
			return VCALS[i]
		}
	}
	return null;
}

function update_sensor_from_kcal_m0(){
	var kc = [];
	var model = $("#control_m0_model").val();
	var hwversion = $("#control_m0_hwversion").val();
	
	kc[0] = transform_to_closest_known_kcal(parseFloat($("#ControlInput_kcal_m0c0").val()));
        kc[1] = transform_to_closest_known_kcal(parseFloat($("#ControlInput_kcal_m0c1").val()));
        kc[2] = transform_to_closest_known_kcal(parseFloat($("#ControlInput_kcal_m0c2").val()));
        kc[3] = transform_to_closest_known_kcal(parseFloat($("#ControlInput_kcal_m0c3").val()));
        kc[4] = transform_to_closest_known_kcal(parseFloat($("#ControlInput_kcal_m0c4").val()));
        kc[5] = transform_to_closest_known_kcal(parseFloat($("#ControlInput_kcal_m0c5").val()));
        kc[6] = transform_to_closest_known_kcal(parseFloat($("#ControlInput_kcal_m0c6").val()));
        kc[7] = transform_to_closest_known_kcal(parseFloat($("#ControlInput_kcal_m0c7").val()));
        
	
	if (model=="RPICT8"){
		if (allEqual(kc)){
			var it = ICALS_query_from_ical(kc[0])
			if (it != null){
				$("#control_select_cttype_m0").val(it.cttype);
			}
		}
	}
	else if (model=="RPICT7V1"){
		if (allEqual(kc.slice(1,-1))){
			var it = ICALS_query_from_ical(kc[7])
			if (it != null){
				$("#control_select_cttype_m0").val(it.cttype);
			}
		}
		
		var it = VCALS_query_from_vcal(kc[0])
		if (it != null){
			$("#control_select_voltage_m0").val(it.vtype);
		}
	
	}
	else if (model=="RPICT4V3"){
		
		if (allEqual(kc.slice(3,-1))){
			var it = ICALS_query_from_ical(kc[7])
			if (it != null){
				$("#control_select_cttype_m0").val(it.cttype);
			}
		}
		
		if (allEqual(kc.slice(0,3))){
			var it = VCALS_query_from_vcal(kc[0])
			if (it != null){
				$("#control_select_voltage_m0").val(it.vtype);
			}
		}
	
	}
	
}

function update_sensor_from_kcal_s1(){
	var kc = [];
	var model = $("#control_s1_model").val();
	var hwversion = $("#control_s1_hwversion").val();
	
	kc[0] = transform_to_closest_known_kcal(parseFloat($("#ControlInput_kcal_s1c0").val()));
        kc[1] = transform_to_closest_known_kcal(parseFloat($("#ControlInput_kcal_s1c1").val()));
        kc[2] = transform_to_closest_known_kcal(parseFloat($("#ControlInput_kcal_s1c2").val()));
        kc[3] = transform_to_closest_known_kcal(parseFloat($("#ControlInput_kcal_s1c3").val()));
        kc[4] = transform_to_closest_known_kcal(parseFloat($("#ControlInput_kcal_s1c4").val()));
        kc[5] = transform_to_closest_known_kcal(parseFloat($("#ControlInput_kcal_s1c5").val()));
        kc[6] = transform_to_closest_known_kcal(parseFloat($("#ControlInput_kcal_s1c6").val()));
        kc[7] = transform_to_closest_known_kcal(parseFloat($("#ControlInput_kcal_s1c7").val()));
        
	
	if (model=="RPICT8"){
		if (allEqual(kc)){
			var it = ICALS_query_from_ical(kc[0])
			if (it != null){
				$("#control_select_cttype_s1").val(it.cttype);
			}
		}
	}
	else if (model=="RPICT7V1"){
		if (allEqual(kc.slice(1,-1))){
			var it = ICALS_query_from_ical(kc[7])
			if (it != null){
				$("#control_select_cttype_s1").val(it.cttype);
			}
		}
		
		var it = VCALS_query_from_vcal(kc[0])
		if (it != null){
			$("#control_select_voltage_s1").val(it.vtype);
		}
	
	}
	else if (model=="RPICT4V3"){
		
		if (allEqual(kc.slice(3,-1))){
			var it = ICALS_query_from_ical(kc[7])
			if (it != null){
				$("#control_select_cttype_s1").val(it.cttype);
			}
		}
		
		if (allEqual(kc.slice(0,3))){
			var it = VCALS_query_from_vcal(kc[0])
			if (it != null){
				$("#control_select_voltage_s1").val(it.vtype);
			}
		}
	
	}
	
}

function update_sensor_from_kcal_s2(){
	var kc = [];
	var model = $("#control_s2_model").val();
	var hwversion = $("#control_s2_hwversion").val();
	
	kc[0] = transform_to_closest_known_kcal(parseFloat($("#ControlInput_kcal_s2c0").val()));
        kc[1] = transform_to_closest_known_kcal(parseFloat($("#ControlInput_kcal_s2c1").val()));
        kc[2] = transform_to_closest_known_kcal(parseFloat($("#ControlInput_kcal_s2c2").val()));
        kc[3] = transform_to_closest_known_kcal(parseFloat($("#ControlInput_kcal_s2c3").val()));
        kc[4] = transform_to_closest_known_kcal(parseFloat($("#ControlInput_kcal_s2c4").val()));
        kc[5] = transform_to_closest_known_kcal(parseFloat($("#ControlInput_kcal_s2c5").val()));
        kc[6] = transform_to_closest_known_kcal(parseFloat($("#ControlInput_kcal_s2c6").val()));
        kc[7] = transform_to_closest_known_kcal(parseFloat($("#ControlInput_kcal_s2c7").val()));
        
	
	if (model=="RPICT8"){
		if (allEqual(kc)){
			var it = ICALS_query_from_ical(kc[0])
			if (it != null){
				$("#control_select_cttype_s2").val(it.cttype);
			}
		}
	}
	else if (model=="RPICT7V1"){
		if (allEqual(kc.slice(1,-1))){
			var it = ICALS_query_from_ical(kc[7])
			if (it != null){
				$("#control_select_cttype_s2").val(it.cttype);
			}
		}
		
		var it = VCALS_query_from_vcal(kc[0])
		if (it != null){
			$("#control_select_voltage_s2").val(it.vtype);
		}
	
	}
	else if (model=="RPICT4V3"){
		
		if (allEqual(kc.slice(3,-1))){
			var it = ICALS_query_from_ical(kc[7])
			if (it != null){
				$("#control_select_cttype_s2").val(it.cttype);
			}
		}
		
		if (allEqual(kc.slice(0,3))){
			var it = VCALS_query_from_vcal(kc[0])
			if (it != null){
				$("#control_select_voltage_s2").val(it.vtype);
			}
		}
	
	}
	
}

function update_sensor_from_kcal_s3(){
	var kc = [];
	var model = $("#control_s3_model").val();
	var hwversion = $("#control_s3_hwversion").val();
	
	kc[0] = transform_to_closest_known_kcal(parseFloat($("#ControlInput_kcal_s3c0").val()));
        kc[1] = transform_to_closest_known_kcal(parseFloat($("#ControlInput_kcal_s3c1").val()));
        kc[2] = transform_to_closest_known_kcal(parseFloat($("#ControlInput_kcal_s3c2").val()));
        kc[3] = transform_to_closest_known_kcal(parseFloat($("#ControlInput_kcal_s3c3").val()));
        kc[4] = transform_to_closest_known_kcal(parseFloat($("#ControlInput_kcal_s3c4").val()));
        kc[5] = transform_to_closest_known_kcal(parseFloat($("#ControlInput_kcal_s3c5").val()));
        kc[6] = transform_to_closest_known_kcal(parseFloat($("#ControlInput_kcal_s3c6").val()));
        kc[7] = transform_to_closest_known_kcal(parseFloat($("#ControlInput_kcal_s3c7").val()));
        
	
	if (model=="RPICT8"){
		if (allEqual(kc)){
			var it = ICALS_query_from_ical(kc[0])
			if (it != null){
				$("#control_select_cttype_s3").val(it.cttype);
			}
		}
	}
	else if (model=="RPICT7V1"){
		if (allEqual(kc.slice(1,-1))){
			var it = ICALS_query_from_ical(kc[7])
			if (it != null){
				$("#control_select_cttype_s3").val(it.cttype);
			}
		}
		
		var it = VCALS_query_from_vcal(kc[0])
		if (it != null){
			$("#control_select_voltage_s3").val(it.vtype);
		}
	
	}
	else if (model=="RPICT4V3"){
		
		if (allEqual(kc.slice(3,-1))){
			var it = ICALS_query_from_ical(kc[7])
			if (it != null){
				$("#control_select_cttype_s3").val(it.cttype);
			}
		}
		
		if (allEqual(kc.slice(0,3))){
			var it = VCALS_query_from_vcal(kc[0])
			if (it != null){
				$("#control_select_voltage_s3").val(it.vtype);
			}
		}
	
	}
	
}

function update_sensor_from_kcal_s4(){
	var kc = [];
	var model = $("#control_s4_model").val();
	var hwversion = $("#control_s4_hwversion").val();
	
	kc[0] = transform_to_closest_known_kcal(parseFloat($("#ControlInput_kcal_s4c0").val()));
        kc[1] = transform_to_closest_known_kcal(parseFloat($("#ControlInput_kcal_s4c1").val()));
        kc[2] = transform_to_closest_known_kcal(parseFloat($("#ControlInput_kcal_s4c2").val()));
        kc[3] = transform_to_closest_known_kcal(parseFloat($("#ControlInput_kcal_s4c3").val()));
        kc[4] = transform_to_closest_known_kcal(parseFloat($("#ControlInput_kcal_s4c4").val()));
        kc[5] = transform_to_closest_known_kcal(parseFloat($("#ControlInput_kcal_s4c5").val()));
        kc[6] = transform_to_closest_known_kcal(parseFloat($("#ControlInput_kcal_s4c6").val()));
        kc[7] = transform_to_closest_known_kcal(parseFloat($("#ControlInput_kcal_s4c7").val()));
        
	
	if (model=="RPICT8"){
		if (allEqual(kc)){
			var it = ICALS_query_from_ical(kc[0])
			if (it != null){
				$("#control_select_cttype_s4").val(it.cttype);
			}
		}
	}
	else if (model=="RPICT7V1"){
		if (allEqual(kc.slice(1,-1))){
			var it = ICALS_query_from_ical(kc[7])
			if (it != null){
				$("#control_select_cttype_s4").val(it.cttype);
			}
		}
		
		var it = VCALS_query_from_vcal(kc[0])
		if (it != null){
			$("#control_select_voltage_s4").val(it.vtype);
		}
	
	}
	else if (model=="RPICT4V3"){
		
		if (allEqual(kc.slice(3,-1))){
			console.log(kc.slice(3,-1));
			console.log("ok");
			var it = ICALS_query_from_ical(kc[7])
			if (it != null){
				$("#control_select_cttype_s4").val(it.cttype);
			}
		}
		
		if (allEqual(kc.slice(0,3))){
			console.log(kc.slice(0,3));
			var it = VCALS_query_from_vcal(kc[0])
			if (it != null){
				$("#control_select_voltage_s4").val(it.vtype);
			}
		}
	
	}
	
}

function disable_input(select_id, label_id){	
	document.getElementById(select_id).setAttribute("disabled","disabled");
	document.getElementById(label_id).style.color = "grey";
}

function enable_input(select_id, label_id){	
	document.getElementById(select_id).removeAttribute("disabled");
	document.getElementById(label_id).style.color = "black";
}


function update_m0_controls(){
	var rating = $("#control_select_cttype_m0").val();
	var vtype = $("#control_select_voltage_m0").val();
	var model = $("#control_m0_model").val();
	var hwversion = $("#control_m0_hwversion").val();
	
	if (model=="RPICT7V1"){
		enable_input("control_select_voltage_m0", "label_vtype_m0");
		$("#ControlInput_kcal_m0c0_label").html("<b>V1</b>");
		$("#ControlInput_kcal_m0c1_label").html("<b>CT7</b>");
		$("#ControlInput_kcal_m0c2_label").html("<b>CT6</b>");
		$("#ControlInput_kcal_m0c3_label").html("<b>CT5</b>");
		
		$("#header_m0_model").html("(RPICT7V1)");
		
		if (rating=="Custom"){
			enable_input("ControlInput_kcal_m0c1", "ControlInput_kcal_m0c1_label");
			enable_input("ControlInput_kcal_m0c2", "ControlInput_kcal_m0c2_label");
			enable_input("ControlInput_kcal_m0c3", "ControlInput_kcal_m0c3_label");
			enable_input("ControlInput_kcal_m0c4", "ControlInput_kcal_m0c4_label");
			enable_input("ControlInput_kcal_m0c5", "ControlInput_kcal_m0c5_label");
			enable_input("ControlInput_kcal_m0c6", "ControlInput_kcal_m0c6_label");
			enable_input("ControlInput_kcal_m0c7", "ControlInput_kcal_m0c7_label");
			
		}
		else{
			var ical = get_ical(rating, model, hwversion);
		
			$("#ControlInput_kcal_m0c1").val(ical);
			$("#ControlInput_kcal_m0c2").val(ical);
			$("#ControlInput_kcal_m0c3").val(ical);
			$("#ControlInput_kcal_m0c4").val(ical);
			$("#ControlInput_kcal_m0c5").val(ical);
			$("#ControlInput_kcal_m0c6").val(ical);
			$("#ControlInput_kcal_m0c7").val(ical);
			
			disable_input("ControlInput_kcal_m0c1", "ControlInput_kcal_m0c1_label");
			disable_input("ControlInput_kcal_m0c2", "ControlInput_kcal_m0c2_label");
			disable_input("ControlInput_kcal_m0c3", "ControlInput_kcal_m0c3_label");
			disable_input("ControlInput_kcal_m0c4", "ControlInput_kcal_m0c4_label");
			disable_input("ControlInput_kcal_m0c5", "ControlInput_kcal_m0c5_label");
			disable_input("ControlInput_kcal_m0c6", "ControlInput_kcal_m0c6_label");
			disable_input("ControlInput_kcal_m0c7", "ControlInput_kcal_m0c7_label");
		}
		
		if (vtype=="Custom"){
			enable_input("ControlInput_kcal_m0c0", "ControlInput_kcal_m0c0_label");
		}
		else {
			var vcal = get_vcal(vtype, model, hwversion);
			$("#ControlInput_kcal_m0c0").val(vcal);
			disable_input("ControlInput_kcal_m0c0", "ControlInput_kcal_m0c0_label");
		}
	}
	else if (model=="RPICT8"){
		disable_input("control_select_voltage_m0", "label_vtype_m0");
		$("#ControlInput_kcal_m0c0_label").html("<b>CT8</b>");
		$("#ControlInput_kcal_m0c1_label").html("<b>CT7</b>");
		$("#ControlInput_kcal_m0c2_label").html("<b>CT6</b>");
		$("#ControlInput_kcal_m0c3_label").html("<b>CT5</b>");
		
		$("#header_m0_model").html("(RPICT8)");
		
		if (rating=="Custom"){
			enable_input("ControlInput_kcal_m0c0", "ControlInput_kcal_m0c0_label");
			enable_input("ControlInput_kcal_m0c1", "ControlInput_kcal_m0c1_label");
			enable_input("ControlInput_kcal_m0c2", "ControlInput_kcal_m0c2_label");
			enable_input("ControlInput_kcal_m0c3", "ControlInput_kcal_m0c3_label");
			enable_input("ControlInput_kcal_m0c4", "ControlInput_kcal_m0c4_label");
			enable_input("ControlInput_kcal_m0c5", "ControlInput_kcal_m0c5_label");
			enable_input("ControlInput_kcal_m0c6", "ControlInput_kcal_m0c6_label");
			enable_input("ControlInput_kcal_m0c7", "ControlInput_kcal_m0c7_label");
			
		}
		else{
			var ical = get_ical(rating, model, hwversion);
			$("#ControlInput_kcal_m0c0").val(ical);
			$("#ControlInput_kcal_m0c1").val(ical);
			$("#ControlInput_kcal_m0c2").val(ical);
			$("#ControlInput_kcal_m0c3").val(ical);
			$("#ControlInput_kcal_m0c4").val(ical);
			$("#ControlInput_kcal_m0c5").val(ical);
			$("#ControlInput_kcal_m0c6").val(ical);
			$("#ControlInput_kcal_m0c7").val(ical);
			
			disable_input("ControlInput_kcal_m0c0", "ControlInput_kcal_m0c0_label");
			disable_input("ControlInput_kcal_m0c1", "ControlInput_kcal_m0c1_label");
			disable_input("ControlInput_kcal_m0c2", "ControlInput_kcal_m0c2_label");
			disable_input("ControlInput_kcal_m0c3", "ControlInput_kcal_m0c3_label");
			disable_input("ControlInput_kcal_m0c4", "ControlInput_kcal_m0c4_label");
			disable_input("ControlInput_kcal_m0c5", "ControlInput_kcal_m0c5_label");
			disable_input("ControlInput_kcal_m0c6", "ControlInput_kcal_m0c6_label");
			disable_input("ControlInput_kcal_m0c7", "ControlInput_kcal_m0c7_label");
		}
	}
	else if (model=="RPICT4V3"){
		enable_input("control_select_voltage_m0", "label_vtype_m0");
		$("#ControlInput_kcal_m0c0_label").html("<b>V3</b>");
		$("#ControlInput_kcal_m0c1_label").html("<b>V2</b>");
		$("#ControlInput_kcal_m0c2_label").html("<b>V1</b>");
		$("#ControlInput_kcal_m0c3_label").html("<b>-</b>");
		
		$("#header_m0_model").html("(RPICT4V3)");
		
		if (rating=="Custom"){
			$("#ControlInput_kcal_m0c3").val(1.0);
		
			disable_input("ControlInput_kcal_m0c3", "ControlInput_kcal_m0c3_label");
			enable_input("ControlInput_kcal_m0c4", "ControlInput_kcal_m0c4_label");
			enable_input("ControlInput_kcal_m0c5", "ControlInput_kcal_m0c5_label");
			enable_input("ControlInput_kcal_m0c6", "ControlInput_kcal_m0c6_label");
			enable_input("ControlInput_kcal_m0c7", "ControlInput_kcal_m0c7_label");
			
		}
		else{
			var ical = get_ical(rating, model, hwversion);
			
			$("#ControlInput_kcal_m0c3").val(1.0);
			$("#ControlInput_kcal_m0c4").val(ical);
			$("#ControlInput_kcal_m0c5").val(ical);
			$("#ControlInput_kcal_m0c6").val(ical);
			$("#ControlInput_kcal_m0c7").val(ical);
			
			disable_input("ControlInput_kcal_m0c3", "ControlInput_kcal_m0c3_label");
			disable_input("ControlInput_kcal_m0c4", "ControlInput_kcal_m0c4_label");
			disable_input("ControlInput_kcal_m0c5", "ControlInput_kcal_m0c5_label");
			disable_input("ControlInput_kcal_m0c6", "ControlInput_kcal_m0c6_label");
			disable_input("ControlInput_kcal_m0c7", "ControlInput_kcal_m0c7_label");
		}
		
		if (vtype=="Custom"){
			enable_input("ControlInput_kcal_m0c0", "ControlInput_kcal_m0c0_label");
			enable_input("ControlInput_kcal_m0c1", "ControlInput_kcal_m0c1_label");
			enable_input("ControlInput_kcal_m0c2", "ControlInput_kcal_m0c2_label");
		}
		else {
			var vcal = get_vcal(vtype, model, hwversion);
			$("#ControlInput_kcal_m0c0").val(vcal);
			$("#ControlInput_kcal_m0c1").val(vcal);
			$("#ControlInput_kcal_m0c2").val(vcal);
			disable_input("ControlInput_kcal_m0c0", "ControlInput_kcal_m0c0_label");
			disable_input("ControlInput_kcal_m0c1", "ControlInput_kcal_m0c1_label");
			disable_input("ControlInput_kcal_m0c2", "ControlInput_kcal_m0c2_label");
		}
	}
	
}


function update_s1_controls(){
	var rating = $("#control_select_cttype_s1").val();
	var vtype = $("#control_select_voltage_s1").val();
	var model = $("#control_s1_model").val();
	var hwversion = $("#control_s1_hwversion").val();
	
	if (model=="RPICT7V1"){
		enable_input("control_select_voltage_s1", "label_vtype_s1");
		$("#ControlInput_kcal_s1c0_label").html("<b>V1</b>");
		$("#ControlInput_kcal_s1c1_label").html("<b>CT7</b>");
		$("#ControlInput_kcal_s1c2_label").html("<b>CT6</b>");
		$("#ControlInput_kcal_s1c3_label").html("<b>CT5</b>");
		
		$("#header_s1_model").html("(RPICT7V1)");
		
		if (rating=="Custom"){
			enable_input("ControlInput_kcal_s1c1", "ControlInput_kcal_s1c1_label");
			enable_input("ControlInput_kcal_s1c2", "ControlInput_kcal_s1c2_label");
			enable_input("ControlInput_kcal_s1c3", "ControlInput_kcal_s1c3_label");
			enable_input("ControlInput_kcal_s1c4", "ControlInput_kcal_s1c4_label");
			enable_input("ControlInput_kcal_s1c5", "ControlInput_kcal_s1c5_label");
			enable_input("ControlInput_kcal_s1c6", "ControlInput_kcal_s1c6_label");
			enable_input("ControlInput_kcal_s1c7", "ControlInput_kcal_s1c7_label");
			
		}
		else{
			var ical = get_ical(rating, model, hwversion);
		
			$("#ControlInput_kcal_s1c1").val(ical);
			$("#ControlInput_kcal_s1c2").val(ical);
			$("#ControlInput_kcal_s1c3").val(ical);
			$("#ControlInput_kcal_s1c4").val(ical);
			$("#ControlInput_kcal_s1c5").val(ical);
			$("#ControlInput_kcal_s1c6").val(ical);
			$("#ControlInput_kcal_s1c7").val(ical);
			
			disable_input("ControlInput_kcal_s1c1", "ControlInput_kcal_s1c1_label");
			disable_input("ControlInput_kcal_s1c2", "ControlInput_kcal_s1c2_label");
			disable_input("ControlInput_kcal_s1c3", "ControlInput_kcal_s1c3_label");
			disable_input("ControlInput_kcal_s1c4", "ControlInput_kcal_s1c4_label");
			disable_input("ControlInput_kcal_s1c5", "ControlInput_kcal_s1c5_label");
			disable_input("ControlInput_kcal_s1c6", "ControlInput_kcal_s1c6_label");
			disable_input("ControlInput_kcal_s1c7", "ControlInput_kcal_s1c7_label");
		}
		
		if (vtype=="Custom"){
			enable_input("ControlInput_kcal_s1c0", "ControlInput_kcal_s1c0_label");
		}
		else {
			var vcal = get_vcal(vtype, model, hwversion);
			$("#ControlInput_kcal_s1c0").val(vcal);
			disable_input("ControlInput_kcal_s1c0", "ControlInput_kcal_s1c0_label");
		}
	}
	else if (model=="RPICT8"){
		disable_input("control_select_voltage_s1", "label_vtype_s1");
		$("#ControlInput_kcal_s1c0_label").html("<b>CT8</b>");
		$("#ControlInput_kcal_s1c1_label").html("<b>CT7</b>");
		$("#ControlInput_kcal_s1c2_label").html("<b>CT6</b>");
		$("#ControlInput_kcal_s1c3_label").html("<b>CT5</b>");
		
		$("#header_s1_model").html("(RPICT8)");
		
		if (rating=="Custom"){
			enable_input("ControlInput_kcal_s1c0", "ControlInput_kcal_s1c0_label");
			enable_input("ControlInput_kcal_s1c1", "ControlInput_kcal_s1c1_label");
			enable_input("ControlInput_kcal_s1c2", "ControlInput_kcal_s1c2_label");
			enable_input("ControlInput_kcal_s1c3", "ControlInput_kcal_s1c3_label");
			enable_input("ControlInput_kcal_s1c4", "ControlInput_kcal_s1c4_label");
			enable_input("ControlInput_kcal_s1c5", "ControlInput_kcal_s1c5_label");
			enable_input("ControlInput_kcal_s1c6", "ControlInput_kcal_s1c6_label");
			enable_input("ControlInput_kcal_s1c7", "ControlInput_kcal_s1c7_label");
			
		}
		else{
			var ical = get_ical(rating, model, hwversion);
			$("#ControlInput_kcal_s1c0").val(ical);
			$("#ControlInput_kcal_s1c1").val(ical);
			$("#ControlInput_kcal_s1c2").val(ical);
			$("#ControlInput_kcal_s1c3").val(ical);
			$("#ControlInput_kcal_s1c4").val(ical);
			$("#ControlInput_kcal_s1c5").val(ical);
			$("#ControlInput_kcal_s1c6").val(ical);
			$("#ControlInput_kcal_s1c7").val(ical);
			
			disable_input("ControlInput_kcal_s1c0", "ControlInput_kcal_s1c0_label");
			disable_input("ControlInput_kcal_s1c1", "ControlInput_kcal_s1c1_label");
			disable_input("ControlInput_kcal_s1c2", "ControlInput_kcal_s1c2_label");
			disable_input("ControlInput_kcal_s1c3", "ControlInput_kcal_s1c3_label");
			disable_input("ControlInput_kcal_s1c4", "ControlInput_kcal_s1c4_label");
			disable_input("ControlInput_kcal_s1c5", "ControlInput_kcal_s1c5_label");
			disable_input("ControlInput_kcal_s1c6", "ControlInput_kcal_s1c6_label");
			disable_input("ControlInput_kcal_s1c7", "ControlInput_kcal_s1c7_label");
		}
	}
	else if (model=="RPICT4V3"){
		enable_input("control_select_voltage_s1", "label_vtype_s1");
		$("#ControlInput_kcal_s1c0_label").html("<b>V3</b>");
		$("#ControlInput_kcal_s1c1_label").html("<b>V2</b>");
		$("#ControlInput_kcal_s1c2_label").html("<b>V1</b>");
		$("#ControlInput_kcal_s1c3_label").html("<b>-</b>");
		
		$("#header_s1_model").html("(RPICT4V3)");
		
		if (rating=="Custom"){
			$("#ControlInput_kcal_s1c3").val(1.0);
		
			disable_input("ControlInput_kcal_s1c3", "ControlInput_kcal_s1c3_label");
			enable_input("ControlInput_kcal_s1c4", "ControlInput_kcal_s1c4_label");
			enable_input("ControlInput_kcal_s1c5", "ControlInput_kcal_s1c5_label");
			enable_input("ControlInput_kcal_s1c6", "ControlInput_kcal_s1c6_label");
			enable_input("ControlInput_kcal_s1c7", "ControlInput_kcal_s1c7_label");
			
		}
		else{
			var ical = get_ical(rating, model, hwversion);
			
			$("#ControlInput_kcal_s1c3").val(1.0);
			$("#ControlInput_kcal_s1c4").val(ical);
			$("#ControlInput_kcal_s1c5").val(ical);
			$("#ControlInput_kcal_s1c6").val(ical);
			$("#ControlInput_kcal_s1c7").val(ical);
			
			disable_input("ControlInput_kcal_s1c3", "ControlInput_kcal_s1c3_label");
			disable_input("ControlInput_kcal_s1c4", "ControlInput_kcal_s1c4_label");
			disable_input("ControlInput_kcal_s1c5", "ControlInput_kcal_s1c5_label");
			disable_input("ControlInput_kcal_s1c6", "ControlInput_kcal_s1c6_label");
			disable_input("ControlInput_kcal_s1c7", "ControlInput_kcal_s1c7_label");
		}
		
		if (vtype=="Custom"){
			enable_input("ControlInput_kcal_s1c0", "ControlInput_kcal_s1c0_label");
			enable_input("ControlInput_kcal_s1c1", "ControlInput_kcal_s1c1_label");
			enable_input("ControlInput_kcal_s1c2", "ControlInput_kcal_s1c2_label");
		}
		else {
			var vcal = get_vcal(vtype, model, hwversion);
			$("#ControlInput_kcal_s1c0").val(vcal);
			$("#ControlInput_kcal_s1c1").val(vcal);
			$("#ControlInput_kcal_s1c2").val(vcal);
			disable_input("ControlInput_kcal_s1c0", "ControlInput_kcal_s1c0_label");
			disable_input("ControlInput_kcal_s1c1", "ControlInput_kcal_s1c1_label");
			disable_input("ControlInput_kcal_s1c2", "ControlInput_kcal_s1c2_label");
		}
	}
	
}

function update_s2_controls(){
	var rating = $("#control_select_cttype_s2").val();
	var vtype = $("#control_select_voltage_s2").val();
	var model = $("#control_s2_model").val();
	var hwversion = $("#control_s2_hwversion").val();
	
	if (model=="RPICT7V1"){
		enable_input("control_select_voltage_s2", "label_vtype_s2");
		$("#ControlInput_kcal_s2c0_label").html("<b>V1</b>");
		$("#ControlInput_kcal_s2c1_label").html("<b>CT7</b>");
		$("#ControlInput_kcal_s2c2_label").html("<b>CT6</b>");
		$("#ControlInput_kcal_s2c3_label").html("<b>CT5</b>");
		
		$("#header_s2_model").html("(RPICT7V1)");
		
		if (rating=="Custom"){
			enable_input("ControlInput_kcal_s2c1", "ControlInput_kcal_s2c1_label");
			enable_input("ControlInput_kcal_s2c2", "ControlInput_kcal_s2c2_label");
			enable_input("ControlInput_kcal_s2c3", "ControlInput_kcal_s2c3_label");
			enable_input("ControlInput_kcal_s2c4", "ControlInput_kcal_s2c4_label");
			enable_input("ControlInput_kcal_s2c5", "ControlInput_kcal_s2c5_label");
			enable_input("ControlInput_kcal_s2c6", "ControlInput_kcal_s2c6_label");
			enable_input("ControlInput_kcal_s2c7", "ControlInput_kcal_s2c7_label");
			
		}
		else{
			var ical = get_ical(rating, model, hwversion);
		
			$("#ControlInput_kcal_s2c1").val(ical);
			$("#ControlInput_kcal_s2c2").val(ical);
			$("#ControlInput_kcal_s2c3").val(ical);
			$("#ControlInput_kcal_s2c4").val(ical);
			$("#ControlInput_kcal_s2c5").val(ical);
			$("#ControlInput_kcal_s2c6").val(ical);
			$("#ControlInput_kcal_s2c7").val(ical);
			
			disable_input("ControlInput_kcal_s2c1", "ControlInput_kcal_s2c1_label");
			disable_input("ControlInput_kcal_s2c2", "ControlInput_kcal_s2c2_label");
			disable_input("ControlInput_kcal_s2c3", "ControlInput_kcal_s2c3_label");
			disable_input("ControlInput_kcal_s2c4", "ControlInput_kcal_s2c4_label");
			disable_input("ControlInput_kcal_s2c5", "ControlInput_kcal_s2c5_label");
			disable_input("ControlInput_kcal_s2c6", "ControlInput_kcal_s2c6_label");
			disable_input("ControlInput_kcal_s2c7", "ControlInput_kcal_s2c7_label");
		}
		
		if (vtype=="Custom"){
			enable_input("ControlInput_kcal_s2c0", "ControlInput_kcal_s2c0_label");
		}
		else {
			var vcal = get_vcal(vtype, model, hwversion);
			$("#ControlInput_kcal_s2c0").val(vcal);
			disable_input("ControlInput_kcal_s2c0", "ControlInput_kcal_s2c0_label");
		}
	}
	else if (model=="RPICT8"){
		disable_input("control_select_voltage_s2", "label_vtype_s2");
		$("#ControlInput_kcal_s2c0_label").html("<b>CT8</b>");
		$("#ControlInput_kcal_s2c1_label").html("<b>CT7</b>");
		$("#ControlInput_kcal_s2c2_label").html("<b>CT6</b>");
		$("#ControlInput_kcal_s2c3_label").html("<b>CT5</b>");
		
		$("#header_s2_model").html("(RPICT8)");
		
		if (rating=="Custom"){
			enable_input("ControlInput_kcal_s2c0", "ControlInput_kcal_s2c0_label");
			enable_input("ControlInput_kcal_s2c1", "ControlInput_kcal_s2c1_label");
			enable_input("ControlInput_kcal_s2c2", "ControlInput_kcal_s2c2_label");
			enable_input("ControlInput_kcal_s2c3", "ControlInput_kcal_s2c3_label");
			enable_input("ControlInput_kcal_s2c4", "ControlInput_kcal_s2c4_label");
			enable_input("ControlInput_kcal_s2c5", "ControlInput_kcal_s2c5_label");
			enable_input("ControlInput_kcal_s2c6", "ControlInput_kcal_s2c6_label");
			enable_input("ControlInput_kcal_s2c7", "ControlInput_kcal_s2c7_label");
			
		}
		else{
			var ical = get_ical(rating, model, hwversion);
			$("#ControlInput_kcal_s2c0").val(ical);
			$("#ControlInput_kcal_s2c1").val(ical);
			$("#ControlInput_kcal_s2c2").val(ical);
			$("#ControlInput_kcal_s2c3").val(ical);
			$("#ControlInput_kcal_s2c4").val(ical);
			$("#ControlInput_kcal_s2c5").val(ical);
			$("#ControlInput_kcal_s2c6").val(ical);
			$("#ControlInput_kcal_s2c7").val(ical);
			
			disable_input("ControlInput_kcal_s2c0", "ControlInput_kcal_s2c0_label");
			disable_input("ControlInput_kcal_s2c1", "ControlInput_kcal_s2c1_label");
			disable_input("ControlInput_kcal_s2c2", "ControlInput_kcal_s2c2_label");
			disable_input("ControlInput_kcal_s2c3", "ControlInput_kcal_s2c3_label");
			disable_input("ControlInput_kcal_s2c4", "ControlInput_kcal_s2c4_label");
			disable_input("ControlInput_kcal_s2c5", "ControlInput_kcal_s2c5_label");
			disable_input("ControlInput_kcal_s2c6", "ControlInput_kcal_s2c6_label");
			disable_input("ControlInput_kcal_s2c7", "ControlInput_kcal_s2c7_label");
		}
	}
	else if (model=="RPICT4V3"){
		enable_input("control_select_voltage_s2", "label_vtype_s2");
		$("#ControlInput_kcal_s2c0_label").html("<b>V3</b>");
		$("#ControlInput_kcal_s2c1_label").html("<b>V2</b>");
		$("#ControlInput_kcal_s2c2_label").html("<b>V1</b>");
		$("#ControlInput_kcal_s2c3_label").html("<b>-</b>");
		
		$("#header_s2_model").html("(RPICT4V3)");
		
		if (rating=="Custom"){
			$("#ControlInput_kcal_s2c3").val(1.0);
		
			disable_input("ControlInput_kcal_s2c3", "ControlInput_kcal_s2c3_label");
			enable_input("ControlInput_kcal_s2c4", "ControlInput_kcal_s2c4_label");
			enable_input("ControlInput_kcal_s2c5", "ControlInput_kcal_s2c5_label");
			enable_input("ControlInput_kcal_s2c6", "ControlInput_kcal_s2c6_label");
			enable_input("ControlInput_kcal_s2c7", "ControlInput_kcal_s2c7_label");
			
		}
		else{
			var ical = get_ical(rating, model, hwversion);
			
			$("#ControlInput_kcal_s2c3").val(1.0);
			$("#ControlInput_kcal_s2c4").val(ical);
			$("#ControlInput_kcal_s2c5").val(ical);
			$("#ControlInput_kcal_s2c6").val(ical);
			$("#ControlInput_kcal_s2c7").val(ical);
			
			disable_input("ControlInput_kcal_s2c3", "ControlInput_kcal_s2c3_label");
			disable_input("ControlInput_kcal_s2c4", "ControlInput_kcal_s2c4_label");
			disable_input("ControlInput_kcal_s2c5", "ControlInput_kcal_s2c5_label");
			disable_input("ControlInput_kcal_s2c6", "ControlInput_kcal_s2c6_label");
			disable_input("ControlInput_kcal_s2c7", "ControlInput_kcal_s2c7_label");
		}
		
		if (vtype=="Custom"){
			enable_input("ControlInput_kcal_s2c0", "ControlInput_kcal_s2c0_label");
			enable_input("ControlInput_kcal_s2c1", "ControlInput_kcal_s2c1_label");
			enable_input("ControlInput_kcal_s2c2", "ControlInput_kcal_s2c2_label");
		}
		else {
			var vcal = get_vcal(vtype, model, hwversion);
			$("#ControlInput_kcal_s2c0").val(vcal);
			$("#ControlInput_kcal_s2c1").val(vcal);
			$("#ControlInput_kcal_s2c2").val(vcal);
			disable_input("ControlInput_kcal_s2c0", "ControlInput_kcal_s2c0_label");
			disable_input("ControlInput_kcal_s2c1", "ControlInput_kcal_s2c1_label");
			disable_input("ControlInput_kcal_s2c2", "ControlInput_kcal_s2c2_label");
		}
	}
	
}

function update_s3_controls(){
	var rating = $("#control_select_cttype_s3").val();
	var vtype = $("#control_select_voltage_s3").val();
	var model = $("#control_s3_model").val();
	var hwversion = $("#control_s3_hwversion").val();
	
	if (model=="RPICT7V1"){
		enable_input("control_select_voltage_s3", "label_vtype_s3");
		$("#ControlInput_kcal_s3c0_label").html("<b>V1</b>");
		$("#ControlInput_kcal_s3c1_label").html("<b>CT7</b>");
		$("#ControlInput_kcal_s3c2_label").html("<b>CT6</b>");
		$("#ControlInput_kcal_s3c3_label").html("<b>CT5</b>");
		
		$("#header_s3_model").html("(RPICT7V1)");
		
		if (rating=="Custom"){
			enable_input("ControlInput_kcal_s3c1", "ControlInput_kcal_s3c1_label");
			enable_input("ControlInput_kcal_s3c2", "ControlInput_kcal_s3c2_label");
			enable_input("ControlInput_kcal_s3c3", "ControlInput_kcal_s3c3_label");
			enable_input("ControlInput_kcal_s3c4", "ControlInput_kcal_s3c4_label");
			enable_input("ControlInput_kcal_s3c5", "ControlInput_kcal_s3c5_label");
			enable_input("ControlInput_kcal_s3c6", "ControlInput_kcal_s3c6_label");
			enable_input("ControlInput_kcal_s3c7", "ControlInput_kcal_s3c7_label");
			
		}
		else{
			var ical = get_ical(rating, model, hwversion);
		
			$("#ControlInput_kcal_s3c1").val(ical);
			$("#ControlInput_kcal_s3c2").val(ical);
			$("#ControlInput_kcal_s3c3").val(ical);
			$("#ControlInput_kcal_s3c4").val(ical);
			$("#ControlInput_kcal_s3c5").val(ical);
			$("#ControlInput_kcal_s3c6").val(ical);
			$("#ControlInput_kcal_s3c7").val(ical);
			
			disable_input("ControlInput_kcal_s3c1", "ControlInput_kcal_s3c1_label");
			disable_input("ControlInput_kcal_s3c2", "ControlInput_kcal_s3c2_label");
			disable_input("ControlInput_kcal_s3c3", "ControlInput_kcal_s3c3_label");
			disable_input("ControlInput_kcal_s3c4", "ControlInput_kcal_s3c4_label");
			disable_input("ControlInput_kcal_s3c5", "ControlInput_kcal_s3c5_label");
			disable_input("ControlInput_kcal_s3c6", "ControlInput_kcal_s3c6_label");
			disable_input("ControlInput_kcal_s3c7", "ControlInput_kcal_s3c7_label");
		}
		
		if (vtype=="Custom"){
			enable_input("ControlInput_kcal_s3c0", "ControlInput_kcal_s3c0_label");
		}
		else {
			var vcal = get_vcal(vtype, model, hwversion);
			$("#ControlInput_kcal_s3c0").val(vcal);
			disable_input("ControlInput_kcal_s3c0", "ControlInput_kcal_s3c0_label");
		}
	}
	else if (model=="RPICT8"){
		disable_input("control_select_voltage_s3", "label_vtype_s3");
		$("#ControlInput_kcal_s3c0_label").html("<b>CT8</b>");
		$("#ControlInput_kcal_s3c1_label").html("<b>CT7</b>");
		$("#ControlInput_kcal_s3c2_label").html("<b>CT6</b>");
		$("#ControlInput_kcal_s3c3_label").html("<b>CT5</b>");
		
		$("#header_s3_model").html("(RPICT8)");
		
		if (rating=="Custom"){
			enable_input("ControlInput_kcal_s3c0", "ControlInput_kcal_s3c0_label");
			enable_input("ControlInput_kcal_s3c1", "ControlInput_kcal_s3c1_label");
			enable_input("ControlInput_kcal_s3c2", "ControlInput_kcal_s3c2_label");
			enable_input("ControlInput_kcal_s3c3", "ControlInput_kcal_s3c3_label");
			enable_input("ControlInput_kcal_s3c4", "ControlInput_kcal_s3c4_label");
			enable_input("ControlInput_kcal_s3c5", "ControlInput_kcal_s3c5_label");
			enable_input("ControlInput_kcal_s3c6", "ControlInput_kcal_s3c6_label");
			enable_input("ControlInput_kcal_s3c7", "ControlInput_kcal_s3c7_label");
			
		}
		else{
			var ical = get_ical(rating, model, hwversion);
			$("#ControlInput_kcal_s3c0").val(ical);
			$("#ControlInput_kcal_s3c1").val(ical);
			$("#ControlInput_kcal_s3c2").val(ical);
			$("#ControlInput_kcal_s3c3").val(ical);
			$("#ControlInput_kcal_s3c4").val(ical);
			$("#ControlInput_kcal_s3c5").val(ical);
			$("#ControlInput_kcal_s3c6").val(ical);
			$("#ControlInput_kcal_s3c7").val(ical);
			
			disable_input("ControlInput_kcal_s3c0", "ControlInput_kcal_s3c0_label");
			disable_input("ControlInput_kcal_s3c1", "ControlInput_kcal_s3c1_label");
			disable_input("ControlInput_kcal_s3c2", "ControlInput_kcal_s3c2_label");
			disable_input("ControlInput_kcal_s3c3", "ControlInput_kcal_s3c3_label");
			disable_input("ControlInput_kcal_s3c4", "ControlInput_kcal_s3c4_label");
			disable_input("ControlInput_kcal_s3c5", "ControlInput_kcal_s3c5_label");
			disable_input("ControlInput_kcal_s3c6", "ControlInput_kcal_s3c6_label");
			disable_input("ControlInput_kcal_s3c7", "ControlInput_kcal_s3c7_label");
		}
	}
	else if (model=="RPICT4V3"){
		enable_input("control_select_voltage_s3", "label_vtype_s3");
		$("#ControlInput_kcal_s3c0_label").html("<b>V3</b>");
		$("#ControlInput_kcal_s3c1_label").html("<b>V2</b>");
		$("#ControlInput_kcal_s3c2_label").html("<b>V1</b>");
		$("#ControlInput_kcal_s3c3_label").html("<b>-</b>");
		
		$("#header_s3_model").html("(RPICT4V3)");
		
		if (rating=="Custom"){
			$("#ControlInput_kcal_s3c3").val(1.0);
		
			disable_input("ControlInput_kcal_s3c3", "ControlInput_kcal_s3c3_label");
			enable_input("ControlInput_kcal_s3c4", "ControlInput_kcal_s3c4_label");
			enable_input("ControlInput_kcal_s3c5", "ControlInput_kcal_s3c5_label");
			enable_input("ControlInput_kcal_s3c6", "ControlInput_kcal_s3c6_label");
			enable_input("ControlInput_kcal_s3c7", "ControlInput_kcal_s3c7_label");
			
		}
		else{
			var ical = get_ical(rating, model, hwversion);
			
			$("#ControlInput_kcal_s3c3").val(1.0);
			$("#ControlInput_kcal_s3c4").val(ical);
			$("#ControlInput_kcal_s3c5").val(ical);
			$("#ControlInput_kcal_s3c6").val(ical);
			$("#ControlInput_kcal_s3c7").val(ical);
			
			disable_input("ControlInput_kcal_s3c3", "ControlInput_kcal_s3c3_label");
			disable_input("ControlInput_kcal_s3c4", "ControlInput_kcal_s3c4_label");
			disable_input("ControlInput_kcal_s3c5", "ControlInput_kcal_s3c5_label");
			disable_input("ControlInput_kcal_s3c6", "ControlInput_kcal_s3c6_label");
			disable_input("ControlInput_kcal_s3c7", "ControlInput_kcal_s3c7_label");
		}
		
		if (vtype=="Custom"){
			enable_input("ControlInput_kcal_s3c0", "ControlInput_kcal_s3c0_label");
			enable_input("ControlInput_kcal_s3c1", "ControlInput_kcal_s3c1_label");
			enable_input("ControlInput_kcal_s3c2", "ControlInput_kcal_s3c2_label");
		}
		else {
			var vcal = get_vcal(vtype, model, hwversion);
			$("#ControlInput_kcal_s3c0").val(vcal);
			$("#ControlInput_kcal_s3c1").val(vcal);
			$("#ControlInput_kcal_s3c2").val(vcal);
			disable_input("ControlInput_kcal_s3c0", "ControlInput_kcal_s3c0_label");
			disable_input("ControlInput_kcal_s3c1", "ControlInput_kcal_s3c1_label");
			disable_input("ControlInput_kcal_s3c2", "ControlInput_kcal_s3c2_label");
		}
	}
	
}

function update_s4_controls(){
	var rating = $("#control_select_cttype_s4").val();
	var vtype = $("#control_select_voltage_s4").val();
	var model = $("#control_s4_model").val();
	var hwversion = $("#control_s4_hwversion").val();
	
	if (model=="RPICT7V1"){
		enable_input("control_select_voltage_s4", "label_vtype_s4");
		$("#ControlInput_kcal_s4c0_label").html("<b>V1</b>");
		$("#ControlInput_kcal_s4c1_label").html("<b>CT7</b>");
		$("#ControlInput_kcal_s4c2_label").html("<b>CT6</b>");
		$("#ControlInput_kcal_s4c3_label").html("<b>CT5</b>");
		
		$("#header_s4_model").html("(RPICT7V1)");
		
		if (rating=="Custom"){
			enable_input("ControlInput_kcal_s4c1", "ControlInput_kcal_s4c1_label");
			enable_input("ControlInput_kcal_s4c2", "ControlInput_kcal_s4c2_label");
			enable_input("ControlInput_kcal_s4c3", "ControlInput_kcal_s4c3_label");
			enable_input("ControlInput_kcal_s4c4", "ControlInput_kcal_s4c4_label");
			enable_input("ControlInput_kcal_s4c5", "ControlInput_kcal_s4c5_label");
			enable_input("ControlInput_kcal_s4c6", "ControlInput_kcal_s4c6_label");
			enable_input("ControlInput_kcal_s4c7", "ControlInput_kcal_s4c7_label");
			
		}
		else{
			var ical = get_ical(rating, model, hwversion);
		
			$("#ControlInput_kcal_s4c1").val(ical);
			$("#ControlInput_kcal_s4c2").val(ical);
			$("#ControlInput_kcal_s4c3").val(ical);
			$("#ControlInput_kcal_s4c4").val(ical);
			$("#ControlInput_kcal_s4c5").val(ical);
			$("#ControlInput_kcal_s4c6").val(ical);
			$("#ControlInput_kcal_s4c7").val(ical);
			
			disable_input("ControlInput_kcal_s4c1", "ControlInput_kcal_s4c1_label");
			disable_input("ControlInput_kcal_s4c2", "ControlInput_kcal_s4c2_label");
			disable_input("ControlInput_kcal_s4c3", "ControlInput_kcal_s4c3_label");
			disable_input("ControlInput_kcal_s4c4", "ControlInput_kcal_s4c4_label");
			disable_input("ControlInput_kcal_s4c5", "ControlInput_kcal_s4c5_label");
			disable_input("ControlInput_kcal_s4c6", "ControlInput_kcal_s4c6_label");
			disable_input("ControlInput_kcal_s4c7", "ControlInput_kcal_s4c7_label");
		}
		
		if (vtype=="Custom"){
			enable_input("ControlInput_kcal_s4c0", "ControlInput_kcal_s4c0_label");
		}
		else {
			var vcal = get_vcal(vtype, model, hwversion);
			$("#ControlInput_kcal_s4c0").val(vcal);
			disable_input("ControlInput_kcal_s4c0", "ControlInput_kcal_s4c0_label");
		}
	}
	else if (model=="RPICT8"){
		disable_input("control_select_voltage_s4", "label_vtype_s4");
		$("#ControlInput_kcal_s4c0_label").html("<b>CT8</b>");
		$("#ControlInput_kcal_s4c1_label").html("<b>CT7</b>");
		$("#ControlInput_kcal_s4c2_label").html("<b>CT6</b>");
		$("#ControlInput_kcal_s4c3_label").html("<b>CT5</b>");
		
		$("#header_s4_model").html("(RPICT8)");
		
		if (rating=="Custom"){
			enable_input("ControlInput_kcal_s4c0", "ControlInput_kcal_s4c0_label");
			enable_input("ControlInput_kcal_s4c1", "ControlInput_kcal_s4c1_label");
			enable_input("ControlInput_kcal_s4c2", "ControlInput_kcal_s4c2_label");
			enable_input("ControlInput_kcal_s4c3", "ControlInput_kcal_s4c3_label");
			enable_input("ControlInput_kcal_s4c4", "ControlInput_kcal_s4c4_label");
			enable_input("ControlInput_kcal_s4c5", "ControlInput_kcal_s4c5_label");
			enable_input("ControlInput_kcal_s4c6", "ControlInput_kcal_s4c6_label");
			enable_input("ControlInput_kcal_s4c7", "ControlInput_kcal_s4c7_label");
			
		}
		else{
			var ical = get_ical(rating, model, hwversion);
			$("#ControlInput_kcal_s4c0").val(ical);
			$("#ControlInput_kcal_s4c1").val(ical);
			$("#ControlInput_kcal_s4c2").val(ical);
			$("#ControlInput_kcal_s4c3").val(ical);
			$("#ControlInput_kcal_s4c4").val(ical);
			$("#ControlInput_kcal_s4c5").val(ical);
			$("#ControlInput_kcal_s4c6").val(ical);
			$("#ControlInput_kcal_s4c7").val(ical);
			
			disable_input("ControlInput_kcal_s4c0", "ControlInput_kcal_s4c0_label");
			disable_input("ControlInput_kcal_s4c1", "ControlInput_kcal_s4c1_label");
			disable_input("ControlInput_kcal_s4c2", "ControlInput_kcal_s4c2_label");
			disable_input("ControlInput_kcal_s4c3", "ControlInput_kcal_s4c3_label");
			disable_input("ControlInput_kcal_s4c4", "ControlInput_kcal_s4c4_label");
			disable_input("ControlInput_kcal_s4c5", "ControlInput_kcal_s4c5_label");
			disable_input("ControlInput_kcal_s4c6", "ControlInput_kcal_s4c6_label");
			disable_input("ControlInput_kcal_s4c7", "ControlInput_kcal_s4c7_label");
		}
	}
	else if (model=="RPICT4V3"){
		enable_input("control_select_voltage_s4", "label_vtype_s4");
		$("#ControlInput_kcal_s4c0_label").html("<b>V3</b>");
		$("#ControlInput_kcal_s4c1_label").html("<b>V2</b>");
		$("#ControlInput_kcal_s4c2_label").html("<b>V1</b>");
		$("#ControlInput_kcal_s4c3_label").html("<b>-</b>");
		
		$("#header_s4_model").html("(RPICT4V3)");
		
		if (rating=="Custom"){
			$("#ControlInput_kcal_s4c3").val(1.0);
		
			disable_input("ControlInput_kcal_s4c3", "ControlInput_kcal_s4c3_label");
			enable_input("ControlInput_kcal_s4c4", "ControlInput_kcal_s4c4_label");
			enable_input("ControlInput_kcal_s4c5", "ControlInput_kcal_s4c5_label");
			enable_input("ControlInput_kcal_s4c6", "ControlInput_kcal_s4c6_label");
			enable_input("ControlInput_kcal_s4c7", "ControlInput_kcal_s4c7_label");
			
		}
		else{
			var ical = get_ical(rating, model, hwversion);
			
			$("#ControlInput_kcal_s4c3").val(1.0);
			$("#ControlInput_kcal_s4c4").val(ical);
			$("#ControlInput_kcal_s4c5").val(ical);
			$("#ControlInput_kcal_s4c6").val(ical);
			$("#ControlInput_kcal_s4c7").val(ical);
			
			disable_input("ControlInput_kcal_s4c3", "ControlInput_kcal_s4c3_label");
			disable_input("ControlInput_kcal_s4c4", "ControlInput_kcal_s4c4_label");
			disable_input("ControlInput_kcal_s4c5", "ControlInput_kcal_s4c5_label");
			disable_input("ControlInput_kcal_s4c6", "ControlInput_kcal_s4c6_label");
			disable_input("ControlInput_kcal_s4c7", "ControlInput_kcal_s4c7_label");
		}
		
		if (vtype=="Custom"){
			enable_input("ControlInput_kcal_s4c0", "ControlInput_kcal_s4c0_label");
			enable_input("ControlInput_kcal_s4c1", "ControlInput_kcal_s4c1_label");
			enable_input("ControlInput_kcal_s4c2", "ControlInput_kcal_s4c2_label");
		}
		else {
			var vcal = get_vcal(vtype, model, hwversion);
			$("#ControlInput_kcal_s4c0").val(vcal);
			$("#ControlInput_kcal_s4c1").val(vcal);
			$("#ControlInput_kcal_s4c2").val(vcal);
			disable_input("ControlInput_kcal_s4c0", "ControlInput_kcal_s4c0_label");
			disable_input("ControlInput_kcal_s4c1", "ControlInput_kcal_s4c1_label");
			disable_input("ControlInput_kcal_s4c2", "ControlInput_kcal_s4c2_label");
		}
	}
	
}


function validate_form(){
	var tnode_table = document.getElementById("tnode_table");
	if ((tnode_table.rows.length-2)%3!=0){
		document.getElementById("response").innerHTML = '<span style="color:red">Three Phase Nodes must have a multiple of 3 entries.<br>Add or remove items from the list and submit again.</span>';
		return false;
	}
	return true;
}


function send_button_clicked(){	
	if (validate_form()){
		post_data();
	}
}


function ControlSelectFormat_changed(){
	generate_config();
}

function ControlInputNid_changed(){
	generate_config();
}

function ControlInputOrate_changed(){
	generate_config();
}

function ControlInputPhasecal_changed(){
	generate_config();
}

function ControlInputNcycle_changed(){
	generate_config();
}

function ControlInputVest_changed(){
	generate_config();
}	

function ControlInputXpfreq_changed(){
	generate_config();
}


function ControlCheckBoxDebug_changed(){
	//console.log(document.getElementById("ControlCheckBoxDebug").checked);
	generate_config();
}


function control_select_cttype_m0_changed(){
	update_m0_controls();
	generate_config();
}

function control_m0_model_changed(){
	update_m0_controls();
	update_select_port_names("snode_port", "snode_level", "any", "btn_snode");
	update_select_port_names("pnode_portI", "pnode_levelI", "current", "btn_pnode");
	update_select_port_names("pnode_portV", "pnode_levelV", "voltage", "btn_pnode");
	update_select_port_names("tnode_portI", "tnode_levelI", "current", "btn_tnode");
	update_select_port_names("tnode_portV", "tnode_levelV", "voltage", "btn_tnode");
	update_select_port_names("fnode_port", "fnode_level", "any", "btn_fnode");
	update_snode_table();
	update_pnode_table();
	update_tnode_table();
	
	generate_config();
	
}

function control_select_voltage_m0_changed(){
	update_m0_controls();
	generate_config();
}

function control_m0_hwversion_changed(){
	update_m0_controls();
	generate_config();
}

function control_select_cttype_s1_changed(){
	update_s1_controls();
	generate_config();
}

function control_s1_model_changed(){
	update_s1_controls();
	update_select_port_names("snode_port", "snode_level", "any", "btn_snode");
	update_select_port_names("pnode_portI", "pnode_levelI", "current", "btn_pnode");
	update_select_port_names("pnode_portV", "pnode_levelV", "voltage", "btn_pnode");
	update_select_port_names("tnode_portI", "tnode_levelI", "current", "btn_tnode");
	update_select_port_names("tnode_portV", "tnode_levelV", "voltage", "btn_tnode");
	update_select_port_names("fnode_port", "fnode_level", "any", "btn_fnode");
	update_snode_table();
	update_pnode_table();
	update_tnode_table();
	update_fnode_table();
	
	generate_config();	
}

function control_select_voltage_s1_changed(){
	update_s1_controls();
	generate_config();
}

function control_s1_hwversion_changed(){
	update_s1_controls();
	generate_config();
}

function control_select_cttype_s2_changed(){
	update_s2_controls();
	generate_config();
}

function control_s2_model_changed(){
	update_s2_controls();
	update_select_port_names("snode_port", "snode_level", "any", "btn_snode");
	update_select_port_names("pnode_portI", "pnode_levelI", "current", "btn_pnode");
	update_select_port_names("pnode_portV", "pnode_levelV", "voltage", "btn_pnode");
	update_select_port_names("tnode_portI", "tnode_levelI", "current", "btn_tnode");
	update_select_port_names("tnode_portV", "tnode_levelV", "voltage", "btn_tnode");
	update_select_port_names("fnode_port", "fnode_level", "any", "btn_fnode");
	update_snode_table();
	update_pnode_table();	
	update_tnode_table();
	update_fnode_table();
	
	generate_config();
}

function control_select_voltage_s2_changed(){
	update_s2_controls();
	generate_config();
}

function control_s2_hwversion_changed(){
	update_s2_controls();
	generate_config();
}

function control_select_cttype_s3_changed(){
	update_s3_controls();
	generate_config();
}

function control_s3_model_changed(){
	update_s3_controls();
	update_select_port_names("snode_port", "snode_level", "any", "btn_snode");
	update_select_port_names("pnode_portI", "pnode_levelI", "current", "btn_pnode");
	update_select_port_names("pnode_portV", "pnode_levelV", "voltage", "btn_pnode");
	update_select_port_names("tnode_portI", "tnode_levelI", "current", "btn_tnode");
	update_select_port_names("tnode_portV", "tnode_levelV", "voltage", "btn_tnode");
	update_select_port_names("fnode_port", "fnode_level", "any", "btn_fnode");
	update_snode_table();
	update_pnode_table();
	update_tnode_table();
	update_fnode_table();
	
	generate_config();
}

function control_select_voltage_s3_changed(){
	update_s3_controls();
	generate_config();
}

function control_s3_hwversion_changed(){
	update_s3_controls();
	generate_config();
}

function control_select_cttype_s4_changed(){
	update_s4_controls();
	generate_config();
}

function control_s4_model_changed(){
	update_s4_controls();
	update_select_port_names("snode_port", "snode_level", "any", "btn_snode");
	update_select_port_names("pnode_portI", "pnode_levelI", "current", "btn_pnode");
	update_select_port_names("pnode_portV", "pnode_levelV", "voltage", "btn_pnode");
	update_select_port_names("tnode_portI", "tnode_levelI", "current", "btn_tnode");
	update_select_port_names("tnode_portV", "tnode_levelV", "voltage", "btn_tnode");
	update_select_port_names("fnode_port", "fnode_level", "any", "btn_fnode");
	update_snode_table();
	update_pnode_table();	
	update_tnode_table();
	update_fnode_table();
	
	generate_config();
}

function control_select_voltage_s4_changed(){
	update_s4_controls();
	generate_config();
}

function control_s4_hwversion_changed(){
	update_s4_controls();
	generate_config();
}

function snode_level_changed(){
	update_select_port_names("snode_port", "snode_level", "any", "btn_snode");
}

function pnode_levelI_changed(){
	update_select_port_names("pnode_portI", "pnode_levelI", "current", "btn_pnode");
}

function pnode_levelV_changed(){
	update_select_port_names("pnode_portV", "pnode_levelV", "voltage", "btn_pnode");
}

function tnode_levelI_changed(){
	update_select_port_names("tnode_portI", "tnode_levelI", "current", "btn_tnode");
}

function tnode_levelV_changed(){
	update_select_port_names("tnode_portV", "tnode_levelV", "voltage", "btn_tnode");
}
function fnode_level_changed(){
	update_select_port_names("fnode_port", "fnode_level", "any", "btn_fnode");
}

function control_node_type_changed(){
	update_output_channels_controls();
}


function control_number_slave_changed(genconf){


	//var nslaves = document.getElementById("control_number_slave").value;
	var nslaves = $("#control_number_slave").val();
	
	var snode_op = document.getElementById("snode_level").getElementsByTagName("option");
	var pnode_opI = document.getElementById("pnode_levelI").getElementsByTagName("option");
	var pnode_opV = document.getElementById("pnode_levelV").getElementsByTagName("option");
	var tnode_opI = document.getElementById("tnode_levelI").getElementsByTagName("option");
	var tnode_opV = document.getElementById("tnode_levelV").getElementsByTagName("option");
	var fnode_op = document.getElementById("fnode_level").getElementsByTagName("option");
	
	if (nslaves==0){
		
		$("#s1_kcal_card").hide();
		$("#s2_kcal_card").hide();
		$("#s3_kcal_card").hide();
		$("#s4_kcal_card").hide();
		
		
		snode_op[1].disabled = true;
		snode_op[2].disabled = true;
		snode_op[3].disabled = true;
		snode_op[4].disabled = true;
		pnode_opI[1].disabled = true;
		pnode_opI[2].disabled = true;
		pnode_opI[3].disabled = true;
		pnode_opI[4].disabled = true;
		pnode_opV[1].disabled = true;
		pnode_opV[2].disabled = true;
		pnode_opV[3].disabled = true;
		pnode_opV[4].disabled = true;
		tnode_opI[1].disabled = true;
		tnode_opI[2].disabled = true;
		tnode_opI[3].disabled = true;
		tnode_opI[4].disabled = true;
		tnode_opV[1].disabled = true;
		tnode_opV[2].disabled = true;
		tnode_opV[3].disabled = true;
		tnode_opV[4].disabled = true;
		fnode_op[1].disabled = true;
		fnode_op[2].disabled = true;
		fnode_op[3].disabled = true;
		fnode_op[4].disabled = true;
		
	}
	else if (nslaves==1){

		
		$("#s1_kcal_card").show();
		$("#s2_kcal_card").hide();
		$("#s3_kcal_card").hide();
		$("#s4_kcal_card").hide();
		
		snode_op[1].disabled = false;
		snode_op[2].disabled = true;
		snode_op[3].disabled = true;
		snode_op[4].disabled = true;
		pnode_opI[1].disabled = false;
		pnode_opI[2].disabled = true;
		pnode_opI[3].disabled = true;
		pnode_opI[4].disabled = true;
		pnode_opV[1].disabled = false;
		pnode_opV[2].disabled = true;
		pnode_opV[3].disabled = true;
		pnode_opV[4].disabled = true;
		tnode_opI[1].disabled = false;
		tnode_opI[2].disabled = true;
		tnode_opI[3].disabled = true;
		tnode_opI[4].disabled = true;
		tnode_opV[1].disabled = false;
		tnode_opV[2].disabled = true;
		tnode_opV[3].disabled = true;
		tnode_opV[4].disabled = true;
		fnode_op[1].disabled = false;
		fnode_op[2].disabled = true;
		fnode_op[3].disabled = true;
		fnode_op[4].disabled = true;
		
		
	}
	else if (nslaves==2){

		
		$("#s1_kcal_card").show();
		$("#s2_kcal_card").show();
		$("#s3_kcal_card").hide();
		$("#s4_kcal_card").hide();
		
		snode_op[1].disabled = false;
		snode_op[2].disabled = false;
		snode_op[3].disabled = true;
		snode_op[4].disabled = true;
		pnode_opI[1].disabled = false;
		pnode_opI[2].disabled = false;
		pnode_opI[3].disabled = true;
		pnode_opI[4].disabled = true;
		pnode_opV[1].disabled = false;
		pnode_opV[2].disabled = false;
		pnode_opV[3].disabled = true;
		pnode_opV[4].disabled = true;
		tnode_opI[1].disabled = false;
		tnode_opI[2].disabled = false;
		tnode_opI[3].disabled = true;
		tnode_opI[4].disabled = true;
		tnode_opV[1].disabled = false;
		tnode_opV[2].disabled = false;
		tnode_opV[3].disabled = true;
		tnode_opV[4].disabled = true;
		fnode_op[1].disabled = false;
		fnode_op[2].disabled = false;
		fnode_op[3].disabled = true;
		fnode_op[4].disabled = true;
	}
	else if (nslaves==3){

		
		$("#s1_kcal_card").show();
		$("#s2_kcal_card").show();
		$("#s3_kcal_card").show();
		$("#s4_kcal_card").hide();
		
		snode_op[1].disabled = false;
		snode_op[2].disabled = false;
		snode_op[3].disabled = false;
		snode_op[4].disabled = true;
		pnode_opI[1].disabled = false;
		pnode_opI[2].disabled = false;
		pnode_opI[3].disabled = false;
		pnode_opI[4].disabled = true;
		pnode_opV[1].disabled = false;
		pnode_opV[2].disabled = false;
		pnode_opV[3].disabled = false;
		pnode_opV[4].disabled = true;
		tnode_opI[1].disabled = false;
		tnode_opI[2].disabled = false;
		tnode_opI[3].disabled = false;
		tnode_opI[4].disabled = true;
		tnode_opV[1].disabled = false;
		tnode_opV[2].disabled = false;
		tnode_opV[3].disabled = false;
		tnode_opV[4].disabled = true;
		fnode_op[1].disabled = false;
		fnode_op[2].disabled = false;
		fnode_op[3].disabled = false;
		fnode_op[4].disabled = true;
	}
	else if (nslaves==4){

		
		$("#s1_kcal_card").show();
		$("#s2_kcal_card").show();
		$("#s3_kcal_card").show();
		$("#s4_kcal_card").show();
		
		snode_op[1].disabled = false;
		snode_op[2].disabled = false;
		snode_op[3].disabled = false;
		snode_op[4].disabled = false;
		pnode_opI[1].disabled = false;
		pnode_opI[2].disabled = false;
		pnode_opI[3].disabled = false;
		pnode_opI[4].disabled = false;
		pnode_opV[1].disabled = false;
		pnode_opV[2].disabled = false;
		pnode_opV[3].disabled = false;
		pnode_opV[4].disabled = false;
		tnode_opI[1].disabled = false;
		tnode_opI[2].disabled = false;
		tnode_opI[3].disabled = false;
		tnode_opI[4].disabled = false;
		tnode_opV[1].disabled = false;
		tnode_opV[2].disabled = false;
		tnode_opV[3].disabled = false;
		tnode_opV[4].disabled = false;
		fnode_op[1].disabled = false;
		fnode_op[2].disabled = false;
		fnode_op[3].disabled = false;
		fnode_op[4].disabled = false;
	}
	
	if (genconf) generate_config();
	
}


function model_from_level(level){
	var model;
	
	if (level==10){
		model = document.getElementById("control_m0_model").value;
	}
	else if (level==6){
		model = document.getElementById("control_s1_model").value;
	}
	else if (level==7){
		model = document.getElementById("control_s2_model").value;
	}
	else if (level==8){
		model = document.getElementById("control_s3_model").value;
	}
	else if (level==9){
		model = document.getElementById("control_s4_model").value;
	}
	else model = "Err";
	
	//console.log("Function model_from_level");
	//console.log("level: "+level+" model: "+model);
	
	return model;
}

function get_port_name(port, model){

	if (model=="RPICT8"){
		if (port=="0") return "CT8";	
		else if (port=="1") return "CT7";
		else if (port=="2") return "CT6";
		else if (port=="3") return "CT5";
		else if (port=="4") return "CT4";
		else if (port=="5") return "CT3";
		else if (port=="6") return "CT2";
		else if (port=="7") return "CT1";
	}
	else if (model=="RPICT7V1"){
		if (port=="0") return "V1";	
		else if (port=="1") return "CT7";
		else if (port=="2") return "CT6";
		else if (port=="3") return "CT5";
		else if (port=="4") return "CT4";
		else if (port=="5") return "CT3";
		else if (port=="6") return "CT2";
		else if (port=="7") return "CT1";
	}
	else if (model=="RPICT4V3"){
		if (port=="0") return "V3";	
		else if (port=="1") return "V2";
		else if (port=="2") return "V1";
		else if (port=="3") return "-";
		else if (port=="4") return "CT4";
		else if (port=="5") return "CT3";
		else if (port=="6") return "CT2";
		else if (port=="7") return "CT1";
	}
	else return "Err";

}

function update_snode_table(){
	var level, port, model, name;
	var table = document.getElementById("snode_table");
	for (i=2; i<table.rows.length; i++){
		port = table.rows[i].cells[4].innerHTML;
		level = table.rows[i].cells[5].innerHTML;
    		model = model_from_level(level);
		name = get_port_name(port, model)
		table.rows[i].cells[1].innerHTML = name;
    	}
}

function update_pnode_table(){
	var level, port, model, name;
	var table = document.getElementById("pnode_table");
	for (i=2; i<table.rows.length; i++){
		port = table.rows[i].cells[6].innerHTML;
		level = table.rows[i].cells[7].innerHTML;
    		model = model_from_level(level);
		name = get_port_name(port, model)
		table.rows[i].cells[1].innerHTML = name;
		
		port = table.rows[i].cells[8].innerHTML;
		level = table.rows[i].cells[9].innerHTML;
    		model = model_from_level(level);
		name = get_port_name(port, model)
		table.rows[i].cells[3].innerHTML = name;
    	}
}

function update_tnode_table(){
	var level, port, model, name;
	var table = document.getElementById("tnode_table");
	for (i=2; i<table.rows.length; i++){
		port = table.rows[i].cells[7].innerHTML;
		level = table.rows[i].cells[8].innerHTML;
    		model = model_from_level(level);
		name = get_port_name(port, model)
		table.rows[i].cells[2].innerHTML = name;
		
		port = table.rows[i].cells[9].innerHTML;
		level = table.rows[i].cells[10].innerHTML;
    		model = model_from_level(level);
		name = get_port_name(port, model)
		table.rows[i].cells[4].innerHTML = name;
    	}
}

function update_fnode_table(){
	var level, port, model, name;
	var table = document.getElementById("fnode_table");
	for (i=2; i<table.rows.length; i++){
		port = table.rows[i].cells[4].innerHTML;
		level = table.rows[i].cells[5].innerHTML;
    		model = model_from_level(level);
		name = get_port_name(port, model)
		table.rows[i].cells[1].innerHTML = name;
    	}
}

function update_output_channels_table(){
	var oc_table = document.getElementById("output_channels_table");
	var stable = document.getElementById("snode_table");
	var ptable = document.getElementById("pnode_table");
	var ttable = document.getElementById("tnode_table");
	var ftable = document.getElementById("fnode_table");
	var text, idx, index;
	
	for (var i=2; i<oc_table.rows.length; i++){
		index = parseInt(oc_table.rows[i].cells[5].innerHTML);
		if (oc_table.rows[i].cells[4].innerHTML=="2"){// signal
			idx = index+2;
			text = stable.rows[idx].cells[0].innerHTML+" "+stable.rows[idx].cells[1].innerHTML+"/"+
				convert_level_name(stable.rows[idx].cells[2].innerHTML);
				
			oc_table.rows[i].cells[1].innerHTML = text;
			
		}
		else if (oc_table.rows[i].cells[4].innerHTML=="3"){// power
			idx = index+2;
			text = ptable.rows[idx].cells[0].innerHTML+" "+ptable.rows[idx].cells[1].innerHTML+"/"+
				convert_level_name(ptable.rows[idx].cells[2].innerHTML)+" "+ptable.rows[idx].cells[3].innerHTML+"/"+
				convert_level_name(ptable.rows[idx].cells[4].innerHTML);
				
			oc_table.rows[i].cells[1].innerHTML = text;
			
		}
		else if (oc_table.rows[i].cells[4].innerHTML=="5"){// three phase
			idx = index*3+2;
			text = ttable.rows[idx].cells[0].innerHTML+" "+ttable.rows[idx].cells[2].innerHTML+"/"+
				convert_level_name(ttable.rows[idx].cells[3].innerHTML)+" "+ttable.rows[idx].cells[4].innerHTML+"/"+
				convert_level_name(ttable.rows[idx].cells[5].innerHTML);
				
			oc_table.rows[i].cells[1].innerHTML = text;
			
		}
		else if (oc_table.rows[i].cells[4].innerHTML=="4"){// frequency
			idx = index+2;
			text = ftable.rows[idx].cells[0].innerHTML+" "+ftable.rows[idx].cells[1].innerHTML+"/"+
				convert_level_name(ftable.rows[idx].cells[2].innerHTML);
				
			oc_table.rows[i].cells[1].innerHTML = text;
			
		}
	}

}

function update_select_port_names(node_port, node_level, port_type, btn_add_id){
	var node_port_el = document.getElementById(node_port);
	var level = document.getElementById(node_level).value;
	
	var model = model_from_level(level);
	
	document.getElementById(btn_add_id).disabled = false;

	
	
	if (model=="RPICT8"){
		node_port_el.options[0].text = "CT8";
		node_port_el.options[1].text = "CT7";
		node_port_el.options[2].text = "CT6";
		node_port_el.options[3].text = "CT5";
		
		if (port_type=="any" || port_type=="current"){
			node_port_el.options[0].disabled = false;
			node_port_el.options[1].disabled = false;
			node_port_el.options[2].disabled = false;
			node_port_el.options[3].disabled = false;
			
			
		}
		else if (port_type=="voltage"){
			node_port_el.options[0].disabled = true;
			node_port_el.options[1].disabled = true;
			node_port_el.options[2].disabled = true;
			node_port_el.options[3].disabled = true;
			
			document.getElementById(btn_add_id).disabled = true;
			
			node_port_el.value = "";
			
		}
	}
	else if (model=="RPICT7V1"){
		node_port_el.options[0].text = "V1";
		node_port_el.options[1].text = "CT7";
		node_port_el.options[2].text = "CT6";
		node_port_el.options[3].text = "CT5";
		
		if (port_type=="any"){
			node_port_el.options[0].disabled = false;
			node_port_el.options[1].disabled = false;
			node_port_el.options[2].disabled = false;
			node_port_el.options[3].disabled = false;
		}
		else if (port_type=="voltage"){
			node_port_el.options[0].disabled = false;
			node_port_el.options[1].disabled = true;
			node_port_el.options[2].disabled = true;
			node_port_el.options[3].disabled = true;
			
			node_port_el.value = 0;
			
		}
		else if (port_type=="current"){
			node_port_el.options[0].disabled = true;
			node_port_el.options[1].disabled = false;
			node_port_el.options[2].disabled = false;
			node_port_el.options[3].disabled = false;
			
			if (node_port_el.value==0){
				node_port_el.value = 1;
			}
						
		}
	}
	else if (model=="RPICT4V3"){
		node_port_el.options[0].text = "V3";
		node_port_el.options[1].text = "V2";
		node_port_el.options[2].text = "V1";
		node_port_el.options[3].text = "-";
		
		if (port_type=="any"){
			node_port_el.options[0].disabled = false;
			node_port_el.options[1].disabled = false;
			node_port_el.options[2].disabled = false;
			node_port_el.options[3].disabled = true;
		}
		else if (port_type=="voltage"){
			node_port_el.options[0].disabled = false;
			node_port_el.options[1].disabled = false;
			node_port_el.options[2].disabled = false;
			node_port_el.options[3].disabled = true;
			
			
			
			if (["0","1","2"].indexOf(node_port_el.value)<0){
				node_port_el.value = 0;
			}
			
		}
		else if (port_type=="current"){
			node_port_el.options[0].disabled = true;
			node_port_el.options[1].disabled = true;
			node_port_el.options[2].disabled = true;
			node_port_el.options[3].disabled = true;
			
			
			if (["3","4","5","6","7"].indexOf(node_port_el.value)<0){
				node_port_el.value = 4;
			}
		}
		
	}
		
}

function convert_level_name(level_name){
	if (level_name=="Master") return "M0";
	else if (level_name=="Slave 1") return "S1";
	else if (level_name=="Slave 2") return "S2";
	else if (level_name=="Slave 3") return "S3";
	else if (level_name=="Slave 4") return "S4";
	else return "Err";
}

function convert_level_number(level_number){
	if (level_number=="10") return "Master";
	else if (level_number=="6") return "Slave 1";
	else if (level_number=="7") return "Slave 2";
	else if (level_number=="8") return "Slave 3";
	else if (level_number=="9") return "Slave 4";
	else return "Err";
}

function convert_nodetypenumber_to_nodetypename(number){
	if (number=="2") return "Signal";
	else if (number=="3") return "Power";
	else if (number=="5") return "Three Phase";
	else if (number=="4") return "Frequency";
	else return "Err";
}

function convert_fieldnumber_to_fieldname(number){
	if (number=="0") return "None";
	else if (number=="1") return "Active Power";
	else if (number=="2") return "Apparent Power";
	else if (number=="3") return "Vrms";
	else if (number=="4") return "Irms";
	else if (number=="5") return "Estimated Power";
	else if (number=="6") return "Power Factor";
	else if (number=="7") return "Temperature";
	else if (number=="8") return "Frequency";
	else if (number=="9") return "RTD";
	else if (number=="10") return "Reactive Power";
	else if (number=="11") return "Active Power";
	else if (number=="12") return "Apparent Power";
	else if (number=="13") return "Reactive Power";
	else if (number=="14") return "Power Factor";
	else if (number=="15") return "Vrms";
	else if (number=="16") return "Irms";
	else return "Err";
}





function add_to_select(element, value, text){
	var option = document.createElement("option");
	option.value = value;
	option.text = text;
	element.add(option);
}

function update_output_channels_controls(){
	var node_type = document.getElementById("control_node_type").value;
	var node_el = document.getElementById("control_node_select");
	var chantype_el = document.getElementById("control_channel_type");
	var text;
	
	// Removing all options
	while (node_el.options.length > 0) {
        	node_el.remove(0);
    	}
    	while (chantype_el.options.length > 0) {
        	chantype_el.remove(0);
    	}
    	
    	
	
	if (node_type==2){// Signal
		table = document.getElementById("snode_table");
		rowCount = table.rows.length;
		
		for (i=2; i<rowCount; i++){
			text = table.rows[i].cells[0].innerHTML+" "+table.rows[i].cells[1].innerHTML+"/"+convert_level_name(table.rows[i].cells[2].innerHTML);
			add_to_select(node_el, (i-2), text);
		}
		add_to_select(node_el, (i-2), "All");
		
		add_to_select(chantype_el, 4, "RMS Value");
		add_to_select(chantype_el, 5, "Estimated Power");		
		
	}
	else if (node_type==3){// Power
		table = document.getElementById("pnode_table");
		rowCount = table.rows.length;
		
		for (i=2; i<rowCount; i++){
			//option = document.createElement("option");
			//option.value = (i-2);
			//option.text = table.rows[i].cells[0].innerHTML+" "+table.rows[i].cells[1].innerHTML+
			//		"/"+convert_level_name(table.rows[i].cells[2].innerHTML)+" "+
			//		table.rows[i].cells[3].innerHTML+"/"+convert_level_name(table.rows[i].cells[4].innerHTML);
			//node_el.add(option);
			
			text = table.rows[i].cells[0].innerHTML+" "+table.rows[i].cells[1].innerHTML+
					"/"+convert_level_name(table.rows[i].cells[2].innerHTML)+" "+
					table.rows[i].cells[3].innerHTML+"/"+convert_level_name(table.rows[i].cells[4].innerHTML);
			add_to_select(node_el, (i-2), text);
		}
		add_to_select(node_el, (i-2), "All");
		
		add_to_select(chantype_el, 1, "Active Power");
		add_to_select(chantype_el, 2, "Apparent Power");
		add_to_select(chantype_el, 10, "Reactive Power");
		add_to_select(chantype_el, 6, "Power Factor");
		add_to_select(chantype_el, 3, "Vrms");
		add_to_select(chantype_el, 4, "Irms");
		
	}
	else if (node_type==5){// Three Phase
		table = document.getElementById("tnode_table");
		rowCount = table.rows.length;
		
		for (i=2; i<rowCount; i++){
			if ((i-2)%3==0){
				//option = document.createElement("option");
				//option.value = (i-2);
				//option.text = table.rows[i].cells[0].innerHTML+" "+table.rows[i].cells[2].innerHTML+
				//		"/"+convert_level_name(table.rows[i].cells[3].innerHTML)+" "+
				//		table.rows[i].cells[4].innerHTML+"/"+convert_level_name(table.rows[i].cells[5].innerHTML);
				//node_el.add(option);
				
				text = table.rows[i].cells[0].innerHTML+" "+table.rows[i].cells[2].innerHTML+
						"/"+convert_level_name(table.rows[i].cells[3].innerHTML)+" "+
						table.rows[i].cells[4].innerHTML+"/"+convert_level_name(table.rows[i].cells[5].innerHTML);
				add_to_select(node_el, (i-2)/3, text);
			}
		}
		add_to_select(node_el, (i-2)/3+1, "All");
		
		add_to_select(chantype_el, 11, "Active Power");
		add_to_select(chantype_el, 12, "Apparent Power");
		add_to_select(chantype_el, 13, "Reactive Power");
		add_to_select(chantype_el, 14, "Power Factor");
		add_to_select(chantype_el, 15, "Vrms");
		add_to_select(chantype_el, 16, "Irms");
		
	}
	if (node_type==4){// Frequency
		table = document.getElementById("fnode_table");
		rowCount = table.rows.length;
		
		for (i=2; i<rowCount; i++){
			//option = document.createElement("option");
			//option.value = (i-2);
			//option.text = table.rows[i].cells[0].innerHTML+" "+table.rows[i].cells[1].innerHTML+"/"+convert_level_name(table.rows[i].cells[2].innerHTML);
			//node_el.add(option);
			text = table.rows[i].cells[0].innerHTML+" "+table.rows[i].cells[1].innerHTML+"/"+convert_level_name(table.rows[i].cells[2].innerHTML);
			add_to_select(node_el, (i-2), text);
		}
		add_to_select(node_el, (i-2), "All");
		
		add_to_select(chantype_el, 8, "Frequency");
		
	}
	
	
	if (node_el.options.length == 1) document.getElementById("btn_ocnode").disabled = true;
	else document.getElementById("btn_ocnode").disabled = false;
	

}


function snode_deleteRow(obj) {
     
    var index = obj.parentNode.parentNode.rowIndex;
    var table = document.getElementById("snode_table");
    var rowCount = table.rows.length;
    
    // Making sure this is not in the output channels first
    var oc_table = document.getElementById("output_channels_table");
    
    // printing the oc table before
    //for(var i=2; i<oc_table.rows.length; i++){
    //	out = "";
    //	for(var j=4; j<oc_table.rows[i].cells.length; j++){
    //		out+=" "+oc_table.rows[i].cells[j].innerHTML;
    //	}
    //	console.log(out);
    //}
    
    for(var i=2; i<oc_table.rows.length; i++){
    	if (oc_table.rows[i].cells[4].innerHTML=="2" && oc_table.rows[i].cells[5].innerHTML==(index-2)){
    		alert("S"+(index-1)+" is used in the Output Channels.\n Delete it from there first.");
    		return;
    	}
    }

    // all good. deleting row now.
    table.deleteRow(index);
    
    // Now update all Sx
    for (i=2; i<rowCount-1; i++){
    	table.rows[i].cells[0].innerHTML= "S"+(i-1);
    }
    
    document.getElementById("header_snode").innerHTML = "("+(rowCount-3)+")";
    
    update_output_channels_controls();
    
    // moving indexes in the output channels
    for(var i=2; i<oc_table.rows.length; i++){
        if (oc_table.rows[i].cells[4].innerHTML=="2"){
            if (oc_table.rows[i].cells[5].innerHTML>(index-2)){
            	oc_table.rows[i].cells[5].innerHTML -= 1;
            }
    	}
    }
    
    update_output_channels_table();
    
    generate_config();
}

function pnode_deleteRow(obj) {
     
    var index = obj.parentNode.parentNode.rowIndex;
    var table = document.getElementById("pnode_table");
    var rowCount = table.rows.length;
    
    // Making sure this is not in the output channels first
    var oc_table = document.getElementById("output_channels_table");
    
    for(var i=2; i<oc_table.rows.length; i++){
    	if (oc_table.rows[i].cells[4].innerHTML=="3" && oc_table.rows[i].cells[5].innerHTML==(index-2)){
    		alert("P"+(index-1)+" is used in the Output Channels.\n Delete it from there first.");
    		return;
    	}
    }
    
    // all good. deleting row now.
    table.deleteRow(index);
    
    // Now update all Px
    for (i=2; i<rowCount-1; i++){
    	table.rows[i].cells[0].innerHTML= "P"+(i-1);
    }
    
    document.getElementById("header_pnode").innerHTML = "("+(rowCount-3)+")";
    
    update_output_channels_controls();
    
    // moving indexes in the output channels
    for(var i=2; i<oc_table.rows.length; i++){
        if (oc_table.rows[i].cells[4].innerHTML=="3"){
            if (oc_table.rows[i].cells[5].innerHTML>(index-2)){
            	oc_table.rows[i].cells[5].innerHTML -= 1;
            }
    	}
    }
    
    update_output_channels_table();
    
    generate_config();
}

function tnode_deleteRow(obj) {
     
    var index = obj.parentNode.parentNode.rowIndex;
    var table = document.getElementById("tnode_table");
    var rowCount = table.rows.length;
    
    // Making sure this is not in the output channels first
    var oc_table = document.getElementById("output_channels_table");
    
    var idx = Math.floor((index-2)/3);
    
    for(var i=2; i<oc_table.rows.length; i++){
    	if (oc_table.rows[i].cells[4].innerHTML=="5" && oc_table.rows[i].cells[5].innerHTML==idx){
    		alert("Y"+(index-1)+" is used in the Output Channels.\n Delete it from there first.");
    		return;
    	}
    }

    // all good. deleting row now.
    table.deleteRow(index);
    
    // Now update all Yx
    for (i=2; i<rowCount-1; i++){
    	table.rows[i].cells[0].innerHTML= "Y"+(Math.floor((i-2)/3)+1);
    	table.rows[i].cells[1].innerHTML= "L"+((i-2)%3+1);
    }
    
    var numT = Math.floor((rowCount-4)/3)+1;
    document.getElementById("header_tnode").innerHTML = "("+numT+")";
    
    update_output_channels_controls();
    
    // moving indexes in the output channels
    for(var i=2; i<oc_table.rows.length; i++){
        if (oc_table.rows[i].cells[4].innerHTML=="5"){
            if (oc_table.rows[i].cells[5].innerHTML>(index-2)){
            	oc_table.rows[i].cells[5].innerHTML -= 1;
            }
    	}
    }
    
    update_output_channels_table();
    
    generate_config();
}

function fnode_deleteRow(obj) {
     
    var index = obj.parentNode.parentNode.rowIndex;
    var table = document.getElementById("fnode_table");
    var rowCount = table.rows.length;
    
    // Making sure this is not in the output channels first
    var oc_table = document.getElementById("output_channels_table");
    
    for(var i=2; i<oc_table.rows.length; i++){
    	if (oc_table.rows[i].cells[4].innerHTML=="4" && oc_table.rows[i].cells[5].innerHTML==(index-2)){
    		alert("F"+(index-1)+" is used in the Output Channels.\n Delete it from there first.");
    		return;
    	}
    }
    
    // all good. deleting row now.
    table.deleteRow(index);
    
    // Now update all Fx
    for (i=2; i<rowCount-1; i++){
    	table.rows[i].cells[0].innerHTML= "F"+(i-1);
    }
    
    document.getElementById("header_fnode").innerHTML = "("+(rowCount-3)+")";
    
    update_output_channels_controls();
    
    // moving indexes in the output channels
    for(var i=2; i<oc_table.rows.length; i++){
        if (oc_table.rows[i].cells[4].innerHTML=="4"){
            if (oc_table.rows[i].cells[5].innerHTML>(index-2)){
            	oc_table.rows[i].cells[5].innerHTML -= 1;
            }
    	}
    }
    
    update_output_channels_table();
    
    generate_config();
}

function output_channels_deleteRow(obj) {
	var index = obj.parentNode.parentNode.rowIndex;
	var table = document.getElementById("output_channels_table");
	var rowCount = table.rows.length;
    
	table.deleteRow(index);
	
	document.getElementById("header_output_channels").innerHTML = "("+(rowCount-3)+")";
	
	generate_config();
	
}

function snode_addRow() {
         
    var port = document.getElementById("snode_port");
    var level = document.getElementById("snode_level");
    var table = document.getElementById("snode_table");
    

    var rowCount = table.rows.length;
    var row = table.insertRow(rowCount);

    
    row.insertCell(0).innerHTML= "S"+(rowCount-1);
    row.insertCell(1).innerHTML= port[port.selectedIndex].text;
    row.insertCell(2).innerHTML= level[level.selectedIndex].text;
    row.insertCell(3).innerHTML= '<span data-feather="x-circle" onclick="snode_deleteRow(this)">ok</span>';
    row.insertCell(4).innerHTML= port.value;
    row.cells[4].style = "display: none";
    row.insertCell(5).innerHTML= level.value;
    row.cells[5].style = "display: none";
    
    document.getElementById("header_snode").innerHTML = "("+(rowCount-1)+")";
    
    update_output_channels_controls();
    
    feather.replace();
    
    generate_config();

}

function pnode_addRow() {
         
    var portI = document.getElementById("pnode_portI");
    var levelI = document.getElementById("pnode_levelI");
    var portV = document.getElementById("pnode_portV");
    var levelV = document.getElementById("pnode_levelV");
    var table = document.getElementById("pnode_table");
    

    var rowCount = table.rows.length;
    var row = table.insertRow(rowCount);

    
    row.insertCell(0).innerHTML= "P"+(rowCount-1);
    row.insertCell(1).innerHTML= portI[portI.selectedIndex].text;
    row.insertCell(2).innerHTML= levelI[levelI.selectedIndex].text;
    row.insertCell(3).innerHTML= portV[portV.selectedIndex].text;
    row.insertCell(4).innerHTML= levelV[levelV.selectedIndex].text;
    row.insertCell(5).innerHTML= '<span data-feather="x-circle" onclick="pnode_deleteRow(this)">ok</span>';
    row.insertCell(6).innerHTML= portI.value;
    row.cells[6].style = "display: none";
    row.insertCell(7).innerHTML= levelI.value;
    row.cells[7].style = "display: none";
    row.insertCell(8).innerHTML= portV.value;
    row.cells[8].style = "display: none";
    row.insertCell(9).innerHTML= levelV.value;
    row.cells[9].style = "display: none";
    
    document.getElementById("header_pnode").innerHTML = "("+(rowCount-1)+")";
    
    update_output_channels_controls();
    
    feather.replace();
    
    generate_config();

}

function tnode_addRow() {
         
    var portI = document.getElementById("tnode_portI");
    var levelI = document.getElementById("tnode_levelI");
    var portV = document.getElementById("tnode_portV");
    var levelV = document.getElementById("tnode_levelV");
    var table = document.getElementById("tnode_table");
    

    var rowCount = table.rows.length;
    var row = table.insertRow(rowCount);
    
    var numT = Math.floor((rowCount-2)/3)+1;

    
    row.insertCell(0).innerHTML= "Y"+numT;
    row.insertCell(1).innerHTML= "L"+(((rowCount-2)%3)+1);
    row.insertCell(2).innerHTML= portI[portI.selectedIndex].text;
    row.insertCell(3).innerHTML= levelI[levelI.selectedIndex].text;
    row.insertCell(4).innerHTML= portV[portV.selectedIndex].text;
    row.insertCell(5).innerHTML= levelV[levelV.selectedIndex].text;
    row.insertCell(6).innerHTML= '<span data-feather="x-circle" onclick="tnode_deleteRow(this)">ok</span>';
    row.insertCell(7).innerHTML= portI.value;
    row.cells[7].style = "display: none";
    row.insertCell(8).innerHTML= levelI.value;
    row.cells[8].style = "display: none";
    row.insertCell(9).innerHTML= portV.value;
    row.cells[9].style = "display: none";
    row.insertCell(10).innerHTML= levelV.value;
    row.cells[10].style = "display: none";
    
    document.getElementById("header_tnode").innerHTML = "("+numT+")";
    
    update_output_channels_controls();
    
    feather.replace();
    
    generate_config();

}

function fnode_addRow() {
         
    var port = document.getElementById("fnode_port");
    var level = document.getElementById("fnode_level");
    var table = document.getElementById("fnode_table");
    

    var rowCount = table.rows.length;
    var row = table.insertRow(rowCount);

    
    row.insertCell(0).innerHTML= "F"+(rowCount-1);
    row.insertCell(1).innerHTML= port[port.selectedIndex].text;
    row.insertCell(2).innerHTML= level[level.selectedIndex].text;
    row.insertCell(3).innerHTML= '<span data-feather="x-circle" onclick="fnode_deleteRow(this)">ok</span>';
    row.insertCell(4).innerHTML= port.value;
    row.cells[4].style = "display: none";
    row.insertCell(5).innerHTML= level.value;
    row.cells[5].style = "display: none";
    
    document.getElementById("header_fnode").innerHTML = "("+(rowCount-1)+")";
    
    update_output_channels_controls();
    
    feather.replace();
    
    generate_config();

}

function output_channels_addRow() {
         
    var node_type = document.getElementById("control_node_type");
    var node_select = document.getElementById("control_node_select");
    var channel_type = document.getElementById("control_channel_type");
    var table = document.getElementById("output_channels_table");
    
    var rowCount = table.rows.length;
    
    if (node_select.options[node_select.selectedIndex].text == "All") {
    	for (var i=node_select.length-2; i>-1; i--){
    		var row = table.insertRow(rowCount);

    		row.insertCell(0).innerHTML= node_type[node_type.selectedIndex].text;
    		row.insertCell(1).innerHTML= node_select.options[i].text;
    		row.insertCell(2).innerHTML= channel_type[channel_type.selectedIndex].text;
    		row.insertCell(3).innerHTML= '<span data-feather="x-circle" onclick="output_channels_deleteRow(this)">ok</span>';
    		row.insertCell(4).innerHTML= node_type.value;
    		row.cells[4].style = "display: none";
    		row.insertCell(5).innerHTML= node_select.options[i].value;
    		row.cells[5].style = "display: none";
    		row.insertCell(6).innerHTML= channel_type.value;
    		row.cells[6].style = "display: none";
    	
    		document.getElementById("header_output_channels").innerHTML = "("+(rowCount-1)+")";
    	
    	}
    }
    else {
    	var row = table.insertRow(rowCount);

    	row.insertCell(0).innerHTML= node_type[node_type.selectedIndex].text;
    	row.insertCell(1).innerHTML= node_select[node_select.selectedIndex].text;
    	row.insertCell(2).innerHTML= channel_type[channel_type.selectedIndex].text;
    	row.insertCell(3).innerHTML= '<span data-feather="x-circle" onclick="output_channels_deleteRow(this)">ok</span>';
    	row.insertCell(4).innerHTML= node_type.value;
    	row.cells[4].style = "display: none";
    	row.insertCell(5).innerHTML= node_select.value;
    	row.cells[5].style = "display: none";
    	row.insertCell(6).innerHTML= channel_type.value;
    	row.cells[6].style = "display: none";
    	
    	
    	
    	document.getElementById("header_output_channels").innerHTML = "("+(rowCount-1)+")";
    }
    
    feather.replace();
    
    generate_config();

}



function generate_config(){



	console.log("generate config");
	//dump_octable();
	
	var out_sensor = "";

	var total_node = 0;
	var ncycles = parseInt(document.getElementById("ControlInputNcycle").value);
	var freq = parseInt(document.getElementById("ControlInputXpfreq").value);

	config_text = "[main]";
	config_text += "\nformat = "+document.getElementById("ControlSelectFormat").value;
	config_text += "\ndevice_id = "+document.getElementById("ControlInput_NID").value;
	config_text += "\noutput_rate = "+document.getElementById("ControlInput_orate").value;
	config_text += "\nphasecal = "+document.getElementById("ControlInputPhasecal").value;
	config_text += "\nkcal =";
	config_text += " "+document.getElementById("ControlInput_kcal_m0c0").value;
	config_text += " "+document.getElementById("ControlInput_kcal_m0c1").value;
	config_text += " "+document.getElementById("ControlInput_kcal_m0c2").value;
	config_text += " "+document.getElementById("ControlInput_kcal_m0c3").value;
	config_text += " "+document.getElementById("ControlInput_kcal_m0c4").value;
	config_text += " "+document.getElementById("ControlInput_kcal_m0c5").value;
	config_text += " "+document.getElementById("ControlInput_kcal_m0c6").value;
	config_text += " "+document.getElementById("ControlInput_kcal_m0c7").value;
	config_text += " "+document.getElementById("ControlInput_kcal_s1c0").value;
	config_text += " "+document.getElementById("ControlInput_kcal_s1c1").value;
	config_text += " "+document.getElementById("ControlInput_kcal_s1c2").value;
	config_text += " "+document.getElementById("ControlInput_kcal_s1c3").value;
	config_text += " "+document.getElementById("ControlInput_kcal_s1c4").value;
	config_text += " "+document.getElementById("ControlInput_kcal_s1c5").value;
	config_text += " "+document.getElementById("ControlInput_kcal_s1c6").value;
	config_text += " "+document.getElementById("ControlInput_kcal_s1c7").value;
	config_text += " "+document.getElementById("ControlInput_kcal_s2c0").value;
	config_text += " "+document.getElementById("ControlInput_kcal_s2c1").value;
	config_text += " "+document.getElementById("ControlInput_kcal_s2c2").value;
	config_text += " "+document.getElementById("ControlInput_kcal_s2c3").value;
	config_text += " "+document.getElementById("ControlInput_kcal_s2c4").value;
	config_text += " "+document.getElementById("ControlInput_kcal_s2c5").value;
	config_text += " "+document.getElementById("ControlInput_kcal_s2c6").value;
	config_text += " "+document.getElementById("ControlInput_kcal_s2c7").value;
	config_text += " "+document.getElementById("ControlInput_kcal_s3c0").value;
	config_text += " "+document.getElementById("ControlInput_kcal_s3c1").value;
	config_text += " "+document.getElementById("ControlInput_kcal_s3c2").value;
	config_text += " "+document.getElementById("ControlInput_kcal_s3c3").value;
	config_text += " "+document.getElementById("ControlInput_kcal_s3c4").value;
	config_text += " "+document.getElementById("ControlInput_kcal_s3c5").value;
	config_text += " "+document.getElementById("ControlInput_kcal_s3c6").value;
	config_text += " "+document.getElementById("ControlInput_kcal_s3c7").value;
	config_text += " "+document.getElementById("ControlInput_kcal_s4c0").value;
	config_text += " "+document.getElementById("ControlInput_kcal_s4c1").value;
	config_text += " "+document.getElementById("ControlInput_kcal_s4c2").value;
	config_text += " "+document.getElementById("ControlInput_kcal_s4c3").value;
	config_text += " "+document.getElementById("ControlInput_kcal_s4c4").value;
	config_text += " "+document.getElementById("ControlInput_kcal_s4c5").value;
	config_text += " "+document.getElementById("ControlInput_kcal_s4c6").value;
	config_text += " "+document.getElementById("ControlInput_kcal_s4c7").value;
	config_text += "\nvest = "+document.getElementById("ControlInputVest").value;
	config_text += "\nxpFREQ = "+freq;
	config_text += "\nNcycle = "+ncycles;
	if (document.getElementById("ControlCheckBoxDebug").checked) config_text += "\ndebug = 1";
	else config_text += "\ndebug = 0";
	config_text += "\nmodel = "+document.getElementById("control_number_slave").value;
	config_text += " "+convert_modelname_to_modelid(document.getElementById("control_m0_model").value);
	config_text += " "+convert_modelname_to_modelid(document.getElementById("control_s1_model").value);
	config_text += " "+convert_modelname_to_modelid(document.getElementById("control_s2_model").value);
	config_text += " "+convert_modelname_to_modelid(document.getElementById("control_s3_model").value);
	config_text += " "+convert_modelname_to_modelid(document.getElementById("control_s4_model").value);
	
	// snode
	table = document.getElementById("snode_table");
	config_text += "\nsnode_pin =";
	for (var i=2; i<table.rows.length; i++){
		config_text += " "+table.rows[i].cells[4].innerHTML;
		total_node++;
	}
	config_text += "\nsnode_mcp =";
	for (var i=2; i<table.rows.length; i++){
		config_text += " "+table.rows[i].cells[5].innerHTML;
	}
	
	// pnode
	table = document.getElementById("pnode_table");
	config_text += "\npnode_pinI =";
	for (var i=2; i<table.rows.length; i++){
		config_text += " "+table.rows[i].cells[6].innerHTML;
		total_node++;
	}
	config_text += "\npnode_mcpI =";
	for (var i=2; i<table.rows.length; i++){
		config_text += " "+table.rows[i].cells[7].innerHTML;
	}
	config_text += "\npnode_pinV =";
	for (var i=2; i<table.rows.length; i++){
		config_text += " "+table.rows[i].cells[8].innerHTML;
	}
	config_text += "\npnode_mcpV =";
	for (var i=2; i<table.rows.length; i++){
		config_text += " "+table.rows[i].cells[9].innerHTML;
	}
	
	// tnode
	table = document.getElementById("tnode_table");
	config_text += "\ntnode_pinI =";
	for (var i=2; i<table.rows.length; i++){
		config_text += " "+table.rows[i].cells[7].innerHTML;
		if ((i-2)%3==1) total_node++;
	}
	config_text += "\ntnode_mcpI =";
	for (var i=2; i<table.rows.length; i++){
		config_text += " "+table.rows[i].cells[8].innerHTML;
	}
	config_text += "\ntnode_pinV =";
	for (var i=2; i<table.rows.length; i++){
		config_text += " "+table.rows[i].cells[9].innerHTML;
	}
	config_text += "\ntnode_mcpV =";
	for (var i=2; i<table.rows.length; i++){
		config_text += " "+table.rows[i].cells[10].innerHTML;
	}
	
	// fnode
	table = document.getElementById("fnode_table");
	config_text += "\nfnode_pin =";
	for (var i=2; i<table.rows.length; i++){
		config_text += " "+table.rows[i].cells[4].innerHTML;
	}
	config_text += "\nfnode_mcp =";
	for (var i=2; i<table.rows.length; i++){
		config_text += " "+table.rows[i].cells[5].innerHTML;
	}
	
	// octable
	table = document.getElementById("output_channels_table");
	config_text += "\nCHID =";
	for (var i=2; i<table.rows.length; i++){
		config_text += " "+table.rows[i].cells[5].innerHTML;
	}
	config_text += "\nCH_node_type =";
	for (var i=2; i<table.rows.length; i++){
		config_text += " "+table.rows[i].cells[4].innerHTML;
	}
	config_text += "\nCH_field_type =";
	for (var i=2; i<table.rows.length; i++){
		config_text += " "+table.rows[i].cells[6].innerHTML;
	}
	document.getElementById("config_pre").innerHTML = config_text;
	
	
	
	// Output Format
	var out_format = "";
	for (var i=2; i<table.rows.length; i++){
		var chid = table.rows[i].cells[5].innerHTML;
		var ch_node_type = table.rows[i].cells[4].innerHTML;
		var ch_field_type = table.rows[i].cells[6].innerHTML;
		
		//console.log(chid, ch_node_type, ch_field_type);
		
		out_format += get_field_type_prefix(ch_field_type)+"("+NODE_TYPES[ch_node_type]+(parseInt(chid)+1)+")";
		
	}
	//document.getElementById("format_pre").innerHTML = out_format;
	
	
	// Sensor Pairing
	//document.getElementById("sensor_pre").innerHTML = out_sensor;
	
	
	
	update_summary(config_text, total_node, ncycles, freq);

	
	localStorage.setItem("full_config_text", config_text);

}

function dump_octable(){
	table = document.getElementById("output_channels_table");
	var tmp_txt;
	for (var i=2; i<table.rows.length; i++){
		tmp_txt = "";
		for (var j=0; j<table.rows[i].cells.length; j++){
			tmp_txt += table.rows[i].cells[j].innerHTML + '\t';
		}
		console.log(tmp_txt);
		
	}

}


function update_summary(config_text, total_node, ncycles, freq){
	config_hash = hashFnv32a(config_text, true);

	var summary_pre = "Checksum: "+config_hash;
	summary_pre += "\nTotal Nodes: "+total_node;
	summary_pre += "\nMinimum Output Rate: " +total_node*ncycles/freq +" seconds";
	
	document.getElementById("summary_pre").innerHTML = summary_pre;

}

function pad(d) {
    return (d < 10) ? '0' + d.toString() : d.toString();
}

function get_kcal(pin, mcp){
	if (mcp==10){
		if (pin==0){
			return document.getElementById("ControlInput_kcal_m0c0").value;
		}
		else if (pin==1){
			return document.getElementById("ControlInput_kcal_m0c1").value;
		}
		else if (pin==2){
			return document.getElementById("ControlInput_kcal_m0c2").value;
		}
		else if (pin==3){
			return document.getElementById("ControlInput_kcal_m0c3").value;
		}
		else if (pin==4){
			return document.getElementById("ControlInput_kcal_m0c4").value;
		}
		else if (pin==5){
			return document.getElementById("ControlInput_kcal_m0c5").value;
		}
		else if (pin==6){
			return document.getElementById("ControlInput_kcal_m0c6").value;
		}
		else if (pin==7){
			return document.getElementById("ControlInput_kcal_m0c7").value;
		}
	}
	else if (mcp==6){
		if (pin==0){
			return document.getElementById("ControlInput_kcal_s1c0").value;
		}
		else if (pin==1){
			return document.getElementById("ControlInput_kcal_s1c1").value;
		}
		else if (pin==2){
			return document.getElementById("ControlInput_kcal_s1c2").value;
		}
		else if (pin==3){
			return document.getElementById("ControlInput_kcal_s1c3").value;
		}
		else if (pin==4){
			return document.getElementById("ControlInput_kcal_s1c4").value;
		}
		else if (pin==5){
			return document.getElementById("ControlInput_kcal_s1c5").value;
		}
		else if (pin==6){
			return document.getElementById("ControlInput_kcal_s1c6").value;
		}
		else if (pin==7){
			return document.getElementById("ControlInput_kcal_s1c7").value;
		}
	}
	else if (mcp==7){
		if (pin==0){
			return document.getElementById("ControlInput_kcal_s2c0").value;
		}
		else if (pin==1){
			return document.getElementById("ControlInput_kcal_s2c1").value;
		}
		else if (pin==2){
			return document.getElementById("ControlInput_kcal_s2c2").value;
		}
		else if (pin==3){
			return document.getElementById("ControlInput_kcal_s2c3").value;
		}
		else if (pin==4){
			return document.getElementById("ControlInput_kcal_s2c4").value;
		}
		else if (pin==5){
			return document.getElementById("ControlInput_kcal_s2c5").value;
		}
		else if (pin==6){
			return document.getElementById("ControlInput_kcal_s2c6").value;
		}
		else if (pin==7){
			return document.getElementById("ControlInput_kcal_s2c7").value;
		}
	}
	else if (mcp==8){
		if (pin==0){
			return document.getElementById("ControlInput_kcal_s3c0").value;
		}
		else if (pin==1){
			return document.getElementById("ControlInput_kcal_s3c1").value;
		}
		else if (pin==2){
			return document.getElementById("ControlInput_kcal_s3c2").value;
		}
		else if (pin==3){
			return document.getElementById("ControlInput_kcal_s3c3").value;
		}
		else if (pin==4){
			return document.getElementById("ControlInput_kcal_s3c4").value;
		}
		else if (pin==5){
			return document.getElementById("ControlInput_kcal_s3c5").value;
		}
		else if (pin==6){
			return document.getElementById("ControlInput_kcal_s3c6").value;
		}
		else if (pin==7){
			return document.getElementById("ControlInput_kcal_s3c7").value;
		}
	}
	else if (mcp==9){
		if (pin==0){
			return document.getElementById("ControlInput_kcal_s4c0").value;
		}
		else if (pin==1){
			return document.getElementById("ControlInput_kcal_s4c1").value;
		}
		else if (pin==2){
			return document.getElementById("ControlInput_kcal_s4c2").value;
		}
		else if (pin==3){
			return document.getElementById("ControlInput_kcal_s4c3").value;
		}
		else if (pin==4){
			return document.getElementById("ControlInput_kcal_s4c4").value;
		}
		else if (pin==5){
			return document.getElementById("ControlInput_kcal_s4c5").value;
		}
		else if (pin==6){
			return document.getElementById("ControlInput_kcal_s4c6").value;
		}
		else if (pin==7){
			return document.getElementById("ControlInput_kcal_s4c7").value;
		}
	}
}

function generate_hardcode(){

	var pinI, mcpI, pinV, mcpV, Ical;
	
	var nslaves = document.getElementById("control_number_slave").value;
	var phasecal = document.getElementById("ControlInputPhasecal").value;
	var output_rate = document.getElementById("ControlInput_orate").value;
	var lib_version = "1_5_0";

	hardcode_text = "#include \"RPICTlib.h\"\n"
	hardcode_text += "#ifndef RPICTlib_"+lib_version+"\n"
	hardcode_text += "#error RPICTlib Version Error\n"
	hardcode_text += "#endif\n"
	hardcode_text += "uint32_t timer = 0;\n"
	
	hardcode_text += "SensorArray Sarr;\n"
	
	stable = document.getElementById("snode_table");
	for (var i=2; i<stable.rows.length; i++){
		hardcode_text += "SignalNode_mcp3208 S"+pad(i-1)+";\n";
	}
	ptable = document.getElementById("pnode_table");
	for (var i=2; i<ptable.rows.length; i++){
		hardcode_text += "PowerNode_mcp3208 P"+pad(i-1)+";\n";
	}
	ttable = document.getElementById("tnode_table");
	for (var i=0; i<((ttable.rows.length-2)/3); i++){
		hardcode_text += "ThreeWattMeter_mcp3208 Y"+pad(i+1)+";\n";
	}
	ftable = document.getElementById("fnode_table");
	for (var i=2; i<ftable.rows.length; i++){
		hardcode_text += "FrequencyNode_mcp3208 F"+pad(i-1)+";\n";
	}
	

	// SETUP HAPPEN HERE
	hardcode_text += "void setup() {\n"
	hardcode_text += "Serial.begin(38400);\n"
	hardcode_text += "Serial.println(F(\"# RPICT - RPICTlib v"+lib_version+"\"));\n"
	hardcode_text += "Serial.println(F(\"# CHECKSUM: "+config_hash+"\"));\n"
	hardcode_text += "Serial.println(F(\"# Code Generator v1.0.4\"));\n"
	hardcode_text += "SPI.begin();\n"
	hardcode_text += "pinMode(MASTER, OUTPUT);\n"
	hardcode_text += "pinMode(SLAVE1, OUTPUT);\n"
	hardcode_text += "pinMode(SLAVE2, OUTPUT);\n"
	hardcode_text += "pinMode(SLAVE3, OUTPUT);\n"
	hardcode_text += "pinMode(SLAVE4, OUTPUT);\n"

	hardcode_text += "adc_definition(12, 4096);\n"
	
	var kcals_txt = "";
	for (var i=0; i<8; i++){
		if (i!=0) kcals_txt += ",";
		kcals_txt+=get_kcal(i, 10);	
	}
	hardcode_text += "Sarr.addMaster("+kcals_txt+");\n"
	
	for (var j=0; j<nslaves; j++){
		kcals_txt = "";
		for (i=0; i<8; i++){
			if (i!=0) kcals_txt += ",";
			kcals_txt+=get_kcal(i, j+6);
		}
		hardcode_text += "Sarr.addSlave("+kcals_txt+");\n"
	}
	
	for (var i=2; i<stable.rows.length; i++){
		pinI = stable.rows[i].cells[4].innerHTML;
		mcpI = stable.rows[i].cells[5].innerHTML;
		hardcode_text += "S"+pad(i-1)+".begin("+pinI+" ,"+mcpI+" , &Sarr);\n";
	}
	for (var i=2; i<ptable.rows.length; i++){
		pinI = ptable.rows[i].cells[6].innerHTML;
		mcpI = ptable.rows[i].cells[7].innerHTML;
		pinV = ptable.rows[i].cells[8].innerHTML;
		mcpV = ptable.rows[i].cells[9].innerHTML;
		
		hardcode_text += "P"+pad(i-1)+".begin("+pinI+" ,"+mcpI+" ,"+pinV+" ,"+mcpV+" ,"+phasecal+", &Sarr);\n";
	}
	for (var i=0; i<((ttable.rows.length-2)/3); i++){
		var pinI1 = ttable.rows[3*i+2].cells[7].innerHTML;
		var mcpI1 = ttable.rows[3*i+2].cells[8].innerHTML;
		var pinV1 = ttable.rows[3*i+2].cells[9].innerHTML;
		var mcpV1 = ttable.rows[3*i+2].cells[10].innerHTML;
		var pinI2 = ttable.rows[3*i+3].cells[7].innerHTML;
		var mcpI2 = ttable.rows[3*i+3].cells[8].innerHTML;
		var pinV2 = ttable.rows[3*i+3].cells[9].innerHTML;
		var mcpV2 = ttable.rows[3*i+3].cells[10].innerHTML;
		var pinI3 = ttable.rows[3*i+4].cells[7].innerHTML;
		var mcpI3 = ttable.rows[3*i+4].cells[8].innerHTML;
		var pinV3 = ttable.rows[3*i+4].cells[9].innerHTML;
		var mcpV3 = ttable.rows[3*i+4].cells[10].innerHTML;
		
		hardcode_text += "Y"+pad(i+1)+".begin(";
		hardcode_text += pinI1+" ,"+mcpI1+" ,"+pinV1+" ,"+mcpV1+" ,";
		hardcode_text += pinI2+" ,"+mcpI2+" ,"+pinV2+" ,"+mcpV2+" ,";
		hardcode_text += pinI3+" ,"+mcpI3+" ,"+pinV3+" ,"+mcpV3+" ,";
		hardcode_text += phasecal +", &Sarr);\n";
	}
	
	for (var i=2; i<ftable.rows.length; i++){
		pinI = ftable.rows[i].cells[4].innerHTML;
		mcpI = ftable.rows[i].cells[5].innerHTML;
		hardcode_text += "F"+pad(i-1)+".begin("+pinI+" ,"+mcpI+", &Sarr);\n";
	}
	
	hardcode_text += "}\n"
	
	// LOOP 
	hardcode_text += "void loop() {\n"
	
	var sinterval_snode = "180";
	var sinterval_pnode = "225";
	var sinterval_tnode = "600";
	
	var ncycles = document.getElementById("ControlInputNcycle").value;
	var xpfreq = document.getElementById("ControlInputXpfreq").value;
	
	var nsample_snode = Math.round(ncycles*1000000/xpfreq/sinterval_snode);
	var nsample_pnode = Math.round(ncycles*1000000/xpfreq/sinterval_pnode);
	var nsample_tnode = Math.round(ncycles*1000000/xpfreq/sinterval_tnode);
	
	for (var i=2; i<stable.rows.length; i++){
		hardcode_text += "S"+pad(i-1)+".calcRMS("+nsample_snode+", "+sinterval_snode+");\n";
		hardcode_text += "timer_check();\n";
	}
	
	for (var i=2; i<ptable.rows.length; i++){
		hardcode_text += "P"+pad(i-1)+".calcVI("+nsample_pnode+", "+sinterval_pnode+");\n";
		hardcode_text += "timer_check();\n";
	}
	
	for (var i=0; i<((ttable.rows.length-2)/3); i++){
		hardcode_text += "Y"+pad(i+1)+".calcVI("+nsample_tnode+", "+sinterval_tnode+");\n";
		hardcode_text += "timer_check();\n";
	}
	
	for (var i=2; i<ftable.rows.length; i++){
		hardcode_text += "F"+pad(i-1)+".calcFreq(1000000/"+xpfreq+");\n";
		hardcode_text += "timer_check();\n";
	}
	hardcode_text += "}\n";
	
	
	var oc_table = document.getElementById("output_channels_table");
	var nid = document.getElementById("ControlInput_NID").value;
	var vest = document.getElementById("ControlInputVest").value;
	
	
	hardcode_text += "void write_data() {\n";
	hardcode_text += "Serial.print(\""+nid+"\");\n";
	//hardcode_text += "print_delimiter();\n";
	
	for (var i=2; i<oc_table.rows.length; i++){
		//hardcode_text += "print_delimiter();\n";
		if (oc_table.rows[i].cells[4].innerHTML=="3"){ // PNODE
			var Pxx = "P"+pad(parseInt(oc_table.rows[i].cells[5].innerHTML)+1);
			if (oc_table.rows[i].cells[6].innerHTML=="1"){ // Active P
				hardcode_text += "check_and_print("+Pxx+".realPower, "+Pxx+".err);\n";
			}
			else if (oc_table.rows[i].cells[6].innerHTML=="2"){
				hardcode_text += "check_and_print("+Pxx+".Irms*"+Pxx+".Vrms, "+Pxx+".err);\n";
			}
			else if (oc_table.rows[i].cells[6].innerHTML=="3"){
				hardcode_text += "check_and_print("+Pxx+".Vrms, "+Pxx+".err);\n";
			}
			else if (oc_table.rows[i].cells[6].innerHTML=="4"){
				hardcode_text += "check_and_print("+Pxx+".Irms, "+Pxx+".err);\n";
			}
			else if (oc_table.rows[i].cells[6].innerHTML=="6"){
				hardcode_text += "check_and_print("+Pxx+".realPower/("+Pxx+".Vrms*"+Pxx+".Irms), "+Pxx+".err);\n";
			}
			else if (oc_table.rows[i].cells[6].innerHTML=="10"){ // REACTIVE P
				hardcode_text += "check_and_print(sqrt("+Pxx+".Vrms*"+Pxx+".Irms*"+Pxx+".Vrms*"+Pxx+".Irms-"+Pxx+".realPower*"+Pxx+".realPower), "+Pxx+".err);\n";
			}
		}
		else if (oc_table.rows[i].cells[4].innerHTML=="2"){ // SNODE
			var Sxx = "S"+pad(parseInt(table.rows[i].cells[5].innerHTML)+1);
			if (table.rows[i].cells[6].innerHTML=="4"){
				hardcode_text += "check_and_print("+Sxx+".RMS, "+Sxx+".err);\n";
			}
			else if (table.rows[i].cells[6].innerHTML=="5"){
				hardcode_text += "check_and_print("+vest+"*"+Sxx+".RMS, "+Sxx+".err);\n";
			}
		}
		else if (oc_table.rows[i].cells[4].innerHTML=="5"){ // TNODE
			var Yxx = "Y"+pad(parseInt(oc_table.rows[i].cells[5].innerHTML)+1);
			if (oc_table.rows[i].cells[6].innerHTML=="11"){ // ACTIVE
				hardcode_text += "check_and_print("+Yxx+".P1, "+Yxx+".err);\n";
				//hardcode_text += "print_delimiter();\n";
				hardcode_text += "check_and_print("+Yxx+".P2, "+Yxx+".err);\n";
				//hardcode_text += "print_delimiter();\n";
				hardcode_text += "check_and_print("+Yxx+".P3, "+Yxx+".err);\n";
				
			}
			else if (oc_table.rows[i].cells[6].innerHTML=="12"){ // APPARENT
				hardcode_text += "check_and_print("+Yxx+".I1rms*"+Yxx+".V1rms, "+Yxx+".err);\n";
				//hardcode_text += "print_delimiter();\n";
				hardcode_text += "check_and_print("+Yxx+".I2rms*"+Yxx+".V2rms, "+Yxx+".err);\n";
				//hardcode_text += "print_delimiter();\n";
				hardcode_text += "check_and_print("+Yxx+".I3rms*"+Yxx+".V3rms, "+Yxx+".err);\n";
			}
			else if (oc_table.rows[i].cells[6].innerHTML=="13"){ // REACTIVE P
				hardcode_text += "check_and_print(sqrt("+Pxx+".V1rms*"+Pxx+".I1rms*"+Pxx+".V1rms*"+Pxx+".I1rms-"+Pxx+".P1*"+Pxx+".P1), "+Yxx+".err);\n";
				//hardcode_text += "print_delimiter();\n";
				hardcode_text += "check_and_print(sqrt("+Pxx+".V2rms*"+Pxx+".I2rms*"+Pxx+".V2rms*"+Pxx+".I2rms-"+Pxx+".P2*"+Pxx+".P2), "+Yxx+".err);\n";
				//hardcode_text += "print_delimiter();\n";
				hardcode_text += "check_and_print(sqrt("+Pxx+".V3rms*"+Pxx+".I3rms*"+Pxx+".V3rms*"+Pxx+".I3rms-"+Pxx+".P3*"+Pxx+".P3), "+Yxx+".err);\n";
			}
			else if (oc_table.rows[i].cells[6].innerHTML=="15"){ // Vrms
				hardcode_text += "check_and_print("+Yxx+".V1rms, "+Yxx+".err);\n";
				//hardcode_text += "print_delimiter();\n";
				hardcode_text += "check_and_print("+Yxx+".V2rms, "+Yxx+".err);\n";
				//hardcode_text += "print_delimiter();\n";
				hardcode_text += "check_and_print("+Yxx+".V3rms, "+Yxx+".err);\n";
			}
			else if (oc_table.rows[i].cells[6].innerHTML=="16"){ // Irms
				hardcode_text += "check_and_print("+Yxx+".I1rms, "+Yxx+".err);\n";
				//hardcode_text += "print_delimiter();\n";
				hardcode_text += "check_and_print("+Yxx+".I2rms, "+Yxx+".err);\n";
				//hardcode_text += "print_delimiter();\n";
				hardcode_text += "check_and_print("+Yxx+".I3rms, "+Yxx+".err);\n";
			}
			else if (oc_table.rows[i].cells[6].innerHTML=="14"){ // PF
				hardcode_text += "check_and_print("+Yxx+".P1/("+Yxx+".V1rms*"+Yxx+".I1rms), "+Yxx+".err);\n";
				//hardcode_text += "print_delimiter();\n";
				hardcode_text += "check_and_print("+Yxx+".P2/("+Yxx+".V2rms*"+Yxx+".I2rms), "+Yxx+".err);\n";
				//hardcode_text += "print_delimiter();\n";
				hardcode_text += "check_and_print("+Yxx+".P3/("+Yxx+".V3rms*"+Yxx+".I3rms), "+Yxx+".err);\n";
			}
		}
	}
	
	
	
	
	
	hardcode_text += "Serial.println();\n";
	hardcode_text += "}\n";
	
	
	hardcode_text += "void timer_check() {\n";
	hardcode_text += "if (millis() - timer > "+output_rate+") {\n";
	hardcode_text += "timer = millis();\n";
	hardcode_text += "write_data();\n";
	hardcode_text += "}\n";
	hardcode_text += "}\n";
	hardcode_text += "void print_delimiter() {\n";
	hardcode_text += "Serial.print(\" \");\n";
	hardcode_text += "}\n";
	
	hardcode_text += "void check_and_print(float value, uint8_t err) {\n";
	hardcode_text += "print_delimiter();\n";
	hardcode_text += "if (err) Serial.print(\"nan\");\n";
	hardcode_text += "else Serial.print(value);\n";
	hardcode_text += "}\n";
	
	document.getElementById("hardcode_pre").innerHTML = hardcode_text;
}







