#!/usr/bin/python3


def output_message(data):
	print("Content-Type: text/html\n\n")
	print(data)


import sys, cgi, subprocess, shlex
debug = 1

#lcl_cmd     = "/home/pi/lcl-rpict-package/usr/local/bin/lcl-rpict-config.py"
lcl_cmd     = "/usr/local/bin/lcl-rpict-config.py"
remote_file = "/tmp/remote_rpict.conf"
cmd         = "%s -a -w %s" % (lcl_cmd, remote_file)
fuser_cmd = "/bin/fuser /dev/ttyAMA0"
nofuser = False

try:
	cmd_stdout = subprocess.check_output(shlex.split(fuser_cmd))
	ee = cmd_stdout.decode()
	sys.stderr.write(ee)
	
except subprocess.CalledProcessError as e:
	nofuser = True


if nofuser:

	form = cgi.FieldStorage()
	config = form.getvalue("config")
	if debug:
		sys.stderr.write(config)
		sys.stderr.write(cmd)
	


	f = open(remote_file, 'w')
	f.write(config)
	f.close()

	data = '{ "success": "true", "error": "" }'
	process_ok = True

	try:
		#p = subprocess.check_output(shlex.split(cmd), shell=True)
		#process = subprocess.Popen(shlex.split(cmd),stdout=subprocess.PIPE,shell=True)
		#pout, perr = process.communicate()
		
		p = subprocess.run(shlex.split(cmd))
		
	except subprocess.CalledProcessError as e:
		sys.stderr.write("Process failed")
		sys.stderr.write(e.output)
		process_ok = False
		data = '{ "success": "false", "error": "Program failed. Check logs." }'
	
	
	if p.returncode==18:
		data = '{ "success": "false", "error": "Timeout. No serial data received in the last 10 seconds." }'
	elif p.returncode==17:
		data = '{ "success": "false", "error": "Error. Malformed configuration." }'
	elif p.returncode==16:
		data = '{ "success": "false", "error": "Error. 3 phase nodes must be multiples of 3." }'

	#if debug and process_ok:
		#sys.stderr.write(p.stdout.decode())
		
	
	output_message(data)
else:	
	data = '{ "success": "false", "error": "Serial Port already in use by pid %s." }' % ee
	output_message(data)

