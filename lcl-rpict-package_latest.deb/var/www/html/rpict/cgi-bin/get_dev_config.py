#!/usr/bin/python3


def output_message(data):
	print("Content-Type: text/html\n\n")
	print(data)


import sys, cgi, subprocess, shlex
debug = 1

#lcl_cmd     = "/home/pi/lcl-rpict-package/usr/local/bin/lcl-rpict-config.py"
lcl_cmd     = "/usr/local/bin/lcl-rpict-config.py"
config_file = "/tmp/rpict.conf"
cmd         = "%s -a" % (lcl_cmd)
fuser_cmd = "/bin/fuser /dev/ttyAMA0"
nofuser = False

try:
	cmd_stdout = subprocess.check_output(shlex.split(fuser_cmd))
	ee = cmd_stdout.decode()
	sys.stderr.write(ee)
	
except subprocess.CalledProcessError as e:
	nofuser = True


if nofuser:


	if debug:
		sys.stderr.write(cmd)
	

	data = '{ "success": "true", "error": "" }'
	process_ok = True

	try:
		#p = subprocess.check_output(shlex.split(cmd), shell=True)
		#process = subprocess.Popen(shlex.split(cmd),stdout=subprocess.PIPE,shell=True)
		#pout, perr = process.communicate()
		
		p = subprocess.run(shlex.split(cmd))
		
	except subprocess.CalledProcessError as e:
		sys.stderr.write("Process failed")
		sys.stderr.write(e.output)
		process_ok = False
		data = '{ "success": "false", "error": "Program failed. Check logs." }'
	
	sys.stderr.write("Returned Code: %s\n" % str(p.returncode))
	
	if p.returncode==0:	
		f = open(config_file, 'r')
		content = f.read().replace('\n', "$")
		f.close()
		sys.stderr.write("Content: %s\n" % content)
		data = '{ "success": "true", "error": "" , "config": "%s"}' % content
	else:	
		data = '{ "success": "false", "error": "Failed." }'

	#if debug and process_ok:
		#sys.stderr.write(p.stdout.decode())
		
	
	output_message(data)
else:	
	data = '{ "success": "false", "error": "Serial Port already in use by pid %s." }' % ee
	output_message(data)

