

var config_mode = "basic";
var config_hash;


window.onload = function onloadFunction() {
	var basic_config_text = localStorage.getItem("basic_config_text");

	if (basic_config_text != null){
		console.log("Config loaded from cache.");
		populate_config(basic_config_text);
		//generate_config();
	}
	else {
		ControlSelect_model_changed();
	}

	// Already included in populate_config
	//ControlSelect_model_changed()
}



function onload(){}

function get_dev_config(){

	if (is_online){
		alert('This function is disabled on the online version');
		return;
	}

	//console.log("clicked");
	document.getElementById("response").innerHTML = "querying device...";
	var xhr = new XMLHttpRequest();

	
	xhr.open("POST", "/cgi-bin/get_dev_config.py");
	xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

	
	var cfg_txt = document.getElementById("config_pre").innerHTML;
	
	xhr.send("");

	
	xhr.onload = function() {
		//console.log(`Loaded: ${xhr.status} ${xhr.response}`);
		var r = JSON.parse(xhr.response);
		//document.getElementById("response").innerHTML = xhr.response;
		if (r.success=="true"){
			var config_text = r.config.replace(/\$/g, "\n");
			document.getElementById("response").innerHTML = '<span style="color:green">Configuration loaded from device.</span>';
			populate_config(config_text);
			generate_config();
			//document.getElementById("config_pre").innerHTML = config_text;
		}
		else {
			document.getElementById("response").innerHTML = '<span style="color:red">'+r.error+'</span>';
		}
		
		//update_output_channels_controls();
	};

	xhr.onerror = function() { // only triggers if the request couldn't be made at all
		//console.log(`Network Error`);
		document.getElementById("response").innerHTML = '<span style="color:red">Network Error!</span>';
	};
	
	
}

function populate_config(text){
	
	var master_model = null;	
        	
	var z = text.split("\n");
	for(var i=0;i<z.length;i++){
		v = z[i].split(" = ");
		
		// In case the file has been formatted by windoze.
		if (v.length>1){
			if (v[1].slice(-1)=="\r"){
				v[1] = v[1].slice(0, -1);
			}
		}
		
		//console.log(z[i]);
		
		//if (v[0]=="format"){
		//	document.getElementById("ControlSelectFormat").value = v[1];
		//}
		//else if (v[0]=="device_id"){
  		//	document.getElementById("ControlInput_NID").value = v[1];
  		//}
  		if (v[0]=="output_rate"){
  			document.getElementById("ControlInput_orate").value = v[1];
  		}
  		//else if (v[0]=="phasecal"){
  		//	document.getElementById("ControlInputPhasecal").value = v[1];
  		//}
  		else if (v[0]=="vest"){
  			document.getElementById("ControlInputVest").value = v[1];
  		}
  		else if (v[0]=="xpFREQ"){
  			document.getElementById("ControlInputXpfreq").value = v[1];
  		}
  		//else if (v[0]=="Ncycle"){
  		//	document.getElementById("ControlInputNcycle").value = v[1];
  		//}
  		//else if (v[0]=="debug"){
  		//	if (v[1]=="1") document.getElementById("ControlCheckBoxDebug").checked = true;
  		//	else document.getElementById("ControlCheckBoxDebug").checked = false;
  		//}
  		else if (v[0]=="model"){
  			mdls = v[1].split(" ");
  			
  			master_model = convert_modelid_to_modelname(mdls[1]);
  			
  			document.getElementById("control_number_slave").value = mdls[0];
  			document.getElementById("ControlSelect_model").value = master_model;
  			
  		}
  		else if (v[0]=="kcal"){
  			var kcals = v[1].split(" ");
  			// 
			
  			
  		}
  		
  		
  		else if (v[0]=="CH_field_type"){
  			nods = v[1].split(" ");
  			
  			document.getElementById("ControlCheckBox_AP").checked = false;
  			document.getElementById("ControlCheckBox_APP").checked = false;
  			document.getElementById("ControlCheckBox_VRMS").checked = false;	
  			document.getElementById("ControlCheckBox_IRMS").checked = false;
  			document.getElementById("ControlCheckBox_EP").checked = false;
  			document.getElementById("ControlCheckBox_PF").checked = false;	
  			document.getElementById("ControlCheckBox_T").checked = false;
  			document.getElementById("ControlCheckBox_F").checked = false;
  			document.getElementById("ControlCheckBox_RP").checked = false;
  			document.getElementById("ControlCheckBox_3P").checked = false;
  			
  			for (j=0; j<nods.length; j++){
  				//console.log(nods[j]);
  				if (nods[j]==1){
  					document.getElementById("ControlCheckBox_AP").checked = true;
  				}
  				else if (nods[j]==2){
  					document.getElementById("ControlCheckBox_APP").checked = true;
  				}
  				else if (nods[j]==3){
  					document.getElementById("ControlCheckBox_VRMS").checked = true;
  				}
  				else if (nods[j]==4){
  					document.getElementById("ControlCheckBox_IRMS").checked = true;
  				}
  				else if (nods[j]==5){
  					document.getElementById("ControlCheckBox_EP").checked = true;
  				}
  				else if (nods[j]==6){
  					document.getElementById("ControlCheckBox_PF").checked = true;
  				}
  				else if (nods[j]==7){
  					document.getElementById("ControlCheckBox_T").checked = true;
  				}
  				else if (nods[j]==8){
  					document.getElementById("ControlCheckBox_F").checked = true;
  				}
  				else if (nods[j]==10){
  					document.getElementById("ControlCheckBox_RP").checked = true;
  				}
  				else if (nods[j]==11){
  					document.getElementById("ControlCheckBox_3P").checked = true;
  					document.getElementById("ControlCheckBox_AP").checked = true;
  				}
  				else if (nods[j]==12){
  					document.getElementById("ControlCheckBox_3P").checked = true;
  					document.getElementById("ControlCheckBox_APP").checked = true;
  				}
  				else if (nods[j]==13){
  					document.getElementById("ControlCheckBox_3P").checked = true;
  					document.getElementById("ControlCheckBox_RP").checked = true;
  				}
  				else if (nods[j]==14){
  					document.getElementById("ControlCheckBox_3P").checked = true;
  					document.getElementById("ControlCheckBox_PF").checked = true;
  				}
  				else if (nods[j]==15){
  					document.getElementById("ControlCheckBox_3P").checked = true;
  					document.getElementById("ControlCheckBox_VRMS").checked = true;
  				}
  				else if (nods[j]==16){
  					document.getElementById("ControlCheckBox_3P").checked = true;
  					document.getElementById("ControlCheckBox_IRMS").checked = true;
  				}
			}
  		
  		}
  		
	}// for   
	
	var [cttype, vers] = guess_cttype_from_kcal(kcals[3]);
	var [vtype, vvers] = guess_vtype_from_kcal(kcals[0]);
	
	if (master_model==null){
		if (kcals[3]=="1."){
			master_model = "RPICT3V1";
		}
		else {
			master_model = "RPICT3T1";
		}
		document.getElementById("ControlSelect_model").value = master_model;
	
	}
	else if (master_model=="RPICT8"){
		if (cttype==0){
			if (vers==0){
				vers = "V5";
			}
			document.getElementById("ControlSelectCtType").value = "SCT-013-000 (100A)";
			document.getElementById("ControlSelect_hwversion").value = vers;
			document.getElementById("response").innerHTML += '<br><span style="color:red">Could not determine CT and Voltage type. Using default values.<br>Config should maybe be opened in full configuration instead.</span>';
			console.log(cttype, vers, kcals[3]);
			console.log(vtype, vvers, kcals[0]);
		}
		else {
			document.getElementById("ControlSelectCtType").value = cttype;
			document.getElementById("ControlSelect_hwversion").value = vers;
		}
	
	}
	else {
		if (cttype==0 || vtype==0){
			if (vers==0){
				if (vvers==0){
					vers = "V5";
				}
				else {
					vers = vvers;
				}
			}
			document.getElementById("ControlSelectCtType").value = "SCT-013-000 (100A)";
			document.getElementById("ControlSelect_hwversion").value = vers;
			document.getElementById("ControlSelectVoltageType").value = "UK AC/AC Wall Plug";
			document.getElementById("response").innerHTML += '<br><span style="color:red">Could not determine CT and Voltage type. Using default values.<br>Config should maybe be opened in full configuration instead.</span>';
			console.log(cttype, vers, kcals[3]);
			console.log(vtype, vvers, kcals[0]);
		}
		else {
			document.getElementById("ControlSelectCtType").value = cttype;
			document.getElementById("ControlSelect_hwversion").value = vers;
			document.getElementById("ControlSelectVoltageType").value = vtype;
		}
	
	}
	
	
	
	   
	
	
	ControlSelect_model_changed(); // !! has generate config
	
        	

}


function ControlSelect_model_changed(){
	
	var v = document.getElementById("ControlSelect_model").value;
	var Nslaves = Number(document.getElementById("control_number_slave").value);
	
	if (v=="RPICT7V1"){
		
		if (Nslaves>3){
			document.getElementById("control_number_slave").value = "3";
		}
	
		enable_checkbox("control_number_slave", "label_nslave");
		//disable_option("control_number_slave", "2"); 
		//disable_option("control_number_slave", "3");
		disable_option("control_number_slave", "4");
		
		
		enable_checkbox("ControlCheckBox_AP", "label_AP");
		enable_checkbox("ControlCheckBox_APP", "label_APP");
		enable_checkbox("ControlCheckBox_RP", "label_RP");
		disable_checkbox("ControlCheckBox_EP", "label_EP");
		enable_checkbox("ControlCheckBox_T", "label_T");
		enable_checkbox("ControlCheckBox_VRMS", "label_VRMS");
		enable_checkbox("ControlCheckBox_IRMS", "label_IRMS");
		enable_checkbox("ControlCheckBox_PF", "label_PF");
		enable_checkbox("ControlCheckBox_F", "label_F");
		disable_checkbox("ControlCheckBox_T", "label_T");
		disable_checkbox("ControlCheckBox_3P", "label_3P");
		enable_checkbox("ControlCheckBox_1V", "label_1V");
		enable_checkbox("ControlSelectVoltageType", "label_vtype");
		enable_checkbox("ControlSelect_hwversion", "label_hwversion");
		
		
	}
	else if (v=="RPICT8"){
	
		enable_checkbox("control_number_slave", "label_nslave");
		//enable_option("control_number_slave", "2");
		enable_option("control_number_slave", "3");
		enable_option("control_number_slave", "4");
		
		disable_checkbox("ControlCheckBox_AP", "label_AP");
		disable_checkbox("ControlCheckBox_APP", "label_APP");
		disable_checkbox("ControlCheckBox_RP", "label_RP");
		enable_checkbox("ControlCheckBox_EP", "label_EP");
		disable_checkbox("ControlCheckBox_T", "label_T");
		disable_checkbox("ControlCheckBox_VRMS", "label_VRMS");
		enable_checkbox("ControlCheckBox_IRMS", "label_IRMS");
		disable_checkbox("ControlCheckBox_PF", "label_PF");
		disable_checkbox("ControlCheckBox_F", "label_F");
		disable_checkbox("ControlCheckBox_T", "label_T");
		disable_checkbox("ControlCheckBox_3P", "label_3P");
		disable_checkbox("ControlCheckBox_1V", "label_1V");
		disable_checkbox("ControlSelectVoltageType", "label_vtype");
		enable_checkbox("ControlSelect_hwversion", "label_hwversion");
	}
	else if (v=="RPICT4V3"){
		if (Nslaves>3){
			document.getElementById("control_number_slave").value = "3";
		}
	
		enable_checkbox("control_number_slave", "label_nslave");
		//disable_option("control_number_slave", "2"); 
		//disable_option("control_number_slave", "3");
		disable_option("control_number_slave", "4");
	
		//enable_option("control_number_slave", "2");
		//enable_option("control_number_slave", "3");
		//enable_option("control_number_slave", "4");
		
		enable_checkbox("ControlCheckBox_AP", "label_AP");
		enable_checkbox("ControlCheckBox_APP", "label_APP");
		enable_checkbox("ControlCheckBox_RP", "label_RP");
		disable_checkbox("ControlCheckBox_EP", "label_EP");
		enable_checkbox("ControlCheckBox_T", "label_T");
		enable_checkbox("ControlCheckBox_VRMS", "label_VRMS");
		enable_checkbox("ControlCheckBox_IRMS", "label_IRMS");
		enable_checkbox("ControlCheckBox_PF", "label_PF");
		enable_checkbox("ControlCheckBox_F", "label_F");
		disable_checkbox("ControlCheckBox_T", "label_T");
		enable_checkbox("ControlCheckBox_3P", "label_3P");
		disable_checkbox("ControlCheckBox_1V", "label_1V");
		enable_checkbox("ControlSelectVoltageType", "label_vtype");
		enable_checkbox("ControlSelect_hwversion", "label_hwversion");
		
	}
	else if (v=="RPICT4W3T1" || v=="RPICT4V3T2"){
		enable_checkbox("control_number_slave", "label_nslave");
	
		//enable_option("control_number_slave", "2");
		enable_option("control_number_slave", "3");
		enable_option("control_number_slave", "4");
		
		enable_checkbox("ControlCheckBox_AP", "label_AP");
		enable_checkbox("ControlCheckBox_APP", "label_APP");
		enable_checkbox("ControlCheckBox_RP", "label_RP");
		disable_checkbox("ControlCheckBox_EP", "label_EP");
		enable_checkbox("ControlCheckBox_T", "label_T");
		enable_checkbox("ControlCheckBox_VRMS", "label_VRMS");
		enable_checkbox("ControlCheckBox_IRMS", "label_IRMS");
		enable_checkbox("ControlCheckBox_PF", "label_PF");
		enable_checkbox("ControlCheckBox_F", "label_F");
		enable_checkbox("ControlCheckBox_T", "label_T");
		enable_checkbox("ControlCheckBox_3P", "label_3P");
		disable_checkbox("ControlCheckBox_1V", "label_1V");
		enable_checkbox("ControlSelectVoltageType", "label_vtype");
		disable_checkbox("ControlSelect_hwversion", "label_hwversion");
		
	}
	else if (v=="RPICT3T1"){
		disable_checkbox("control_number_slave", "label_nslave");
		
		disable_checkbox("ControlCheckBox_AP", "label_AP");
		disable_checkbox("ControlCheckBox_APP", "label_APP");
		disable_checkbox("ControlCheckBox_RP", "label_RP");
		disable_checkbox("ControlCheckBox_EP", "label_EP");
		disable_checkbox("ControlCheckBox_T", "label_T");
		disable_checkbox("ControlCheckBox_VRMS", "label_VRMS");
		disable_checkbox("ControlCheckBox_IRMS", "label_IRMS");
		disable_checkbox("ControlCheckBox_PF", "label_PF");
		disable_checkbox("ControlCheckBox_F", "label_F");
		disable_checkbox("ControlCheckBox_T", "label_T");
		disable_checkbox("ControlCheckBox_3P", "label_3P");
		disable_checkbox("ControlCheckBox_1V", "label_1V");
		disable_checkbox("ControlSelectVoltageType", "label_vtype");
		disable_checkbox("ControlSelect_hwversion", "label_hwversion");
		
	}
	else if (v=="RPICT3V1"){
		disable_checkbox("control_number_slave", "label_nslave");

		
		disable_checkbox("ControlCheckBox_AP", "label_AP");
		disable_checkbox("ControlCheckBox_APP", "label_APP");// enable me 
		disable_checkbox("ControlCheckBox_RP", "label_RP");
		disable_checkbox("ControlCheckBox_EP", "label_EP");
		disable_checkbox("ControlCheckBox_T", "label_T");
		disable_checkbox("ControlCheckBox_VRMS", "label_VRMS");// enable me
		disable_checkbox("ControlCheckBox_IRMS", "label_IRMS");// enable me
		disable_checkbox("ControlCheckBox_PF", "label_PF");// enable me
		disable_checkbox("ControlCheckBox_F", "label_F");
		disable_checkbox("ControlCheckBox_T", "label_T");
		disable_checkbox("ControlCheckBox_3P", "label_3P");
		disable_checkbox("ControlCheckBox_1V", "label_1V");
		enable_checkbox("ControlSelectVoltageType", "label_vtype");
		disable_checkbox("ControlSelect_hwversion", "label_hwversion");
		
	}
	
	else {console.log("Error: Unknown Model")}
	
	generate_config();
}

function control_number_slave_changed(){
	generate_config();
}

function ControlInputVest_changed(){
	generate_config();
}

function ControlInputXpfreq_changed(){
	generate_config();
}

function ControlInputOrate_changed(){
	generate_config();
}


function ControlSelect_hwversion_changed(){
	generate_config();
}

function ControlCheckBox_AP_changed(){
	generate_config();
}

function ControlCheckBox_APP_changed(){
	generate_config();
}

function ControlCheckBox_RP_changed(){
	generate_config();
}

function ControlCheckBox_EP_changed(){
	generate_config();
}

function ControlCheckBox_T_changed(){
	generate_config();
}

function ControlCheckBox_IRMS_changed(){
	generate_config();
}

function ControlCheckBox_VRMS_changed(){
	generate_config();
}

function ControlCheckBox_F_changed(){
	generate_config();
}

function ControlCheckBox_PF_changed(){
	generate_config();
}

function ControlSelectCtType_changed(){
	generate_config();
}

function ControlSelectVoltageType_changed(){
	generate_config();
}

function ControlCheckBox_1V_changed(){
	generate_config();
}

function ControlCheckBox_3P_changed(){
	generate_config();
	var model = document.getElementById("ControlSelect_model").value;
	var is_3P = document.getElementById("ControlCheckBox_3P").checked;
	
	if (model=="RPICT4V3"){
		if (is_3P){
			enable_option("control_number_slave", "3");
			enable_option("control_number_slave", "4");
		}
		else{
			disable_option("control_number_slave", "3");
			disable_option("control_number_slave", "4");
			var nslave = document.getElementById("control_number_slave").value;
			if (nslave=="3" || nslave=="4"){
				document.getElementById("control_number_slave").value = "2";
			}
		}
	
	}
}


function disable_checkbox(select_id, label_id){	
	document.getElementById(select_id).setAttribute("disabled","disabled");
	document.getElementById(label_id).style.color = "grey";
}

function enable_checkbox(select_id, label_id){	
	document.getElementById(select_id).removeAttribute("disabled");
	document.getElementById(label_id).style.color = "black";
}


function enable_option(select_id, t_value) {
	var op = document.getElementById(select_id).getElementsByTagName("option");
	for (var i = 0; i < op.length; i++) {
	  if (op[i].value == t_value) {
	    op[i].disabled = false;
	  }
	}
}

function disable_option(select_id, t_value) {
	var op = document.getElementById(select_id).getElementsByTagName("option");
	for (var i = 0; i < op.length; i++) {
	  if (op[i].value == t_value) {
	    op[i].disabled = true;
	  }
	}
}

function model_to_modelID(model){
	if (model=="RPICT8"){
		return "0";
	}
	else if (model=="RPICT7V1"){
		return "1";
	}
	else if (model=="RPICT4V3"){
		return "2";
	}
	else if (model=="RPICT4W3T1" || model=="RPICT4V3T2"){
		return "2";
	}
	
	return "255";
}




function generate_config(){
	console.log("generate config");

	var config_text = "";
	var total_node = 0;
	
	var kcal = "";
	var ical, vcal;
	var out_format = "";
	var out_sensor = "";
	var ncycles = 20;
	
	var model = document.getElementById("ControlSelect_model").value;
	var modelID = model_to_modelID(model);
	
	var vest = document.getElementById("ControlInputVest").value;
	var freq = document.getElementById("ControlInputXpfreq").value;
	var orate = document.getElementById("ControlInput_orate").value;
	
	var is_AP = document.getElementById("ControlCheckBox_AP").checked;
	var is_APP = document.getElementById("ControlCheckBox_APP").checked;
	var is_RP = document.getElementById("ControlCheckBox_RP").checked;
	var is_EP = document.getElementById("ControlCheckBox_EP").checked;
	var is_T = document.getElementById("ControlCheckBox_T").checked;
	var is_IRMS = document.getElementById("ControlCheckBox_IRMS").checked;
	var is_VRMS = document.getElementById("ControlCheckBox_VRMS").checked;
	var is_F = document.getElementById("ControlCheckBox_F").checked;
	var is_PF = document.getElementById("ControlCheckBox_PF").checked;
	var is_3P = document.getElementById("ControlCheckBox_3P").checked;
	var is_1V = document.getElementById("ControlCheckBox_1V").checked;
	//var is_v3 = document.getElementById("ControlCheckBox_version3").checked;
	var hwversion = document.getElementById("ControlSelect_hwversion").value;
	
	var Nslaves = Number(document.getElementById("control_number_slave").value);
	
	var cttype = document.getElementById("ControlSelectCtType").value;
	var voltagetype = document.getElementById("ControlSelectVoltageType").value;
	
	
	ical = get_ical(cttype, model, hwversion);
	vcal = get_vcal(voltagetype, model, hwversion);
	
	var snode_pin = "";
	var snode_mcp = "";
	var pnode_pinI = "";
	var pnode_mcpI = "";
	var pnode_pinV = "";
	var pnode_mcpV = "";
	var tnode_pinI = "";
	var tnode_mcpI = "";
	var tnode_pinV = "";
	var tnode_mcpV = "";
	var fnode_pin = "";
	var fnode_mcp = "";
	var CHID = "";
	var CH_node_type = "";
	var CH_field_type = "";
	var sp, sm, u;
	var Nnodes = 0;
	var sNnodes = 0;
	
	if (model=="RPICT3T1"){
		config_text = "[main]\n";
		config_text += "format = 3\n";
		config_text += "nodeid = 11\n";
		config_text += "polling = "+orate+"\n";
		//kcal= " "+ical+" 1. 1. "+ical+" 1. 1. 1. "+ical;
		for (var i=0; i<8; i++){
			kcal += " "+ical;
		}
		config_text += "kcal ="+kcal+"\n";
		config_text += "phasecal = 0\n";
		config_text += "vest = "+vest+"\n";
		config_text += "xpFREQ = "+freq+"\n";
		config_text += "Ncycle = "+ncycles+"\n";
		config_text += "debug = 0\n";
		
		out_format = "EP1 EP2 EP3 [T1-T8]\n";
		out_sensor = "All inputs are independent.\nEstimated Power is computed against Estimated Voltage (Vest).";
		
		total_node = 3;
		
	}
	
	else if (model=="RPICT3V1"){
		config_text = "[main]\n";
		config_text += "format = 3\n";
		config_text += "nodeid = 11\n";
		config_text += "polling = "+orate+"\n";
		kcal= " "+ical+" "+ical+" "+ical+" 1. 1. 1. 1. "+vcal;
		config_text += "kcal ="+kcal+"\n";
		config_text += "phasecal = 0\n";
		config_text += "vest = "+vest+"\n";
		config_text += "xpFREQ = "+freq+"\n";
		config_text += "Ncycle = 20\n";
		//var dbg = 2*(!is_APP) + 4*(!is_IRMS) + 8*(!is_VRMS) + 16*(!is_PF);
		var dbg = "0";
		config_text += "debug = "+dbg+"\n";
		
		for (var i=0; i<3; i++){
			out_format += " P"+(i+1);
			if (is_APP) out_format += " S"+(i+1);
			if (is_IRMS) out_format += " Irms"+(i+1);
			if (is_VRMS) out_format += " Vrms"+(i+1);
			if (is_PF) out_format += " PF"+(i+1);
			
		}
		
		out_sensor = "CT1/V1 -> P1\n";
		out_sensor += "CT2/V1 -> P2\n";
		out_sensor += "CT3/V1 -> P3";
		
		total_node = 3;
	}
	
	else if (model=="RPICT8"){
	
		config_text = "[main]\n";
		config_text += "format = 3\n";
		config_text += "device_id = 11\n";
		config_text += "output_rate = "+orate+"\n";
		config_text += "phasecal = 0\n";
		
		
		kcal= "";
		for (i=0; i<40; i++){
			kcal += " "+ical;
		}
		
		config_text += "kcal ="+kcal+"\n";
		config_text += "vest = "+vest+"\n";
		config_text += "xpFREQ = "+freq+"\n";
		config_text += "Ncycle = 20\n";
		config_text += "debug = 0\n";
		config_text += "model = "+Nslaves+" "+modelID+" 0 0 0 0\n";
	
		
		for (i=0; i<Nslaves+1; i++){
			if (i==0) sm = 10;
			else sm  = 5 + i;
					
			for (j=0; j<8; j++){
				sp = 7 - j;
				snode_pin += " "+sp;
				snode_mcp += " "+sm;
				Nnodes++;
				total_node++;
			}
		}
		if (is_EP){				
			for (i=0; i<Nnodes; i++){				
				CHID += " "+i;
				CH_node_type += " 2";
				CH_field_type += " 5";
				out_format += " EP"+(i+1);
			}
		}
		if (is_IRMS){			
			for (i=0; i<Nnodes; i++){					
				CHID += " "+i;
				CH_node_type += " 2";
				CH_field_type += " 4";
				out_format += " Irms"+(i+1);
			}		
		}
		
		config_text += "snode_pin =" + snode_pin + "\n";
		config_text += "snode_mcp =" + snode_mcp + "\n";
		config_text += "pnode_pinI =" + pnode_pinI + "\n";
		config_text += "pnode_mcpI =" + pnode_mcpI + "\n";
		config_text += "pnode_pinV =" + pnode_pinV + "\n";
		config_text += "pnode_mcpV =" + pnode_mcpV + "\n";
		config_text += "tnode_pinI =" + tnode_pinI + "\n";
		config_text += "tnode_mcpI =" + tnode_mcpI + "\n";
		config_text += "tnode_pinV =" + tnode_pinV + "\n";
		config_text += "tnode_mcpV =" + tnode_mcpV + "\n";
		config_text += "fnode_pin =" + fnode_pin + "\n";
		config_text += "fnode_mcp =" + fnode_mcp + "\n";
		config_text += "CHID =" + CHID + "\n";
		config_text += "CH_node_type =" + CH_node_type + "\n";
		config_text += "CH_field_type =" + CH_field_type + "\n";
		
		
		
		out_sensor = "All inputs are independent.\nEstimated Power is computed against Estimated Voltage (Vest)."
	} // if model==RPICT8
	
	
	else if (model=="RPICT7V1"){
	
		config_text = "[main]\n";
		config_text += "format = 3\n";
		config_text += "device_id = 11\n";
		config_text += "output_rate = "+orate+"\n";
		
		config_text += "phasecal = 0\n";
		
		kcal= "";
		for (i=0; i<40; i++){
			if (i==0) kcal += " "+vcal;
			else kcal += " "+ical;
		}
		
		config_text += "kcal ="+kcal+"\n";
		config_text += "vest = "+vest+"\n";
		config_text += "xpFREQ = "+freq+"\n";
		config_text += "Ncycle = 20\n";
		config_text += "debug = 0\n";
		config_text += "model = "+Nslaves+" "+modelID+" 0 0 0 0\n";
	
	
		if (Nslaves==0){
			out_sensor = "CT1/V1 -> P1\nCT2/V1 -> P2\nCT3/V1 -> P3\nCT4/V1 -> P4\nCT5/V1 -> P5\nCT6/V1 -> P6\nCT7/V1 -> P7\n";
		}
		else if (Nslaves==1){
			out_sensor = "CT1 master/V1 -> P1\nCT2 master/V1 -> P2\nCT3 master/V1 -> P3\nCT4 master/V1 -> P4\nCT5 master/V1 -> P5\nCT6 master/V1 -> P6\nCT7 master/V1 -> P7\n";
			out_sensor += "CT1 slave1/V1 -> P8\nCT2 slave1/V1 -> P9\nCT3 slave1/V1 -> P10\nCT4 slave1/V1 -> P11\nCT5 slave1/V1 -> P12\nCT6 slave1/V1 -> P13\nCT7 slave1/V1 -> P14\nCT8 slave1/V1 -> P15\n";
		}
		else if (Nslaves==2){
			out_sensor = "CT1 master/V1 -> P1\nCT2 master/V1 -> P2\nCT3 master/V1 -> P3\nCT4 master/V1 -> P4\nCT5 master/V1 -> P5\nCT6 master/V1 -> P6\nCT7 master/V1 -> P7\n";
			out_sensor += "CT1 slave1/V1 -> P8\nCT2 slave1/V1 -> P9\nCT3 slave1/V1 -> P10\nCT4 slave1/V1 -> P11\nCT5 slave1/V1 -> P12\nCT6 slave1/V1 -> P13\nCT7 slave1/V1 -> P14\nCT8 slave1/V1 -> P15\n";
			out_sensor += "CT1 slave2/V1 -> P16\nCT2 slave2/V1 -> P17\nCT3 slave2/V1 -> P18\nCT4 slave2/V1 -> P19\nCT5 slave2/V1 -> P20\nCT6 slave2/V1 -> P21\nCT7 slave2/V1 -> P22\nCT8 slave2/V1 -> P23\n";
		
		}
		else if (Nslaves==3){
			out_sensor = "CT1 master/V1 -> P1\nCT2 master/V1 -> P2\nCT3 master/V1 -> P3\nCT4 master/V1 -> P4\nCT5 master/V1 -> P5\nCT6 master/V1 -> P6\nCT7 master/V1 -> P7\n";
			out_sensor += "CT1 slave1/V1 -> P8\nCT2 slave1/V1 -> P9\nCT3 slave1/V1 -> P10\nCT4 slave1/V1 -> P11\nCT5 slave1/V1 -> P12\nCT6 slave1/V1 -> P13\nCT7 slave1/V1 -> P14\nCT8 slave1/V1 -> P15\n";
			out_sensor += "CT1 slave2/V1 -> P16\nCT2 slave2/V1 -> P17\nCT3 slave2/V1 -> P18\nCT4 slave2/V1 -> P19\nCT5 slave2/V1 -> P20\nCT6 slave2/V1 -> P21\nCT7 slave2/V1 -> P22\nCT8 slave2/V1 -> P23\n";
			out_sensor += "CT1 slave3/V1 -> P24\nCT2 slave3/V1 -> P25\nCT3 slave3/V1 -> P26\nCT4 slave3/V1 -> P27\nCT5 slave3/V1 -> P28\nCT6 slave3/V1 -> P29\nCT7 slave3/V1 -> P30\nCT8 slave3/V1 -> P31\n";
			
		
		}
		
		for (i=0; i<Nslaves+1; i++){
			if (i==0) sm = 10;
			else sm  = 5 + i;
					
			for (j=0; j<8; j++){
				//if (Nnodes<31){
					sp = 7 - j;
					if (sp!=0 || sm!=10){
						pnode_pinI += " "+sp;
						pnode_mcpI += " "+sm;
						pnode_pinV += " 0";
						pnode_mcpV += " 10";
						Nnodes++;
						total_node++;
					}
				//}
			}
		}
		if (is_AP){			
			for (i=0; i<Nnodes; i++){					
				CHID += " "+i;
				CH_node_type += " 3";
				CH_field_type += " 1";
				out_format += " P"+(i+1);
				
			}
		}
		if (is_APP){		
			for (i=0; i<Nnodes; i++){					
				CHID += " "+i;
				CH_node_type += " 3";
				CH_field_type += " 2";
				out_format += " S"+(i+1);
			}
		}
		if (is_RP){			
			for (i=0; i<Nnodes; i++){					
				CHID += " "+i;
				CH_node_type += " 3";
				CH_field_type += " 10";
				out_format += " Q"+(i+1);
			}
		}
		
		if (is_IRMS){			
			for (i=0; i<Nnodes; i++){					
				CHID += " "+i;
				CH_node_type += " 3";
				CH_field_type += " 4";
				out_format += " Irms"+(i+1);
			}		
		}
		if (is_VRMS){	
			if (is_1V){	
				CHID += " 0";
				CH_node_type += " 3";
				CH_field_type += " 3";
				out_format += " Vrms1";
			}
			else {					
				
				for (i=0; i<Nnodes; i++){					
					CHID += " "+i;
					CH_node_type += " 3";
					CH_field_type += " 3";
					out_format += " Vrms"+(i+1);
				}
			}	
		}
		if (is_PF){			
			for (i=0; i<Nnodes; i++){					
				CHID += " "+i;
				CH_node_type += " 3";
				CH_field_type += " 6";
				out_format += " PF"+(i+1);
			}		
		}
		if (is_F){
			CHID += " 0";
			CH_node_type += " 4";
			CH_field_type += " 8";
			fnode_pin = " 0";
			fnode_mcp = " 10";
			out_format += " F1";
			out_sensor += "V1 -> F01 (Frequency)\n";
				
		}
		
		config_text += "snode_pin =" + snode_pin + "\n";
		config_text += "snode_mcp =" + snode_mcp + "\n";
		config_text += "pnode_pinI =" + pnode_pinI + "\n";
		config_text += "pnode_mcpI =" + pnode_mcpI + "\n";
		config_text += "pnode_pinV =" + pnode_pinV + "\n";
		config_text += "pnode_mcpV =" + pnode_mcpV + "\n";
		config_text += "tnode_pinI =" + tnode_pinI + "\n";
		config_text += "tnode_mcpI =" + tnode_mcpI + "\n";
		config_text += "tnode_pinV =" + tnode_pinV + "\n";
		config_text += "tnode_mcpV =" + tnode_mcpV + "\n";
		config_text += "fnode_pin =" + fnode_pin + "\n";
		config_text += "fnode_mcp =" + fnode_mcp + "\n";
		config_text += "CHID =" + CHID + "\n";
		config_text += "CH_node_type =" + CH_node_type + "\n";
		config_text += "CH_field_type =" + CH_field_type + "\n";
		
		
	} // if model==RPICT7V1
	
	else if (model=="RPICT4V3" || model=="RPICT4W3T1" || model=="RPICT4V3T2"){
	
		config_text = "[main]\n";
		config_text += "format = 3\n";
		config_text += "device_id = 11\n";
		config_text += "output_rate = "+orate+"\n";
		
		config_text += "phasecal = 0\n";
		
		kcal= "";
		for (i=0; i<40; i++){
			if (i<3) kcal += " "+vcal;
			else kcal += " "+ical;
		}
		
		config_text += "kcal ="+kcal+"\n";
		config_text += "vest = "+vest+"\n";
		config_text += "xpFREQ = "+freq+"\n";
		config_text += "Ncycle = 20\n";
		config_text += "debug = 0\n";
		config_text += "model = "+Nslaves+" "+modelID+" 0 0 0 0\n";
	
	
	
	
		if (is_3P){
			if (Nslaves==0){
				tnode_pinI = " 7 6 5";
				tnode_mcpI = " 10 10 10";
				tnode_pinV = " 2 1 0";
				tnode_mcpV = " 10 10 10";
				snode_pin = " 4";
				snode_mcp = " 10";
				Nnodes = 1;
				sNnodes = 1;
				total_node += 2;
				out_sensor = "CT1/V1 -> P1(L1)\nCT2/V2 -> P1(L2)\nCT3/V3 -> P1(L3)\n";
				out_sensor += "CT4 -> Irms2";
			}
			else if (Nslaves==1){
				tnode_pinI = " 7 6 5 7 6 5 3 2 1 4 4 0";
				tnode_mcpI = " 10 10 10 6 6 6 6 6 6 10 6 6";
				tnode_pinV = " 2 1 0 2 1 0 2 1 0 2 1 0";
				tnode_mcpV = " 10 10 10 10 10 10 10 10 10 10 10 10";
				Nnodes = 4;
				total_node = 4;
				out_sensor = "CT1 master/V1 -> Y1(L1)\nCT2 master/V2 -> Y1(L2)\nCT3 master/V3 -> Y1(L3)\n\n"
				out_sensor += "CT1 slave1/V1 -> Y2(L1)\nCT2 slave1/V2 -> Y2(L2)\nCT3 slave1/V3 -> Y2(L3)\n\n"
				out_sensor += "CT5 slave1/V1 -> Y3(L1)\nCT6 slave1/V2 -> Y3(L2)\nCT7 slave1/V3 -> Y3(L3)\n\n"
				out_sensor += "CT4 master/V1 -> Y4(L1)\nCT4 slave1/V2 -> Y4(L2)\nCT8 slave1/V3 -> Y4(L3)"
			}
			else if (Nslaves==2){
				tnode_pinI = " 7 6 5 7 6 5 3 2 1 7 6 5 3 2 1 4 4 0";
				tnode_mcpI = " 10 10 10 6 6 6 6 6 6 7 7 7 7 7 7 10 6 6";
				tnode_pinV = " 2 1 0 2 1 0 2 1 0 2 1 0 2 1 0 2 1 0";
				tnode_mcpV = " 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10";
				Nnodes = 6;
				total_node = 6;
				out_sensor = "CT1 master/V1 -> Y1(L1)\nCT2 master/V2 -> Y1(L2)\nCT3 master/V3 -> Y1(L3)\n\n"
				out_sensor += "CT1 slave1/V1 -> Y2(L1)\nCT2 slave1/V2 -> Y2(L2)\nCT3 slave1/V3 -> Y2(L3)\n\n"
				out_sensor += "CT5 slave1/V1 -> Y3(L1)\nCT6 slave1/V2 -> Y3(L2)\nCT7 slave1/V3 -> Y3(L3)\n\n"
				out_sensor += "CT1 slave2/V1 -> Y4(L1)\nCT2 slave2/V2 -> Y4(L2)\nCT3 slave2/V3 -> Y4(L3)\n\n"
				out_sensor += "CT5 slave2/V1 -> Y5(L1)\nCT6 slave2/V2 -> Y5(L2)\nCT7 slave2/V3 -> Y5(L3)\n\n"
				out_sensor += "CT4 master/V1 -> Y6(L1)\nCT4 slave1/V2 -> Y6(L2)\nCT8 slave1/V3 -> Y6(L3)\n\n"
			}
			else if (Nslaves==3){
				tnode_pinI = " 7 6 5 7 6 5 3 2 1 7 6 5 3 2 1 7 6 5 3 2 1 4 4 4 0 0 0";
				tnode_mcpI = " 10 10 10 6 6 6 6 6 6 7 7 7 7 7 7 8 8 8 8 8 8 10 6 7 6 7 8";
				tnode_pinV = " 2 1 0 2 1 0 2 1 0 2 1 0 2 1 0 2 1 0 2 1 0 2 1 0 2 1 0";
				tnode_mcpV = " 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10";
				Nnodes = 9;
				total_node = 9;
				out_sensor = "CT1 master/V1 -> Y1(L1)\nCT2 master/V2 -> Y1(L2)\nCT3 master/V3 -> Y1(L3)\n\n"
				out_sensor += "CT1 slave1/V1 -> Y2(L1)\nCT2 slave1/V2 -> Y2(L2)\nCT3 slave1/V3 -> Y2(L3)\n\n"
				out_sensor += "CT5 slave1/V1 -> Y3(L1)\nCT6 slave1/V2 -> Y3(L2)\nCT7 slave1/V3 -> Y3(L3)\n\n"
				out_sensor += "CT1 slave2/V1 -> Y4(L1)\nCT2 slave2/V2 -> Y4(L2)\nCT3 slave2/V3 -> Y4(L3)\n\n"
				out_sensor += "CT5 slave2/V1 -> Y5(L1)\nCT6 slave2/V2 -> Y5(L2)\nCT7 slave2/V3 -> Y5(L3)\n\n"
				out_sensor += "CT1 slave3/V1 -> Y6(L1)\nCT2 slave3/V2 -> Y6(L2)\nCT3 slave3/V3 -> Y6(L3)\n\n"
				out_sensor += "CT5 slave3/V1 -> Y7(L1)\nCT6 slave3/V2 -> Y7(L2)\nCT7 slave3/V3 -> Y7(L3)\n\n"
				out_sensor += "CT4 master/V1 -> Y8(L1)\nCT4 slave1/V2 -> Y8(L2)\nCT4 slave2/V3 -> Y8(L3)\n\n"
				out_sensor += "CT8 slave1/V1 -> Y9(L1)\nCT8 slave2/V2 -> Y9(L2)\nCT8 slave3/V3 -> Y9(L3)\n\n"
			}
			else if (Nslaves==4){
				tnode_pinI = " 7 6 5 7 6 5 3 2 1 7 6 5 3 2 1 7 6 5 3 2 1 7 6 5 3 2 1 4 4 4";
				tnode_mcpI = " 10 10 10 6 6 6 6 6 6 7 7 7 7 7 7 8 8 8 8 8 8 9 9 9 9 9 9 10 6 7";
				tnode_pinV = " 2 1 0 2 1 0 2 1 0 2 1 0 2 1 0 2 1 0 2 1 0 2 1 0 2 1 0 2 1 0";
				tnode_mcpV = " 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10";
				Nnodes = 10;
				total_node = 10;
				out_sensor = "CT1 master/V1 -> Y1(L1)\nCT2 master/V2 -> Y1(L2)\nCT3 master/V3 -> Y1(L3)\n\n"
				out_sensor += "CT1 slave1/V1 -> Y2(L1)\nCT2 slave1/V2 -> Y2(L2)\nCT3 slave1/V3 -> Y2(L3)\n\n"
				out_sensor += "CT5 slave1/V1 -> Y3(L1)\nCT6 slave1/V2 -> Y3(L2)\nCT7 slave1/V3 -> Y3(L3)\n\n"
				out_sensor += "CT1 slave2/V1 -> Y4(L1)\nCT2 slave2/V2 -> Y4(L2)\nCT3 slave2/V3 -> Y4(L3)\n\n"
				out_sensor += "CT5 slave2/V1 -> Y5(L1)\nCT6 slave2/V2 -> Y5(L2)\nCT7 slave2/V3 -> Y5(L3)\n\n"
				out_sensor += "CT1 slave3/V1 -> Y6(L1)\nCT2 slave3/V2 -> Y6(L2)\nCT3 slave3/V3 -> Y6(L3)\n\n"
				out_sensor += "CT5 slave3/V1 -> Y7(L1)\nCT6 slave3/V2 -> Y7(L2)\nCT7 slave3/V3 -> Y7(L3)\n\n"
				out_sensor += "CT1 slave4/V1 -> Y8(L1)\nCT2 slave4/V2 -> Y8(L2)\nCT3 slave4/V3 -> Y8(L3)\n\n"
				out_sensor += "CT5 slave4/V1 -> Y9(L1)\nCT6 slave4/V2 -> 9(L2)\nCT7 slave4/V3 -> Y9(L3)\n\n"
				out_sensor += "CT4 master/V1 -> Y10(L1)\nCT4 slave1/V2 -> Y10(L2)\nCT4 slave2/V3 -> Y10(L3)\n\n"
				
			}
			
			
			if (is_AP){			
				for (i=0; i<Nnodes; i++){					
					CHID += " "+i;
					CH_node_type += " 5";
					CH_field_type += " 11";
					out_format += " P"+(i+1)+"(L1)"+" P"+(i+1)+"(L2)"+" P"+(i+1)+"(L3)";
				}
			}
			if (is_APP){				
				for (i=0; i<Nnodes; i++){					
					CHID += " "+i;
					CH_node_type += " 5";
					CH_field_type += " 12";
					out_format += " S"+(i+1)+"(L1)"+" S"+(i+1)+"(L2)"+" S"+(i+1)+"(L3)";
				}
			}
			if (is_RP){			
				for (i=0; i<Nnodes; i++){					
					CHID += " "+i;
					CH_node_type += " 5";
					CH_field_type += " 13";
					out_format += " Q"+(i+1)+"(L1)"+" Q"+(i+1)+"(L2)"+" Q"+(i+1)+"(L3)";
				}
			}
			if (is_EP){	

			}
			if (is_IRMS){		
				for (i=0; i<Nnodes; i++){					
					CHID += " "+i;
					CH_node_type += " 5";
					CH_field_type += " 16";
					out_format += " Irms"+(i+1)+"(L1)"+" Irms"+(i+1)+"(L2)"+" Irms"+(i+1)+"(L3)";
				}
				for (i=0; i<sNnodes; i++){					
					CHID += " "+i;
					CH_node_type += " 2";
					CH_field_type += " 4";
					out_format += " Irms"+(Nnodes+i+1);
				}
			
			}
			
			if (is_VRMS){		
				for (i=0; i<Nnodes; i++){					
					CHID += " "+i;
					CH_node_type += " 5";
					CH_field_type += " 15";
					out_format += " Vrms"+(i+1)+"(L1)"+" Vrms"+(i+1)+"(L2)"+" Vrms"+(i+1)+"(L3)";
				}		
			}
			
			if (is_F){
				CHID += " 0 1 2";
				CH_node_type += " 4 4 4";
				CH_field_type += " 8 8 8";
				fnode_pin = " 2 1 0";
				fnode_mcp = " 10 10 10";
				out_format += " F(L1)"+" F(L2)"+" F(L3)";
					
			}
			
			if (is_PF){			
				for (i=0; i<Nnodes; i++){					
					CHID += " "+i;
					CH_node_type += " 5";
					CH_field_type += " 14";
					out_format += " PF"+(i+1)+"(L1)"+" PF"+(i+1)+"(L2)"+" PF"+(i+1)+"(L3)";
				}		
			}
	
			
		}
		else{ // not is_3P
			if (Nslaves==0){
				pnode_pinI = " 7 6 5";
				pnode_mcpI = " 10 10 10";
				pnode_pinV = " 2 1 0";
				pnode_mcpV = " 10 10 10";
				snode_pin = " 4";
				snode_mcp = " 10";
				Nnodes = 3;
				sNnodes = 1;
				total_node = 4;
				out_sensor = "CT1/V1 -> P1\nCT2/V2 -> P2\nCT3/V3 -> P3\n";
				out_sensor += "CT4 -> Irms4"
			}
			else if (Nslaves==1){
				pnode_pinI = " 7 6 5 4 7 6 5 4 3 2 1 0";
				pnode_mcpI = " 10 10 10 10 6 6 6 6 6 6 6 6";
				pnode_pinV = " 2 2 2 2 1 1 1 1 0 0 0 0";
				pnode_mcpV = " 10 10 10 10 10 10 10 10 10 10 10 10";
				Nnodes = 12;
				total_node = 12;
				out_sensor = "CT1 master/V1 -> P1\nCT2 master/V1 -> P2\nCT3 master/V1 -> P3\nCT4 master/V1 -> P4\n\n"
				out_sensor += "CT1 slave1/V2 -> P5\nCT2 slave1/V2 -> P6\nCT3 slave1/V2 -> P7\nCT4 slave1/V2 -> P8\n\n"
				out_sensor += "CT5 slave1/V3 -> P9\nCT6 slave1/V3 -> P10\nCT7 slave1/V3 -> P11\nCT8 slave1/V3 -> P12\n"
				
			}
			else if (Nslaves==2){
				pnode_pinI = " 7 6 5 4 7 6 5 4 3 2 1 0 3 2 1 0 7 6 5 4";
				pnode_mcpI = " 10 10 10 10 6 6 6 6 6 6 6 6 7 7 7 7 7 7 7 7";
				pnode_pinV = " 2 2 2 2 2 2 2 2 1 1 1 1 1 1 1 1 0 0 0 0";
				pnode_mcpV = " 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10";
				Nnodes = 20;
				total_node = 20;
				out_sensor = "CT1 master/V1 -> P1\nCT2 master/V1 -> P2\nCT3 master/V1 -> P3\nCT4 master/V1 -> P4\n"
				out_sensor += "CT1 slave1/V1 -> P5\nCT2 slave1/V1 -> P6\nCT3 slave1/V1 -> P7\nCT4 slave1/V1 -> P8\n\n"
				out_sensor += "CT5 slave1/V2 -> P9\nCT6 slave1/V2 -> P10\nCT7 slave1/V2 -> P11\nCT8 slave1/V2 -> P12\n"
				out_sensor += "CT5 slave2/V2 -> P13\nCT6 slave2/V2 -> P14\nCT7 slave2/V2 -> P15\nCT8 slave2/V2 -> P16\n\n"
				out_sensor += "CT1 slave2/V3 -> P17\nCT2 slave2/V3 -> P18\nCT3 slave2/V3 -> P19\nCT4 slave2/V3 -> P20\n"
				
			}
			else if (Nslaves==3){
				pnode_pinI = " 7 6 5 4 7 6 5 4 3 2 1 0 3 2 1 0 7 6 5 4 7 6 5 4 3 2 1 0";
				pnode_mcpI = " 10 10 10 10 6 6 6 6 6 6 6 6 7 7 7 7 7 7 7 7 8 8 8 8 8 8 8 8";
				pnode_pinV = " 2 2 2 2 2 2 2 2 1 1 1 1 1 1 1 1 0 0 0 0 0 0 0 0 1 1 1 1";
				pnode_mcpV = " 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10";
				Nnodes = 28;
				total_node = 28;
				out_sensor = "CT1 master/V1 -> P1\nCT2 master/V1 -> P2\nCT3 master/V1 -> P3\nCT4 master/V1 -> P4\n"
				out_sensor += "CT1 slave1/V1 -> P5\nCT2 slave1/V1 -> P6\nCT3 slave1/V1 -> P7\nCT4 slave1/V1 -> P8\n\n"
				out_sensor += "CT5 slave1/V2 -> P9\nCT6 slave1/V2 -> P10\nCT7 slave1/V2 -> P11\nCT8 slave1/V2 -> P12\n"
				out_sensor += "CT5 slave2/V2 -> P13\nCT6 slave2/V2 -> P14\nCT7 slave2/V2 -> P15\nCT8 slave2/V2 -> P16\n\n"
				out_sensor += "CT1 slave2/V3 -> P17\nCT2 slave2/V3 -> P18\nCT3 slave2/V3 -> P19\nCT4 slave2/V3 -> P20\n"
				out_sensor += "CT1 slave3/V3 -> P21\nCT2 slave3/V3 -> P22\nCT3 slave3/V3 -> P23\nCT4 slave3/V3 -> P24\n\n"
				out_sensor += "CT5 slave3/V2 -> P25\nCT6 slave3/V2 -> P26\nCT7 slave3/V2 -> P27\nCT8 slave3/V2 -> P28\n"
				
				
			}
			else if (Nslaves==4){
				pnode_pinI = " 7 6 5 4 7 6 5 4 3 2 1 0 3 2 1 0 7 6 5 4";
				pnode_mcpI = " 10 10 10 10 6 6 6 6 6 6 6 6 7 7 7 7 7 7 7 7";
				pnode_pinV = " 2 2 2 2 2 2 2 2 1 1 1 1 1 1 1 1 0 0 0 0";
				pnode_mcpV = " 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10 10";
				Nnodes = 20;
				total_node = 20;
				out_sensor = "CT1 master/V1 -> P1\nCT2 master/V1 -> P2\nCT3 master/V1 -> P3\nCT4 master/V1 -> P4\n"
				out_sensor += "CT1 slave1/V1 -> P5\nCT2 slave1/V1 -> P6\nCT3 slave1/V1 -> P7\nCT4 slave1/V1 -> P8\n\n"
				out_sensor += "CT5 slave1/V2 -> P9\nCT6 slave1/V2 -> P10\nCT7 slave1/V2 -> P11\nCT8 slave1/V2 -> P12\n"
				out_sensor += "CT5 slave2/V2 -> P13\nCT6 slave2/V2 -> P14\nCT7 slave2/V2 -> P15\nCT8 slave2/V2 -> P16\n\n"
				out_sensor += "CT1 slave2/V3 -> P17\nCT2 slave2/V3 -> P18\nCT3 slave2/V3 -> P19\nCT4 slave2/V3 -> P20\n"
				
			}
			
			if (is_AP){			
				for (i=0; i<Nnodes; i++){					
					CHID += " "+i;
					CH_node_type += " 3";
					CH_field_type += " 1";
					out_format += " P"+(i+1);
				}
			}
			if (is_APP){				
				for (i=0; i<Nnodes; i++){					
					CHID += " "+i;
					CH_node_type += " 3";
					CH_field_type += " 2";
					out_format += " S"+(i+1);
				}
			}
			if (is_RP){			
				for (i=0; i<Nnodes; i++){					
					CHID += " "+i;
					CH_node_type += " 3";
					CH_field_type += " 10";
					out_format += " Q"+(i+1);
				}
			}
			if (is_EP){	

			}
			if (is_IRMS){		
				for (i=0; i<Nnodes; i++){					
					CHID += " "+i;
					CH_node_type += " 3";
					CH_field_type += " 4";
					out_format += " Irms"+(i+1);
				}
				for (i=0; i<sNnodes; i++){					
					CHID += " "+i;
					CH_node_type += " 2";
					CH_field_type += " 4";
					out_format += " Irms"+(Nnodes+i+1);
				}
			
			}
			
			if (is_VRMS){		
				for (i=0; i<Nnodes; i++){					
					CHID += " "+i;
					CH_node_type += " 3";
					CH_field_type += " 3";
					out_format += " Vrms"+(i+1);
				}		
			}
			
			if (is_F){
				CHID += " 0 1 2";
				CH_node_type += " 4 4 4";
				CH_field_type += " 8 8 8";
				fnode_pin = " 2 1 0";
				fnode_mcp = " 10 10 10";
				out_format += " F1"+" F2"+" F3";
					
			}
			
			if (is_PF){			
				for (i=0; i<Nnodes; i++){					
					CHID += " "+i;
					CH_node_type += " 3";
					CH_field_type += " 6";
					out_format += " PF"+(i+1);
				}		
			}
			
		
		}
	
		if (model=="RPICT4W3T1"){
			if (is_T){
				CHID += " 255";
				CH_node_type += " 255";
				CH_field_type += " 7";
				out_format += " [T1-T32]";
			}
		}
		
		if (model=="RPICT4V3T2"){
			if (is_T){
				CHID += " 255 255";
				CH_node_type += " 255 255";
				CH_field_type += " 9 7";
				out_format += " RTD [T1-T32]";
			}
		}
		
		config_text += "snode_pin =" + snode_pin + "\n";
		config_text += "snode_mcp =" + snode_mcp + "\n";
		config_text += "pnode_pinI =" + pnode_pinI + "\n";
		config_text += "pnode_mcpI =" + pnode_mcpI + "\n";
		config_text += "pnode_pinV =" + pnode_pinV + "\n";
		config_text += "pnode_mcpV =" + pnode_mcpV + "\n";
		config_text += "tnode_pinI =" + tnode_pinI + "\n";
		config_text += "tnode_mcpI =" + tnode_mcpI + "\n";
		config_text += "tnode_pinV =" + tnode_pinV + "\n";
		config_text += "tnode_mcpV =" + tnode_mcpV + "\n";
		config_text += "fnode_pin =" + fnode_pin + "\n";
		config_text += "fnode_mcp =" + fnode_mcp + "\n";
		config_text += "CHID =" + CHID + "\n";
		config_text += "CH_node_type =" + CH_node_type + "\n";
		config_text += "CH_field_type =" + CH_field_type + "\n";
	
	} // if model==RPICT4V3
	
	document.getElementById("config_pre").innerHTML = config_text;
	document.getElementById("format_pre").innerHTML = out_format;
	document.getElementById("sensor_pre").innerHTML = out_sensor;


	config_hash = hashFnv32a(config_text, true);
	var summary_pre = "Checksum: "+config_hash;
	summary_pre += "\nTotal Nodes: "+total_node;
	summary_pre += "\nMinimum Output Rate: " +total_node*ncycles/freq +" seconds";
	
	document.getElementById("summary_pre").innerHTML = summary_pre;
	
	localStorage.setItem("basic_config_text", config_text);

}









