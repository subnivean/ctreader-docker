

// GLOBAL CONFIGURATION

var is_online = false;

function fileOpenClicked(){
	
	document.getElementById("file_dialogue").click();
	
}

function openFile(event){
	var input = event.target;
        var reader = new FileReader();
        
        reader.onload = function(){
        
        	var text = reader.result;
        	document.getElementById("response").innerHTML = '<span style="color:green">Configuration loaded from file.</span>'
        	if (config_mode=="basic"){
        		document.getElementById("response").innerHTML += '<br><span style="color:orange">Warning. Features added in full configuration will not be preserved.</span>';
        	}

		
        	populate_config(text);
        	generate_config();

        }// funct
        
        if (input.files[0]){
        	reader.readAsText(input.files[0]);
        }

}


// Function to generate hash
function hashFnv32a(str, asString, seed) {
    /*jshint bitwise:false */
    var i, l,
        hval = (seed === undefined) ? 0x811c9dc5 : seed;

    for (i = 0, l = str.length; i < l; i++) {
        hval ^= str.charCodeAt(i);
        hval += (hval << 1) + (hval << 4) + (hval << 7) + (hval << 8) + (hval << 24);
    }
    if( asString ){
        // Convert to 8 digit hex string
        return ("0000000" + (hval >>> 0).toString(16)).substr(-8);
    }
    return hval >>> 0;
}


function post_data(){

	if (is_online){
		alert('This function is disabled on the online version');
		return;
	}

	//console.log("clicked");
	document.getElementById("response").innerHTML = "upload request sent...";
	var xhr = new XMLHttpRequest();

	
	xhr.open("POST", "/cgi-bin/process_config.py");
	xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

	
	var cfg_txt = document.getElementById("config_pre").innerHTML;
	
	xhr.send("config="+cfg_txt+"");

	
	xhr.onload = function() {
		console.log(`Loaded: ${xhr.status} ${xhr.response}`);
		var r = JSON.parse(xhr.response);
		//document.getElementById("response").innerHTML = xhr.response;
		if (r.success=="true"){
			document.getElementById("response").innerHTML = "Configuration Uploaded.";
		}
		else {
			document.getElementById("response").innerHTML = '<span style="color:red">'+r.error+'</span>';
		}
	};

	xhr.onerror = function() { // only triggers if the request couldn't be made at all
		console.log(`Network Error`);
		document.getElementById("response").innerHTML = '<span style="color:red">Network Error!</span>';
	};

	
}

function fuser_check(){
	var xmlhttp = new XMLHttpRequest();
	var url = "/cgi-bin/fuser_check.py";

	xmlhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			
        		var r = JSON.parse(this.responseText);
        		console.log(r.fuser_check);
        		document.getElementById("response_fuser").innerHTML = r.fuser_check;
        		
		}
	};
	xmlhttp.open("GET", url, true);
	xmlhttp.send();

}


// For the file save
function destroyClickedElement(event) {
  // remove the link from the DOM
  document.body.removeChild(event.target);
}

function save_to_file(e){

  var textToWrite = document.getElementById('config_pre').innerHTML;
  var textFileAsBlob = new Blob([ textToWrite ], { type: 'text/plain' });
  var fileNameToSaveAs = Math.floor(new Date().getTime()/1000)+"_rpict.conf"; //filename.extension

  var downloadLink = document.createElement("a");
  downloadLink.download = fileNameToSaveAs;
  downloadLink.innerHTML = "Download File";
  if (window.webkitURL != null) {
    // Chrome allows the link to be clicked without actually adding it to the DOM.
    downloadLink.href = window.webkitURL.createObjectURL(textFileAsBlob);
  } 
  else {
    // Firefox requires the link to be added to the DOM before it can be clicked.
    downloadLink.href = window.URL.createObjectURL(textFileAsBlob);
    downloadLink.onclick = destroyClickedElement;
    downloadLink.style.display = "none";
    document.body.appendChild(downloadLink);
  }

  downloadLink.click();

}

var ICALS = [{ical:"74.074", cttype:"SCT-013-000 (100A)", version:"V5"},
	     {ical:"83.33", cttype:"SCT-013-000 (100A)", version:"V3"},
	     {ical:"42.553", cttype:"SCT-013-000 (60A)", version:"V5"},
	     {ical:"51.28", cttype:"SCT-013-000 (60A)", version:"V3"},
	     {ical:"35.714", cttype:"SCT-013-000 (50A)", version:"V5"},
	     {ical:"42.55", cttype:"SCT-013-000 (50A)", version:"V3"},
	     {ical:"27.972", cttype:"SCT-013-000 (40A)", version:"V5"},
	     {ical:"35.59", cttype:"SCT-013-000 (40A)", version:"V3"},
	     {ical:"21.978", cttype:"SCT-013-000 (30A)", version:"V5"},
	     {ical:"26.67", cttype:"SCT-013-000 (30A)", version:"V3"},
	     {ical:"14.286", cttype:"SCT-013-000 (20A)", version:"V5"},
	     {ical:"16.67", cttype:"SCT-013-000 (20A)", version:"V3"},
	     {ical:"14.286", cttype:"SCT-006 (20A)", version:"V5"},
	     {ical:"17.02", cttype:"SCT-006 (20A)", version:"V3"},
	     {ical:"139.535", cttype:"SCT-019 (200A)", version:"V5"},
	     {ical:"181.82", cttype:"SCT-019 (200A)", version:"V3"},
	     {ical:"279.72", cttype:"SCT-024 (400A)", version:"V5"},
	     {ical:"333.33", cttype:"SCT-024 (400A)", version:"V3"},
	     {ical:"419.58", cttype:"SCT-031 (600A)", version:"V5"},
	     {ical:"500.00", cttype:"SCT-031 (600A)", version:"V3"},
	     ];
	     
var VCALS = [{vcal:"256.6", vtype:"UK AC/AC Wall Plug", version:"V5"},
	     {vcal:"635.0", vtype:"UK AC/AC Wall Plug", version:"V3"},
	     {vcal:"248.1", vtype:"EU AC/AC Wall Plug", version:"V5"},
	     {vcal:"614.0", vtype:"EU AC/AC Wall Plug", version:"V3"},
	     {vcal:"124.0", vtype:"US AC/AC Wall Plug", version:"V5"},
	     {vcal:"307.0", vtype:"US AC/AC Wall Plug", version:"V3"},
	     {vcal:"200.43", vtype:"ZMPT 280V", version:"V5"},
	     {vcal:"249.34", vtype:"ZMPT 280V", version:"V3"},
	     {vcal:"100.21", vtype:"ZMPT 140V", version:"V5"},
	     {vcal:"124.67", vtype:"ZMPT 140V", version:"V3"},
	     ];   
	     
var NODE_TYPES = {2:'S', 3:'P', 4:'F', 5:'Y'};

var FIELD_TYPES = [{id:0, short:'_', long:'NONE'},
		{id:1, short:'P', long:'ACTIVE_POWER'},
		{id:2, short:'S', long:'APPARENT_POWER'},
		{id:3, short:'Vrms', long:'Vrms'},
		{id:4, short:'Irms', long:'Irms'},
		{id:5, short:'EP', long:'ESTIMATED_POWER'},
		{id:6, short:'PF', long:'POWER_FACTOR'},
		{id:7, short:'Temp', long:'TEMPERATURE'},
		{id:8, short:'F', long:'FREQUENCY'},
		{id:9, short:'RTD', long:'RTD'},
		{id:10, short:'Q', long:'REACTIVE_POWER'},
		{id:11, short:'P', long:'ACTIVE_POWER'},
		];
		
function get_field_type_prefix(id){
	for (var i=0; i<FIELD_TYPES.length; i++){
		if (FIELD_TYPES[i]['id']==id){
			return FIELD_TYPES[i]['short'];
		}
	}
	return null;
}

function guess_cttype_from_kcal(kcal){
	var d = 0.0001;
	kcal = parseFloat(kcal);
	for (var i=0; i<ICALS.length; i++){
		var ical = parseFloat(ICALS[i]['ical']);
		if (kcal>ical-d && kcal<ical+d){
			return [ICALS[i]['cttype'], ICALS[i]['version']];
		}
	}
	return [0,0];
}

function guess_vtype_from_kcal(kcal){
	var d = 0.0001;
	kcal = parseFloat(kcal);
	for (var i=0; i<VCALS.length; i++){
		var vcal = parseFloat(VCALS[i]['vcal']);
		if (kcal>vcal-d && kcal<vcal+d){
			return [VCALS[i]['vtype'], VCALS[i]['version']];
		}
	}
	return [0,0];
}

function get_ical(cttype, model, hwversion){
	if (model=="RPICT3T1" || model=="RPICT3V1"){
		hwversion = "V3";
	}
	for (var i=0; i<ICALS.length; i++){
		if (cttype == ICALS[i]['cttype'] && hwversion == ICALS[i]['version']){
			return ICALS[i]['ical'];
		}
	}
	return 0;
	
}

function get_vcal(vtype, model, hwversion){
	if (model=="RPICT3T1" || model=="RPICT3V1"){
		hwversion = "V3";
	}
	for (var i=0; i<VCALS.length; i++){
		if (vtype == VCALS[i]['vtype'] && hwversion == VCALS[i]['version']){
			return VCALS[i]['vcal'];
		}
	}
	return 0;
	
}

function convert_modelname_to_modelid(modelname){
	if (modelname=="RPICT8") return 0;
	else if (modelname=="RPICT7V1") return 1;
	else if (modelname=="RPICT4V3") return 2;
	else return -1;

}

function convert_modelid_to_modelname(modelid){
	if (modelid=="0") return "RPICT8";
	else if (modelid=="1") return "RPICT7V1";
	else if (modelid=="2") return "RPICT4V3";
	else return -1;

}

